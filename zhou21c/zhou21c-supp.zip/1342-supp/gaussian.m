%% Gaussian perturbation
lambda = 0.7;
d = 1e2;  % parameter d
alpha = log(d)/d;
r = 2;  % rank r
R = repmat(eye(r), d/r, 1);
Z = R(randperm(d), :);
B_0 = lambda.*eye(r) + (1-lambda).*ones(r,r);
B = alpha.*B_0;
L = Z*B*Z';  %  L_0
[U,S,V] = svd(L);
P = rand(d);
delta = 0.01;
S = normrnd(0, 1, d, d);
S_0 = tril(S);
S_1 = S_0 + S_0' - diag(diag(S_0));  % Gaussian perturbation
A = L + delta.*S_1; % A
a = norm(L);  % \lambda_1
b = 0.01;   % \sigma
f_A = A*A/norm(L) + A + b*eye(d);  % f(A) in the paper: we choose f(x) = \lambda^{-1}x^2 + x + \sigma
cov = f_A^2;
sample_size = [10, 1e2, 1e3, 1e4, 1e5];
err_gs = [];
for i = 1:100
for k = [1 2 3 4 5]
   n = sample_size(k);
   mu = zeros(d,1);
   Y = mvnrnd(mu, cov, n);
   cov_h = Y'*Y./n;
   [U_h,S_h,V_h] = svd(cov_h);
   thres = 6*(norm(L) * norm(A-L))/2;
   err_gs(i,k) = norm(U_h(:,1:r)*U_h(:,1:r)' - U(:,1:r)*U(:,1:r)', 'fro');
end
end

ex_err_gs = mean(err_gs);

%%
figure; box on;
semilogx(sample_size, ex_err_gs,'r-o','linewidth',2); hold on; grid on;
set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('Gaussian', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e3, 0.2, ['d = ' (num2str(d)), ', r = ' (num2str(r)), ', \delta = ' (num2str(delta))],'color','r','fontsize',20,'fontweight','bold');

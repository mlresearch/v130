%% plot of 3rd row in Fig. 1 Spike model, d = 100, r = 2
d = 100;
r = 2
sample_size = [10, 1e2, 1e3, 1e4, 1e5];
err_sp_del01_de2_r2 = [0.2312    0.0642    0.0201    0.0064    0.0020];
err_sp_del1_de2_r2 =  [1.2154    0.4513    0.1460    0.0463    0.0146];
err_sp_del10_de2_r2 = [1.9366    1.7558    0.8832    0.2985    0.0938];

figure; box on;
loglog(sample_size, err_sp_del01_de2_r2,'r-o','linewidth',2); hold on; grid on;
loglog(sample_size, err_sp_del1_de2_r2,'b-o','linewidth',2); hold on; grid on;
loglog(sample_size, err_sp_del10_de2_r2,'k-o','linewidth',2); hold on; grid on;

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('\epsilon = 0.1','\epsilon = 1.0','\epsilon = 10', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e3, 0.5,['Spike', ', d = ' (num2str(d)), ', r = ' (num2str(r))], 'color','r','fontsize',20,'fontweight','bold');

%% plot of 3rd row in Fig. 1 Spike model, d = 400, r = 4
d = 400;
r = 4;
sample_size = [10, 1e2, 1e3, 1e4, 1e5];
err_sp_del01_d4e2_r4 = [1.2249    0.3519    0.1099    0.0347    0.0110];
err_sp_del1_d4e2_r4 =  [2.5472    1.7797    0.6895    0.2242    0.0710];
err_sp_del10_d4e2_r4 = [2.7997    2.7750    2.5315    1.3372    0.4396];

figure; box on;
loglog(sample_size, err_sp_del01_d4e2_r4,'r-o','linewidth',2); hold on; grid on;
loglog(sample_size, err_sp_del1_d4e2_r4,'b-o','linewidth',2); hold on; grid on;
loglog(sample_size, err_sp_del10_d4e2_r4,'k-o','linewidth',2); hold on; grid on;

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('\epsilon = 0.1','\epsilon = 1.0','\epsilon = 10', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e3, 0.5,['Spike', ', d = ' (num2str(d)), ', r = ' (num2str(r))], 'color','r','fontsize',20,'fontweight','bold');

%% plot of 3rd row in Fig. 1 Spike model, d = 1000, r = 4
d = 1000;
r = 4;
sample_size = [10, 1e2, 1e3, 1e4, 1e5];
err_sp_del01_de3_r4 = [1.5152    0.4868    0.1527    0.0482    0.0153];
err_sp_del1_de3_r4 =  [2.6590    2.0994    0.9481    0.3177    0.1010];
err_sp_del10_de3_r4 = [2.8172    2.8087    2.6538    1.7928    0.6126];

figure; box on;
loglog(sample_size, err_sp_del01_de3_r4,'r-o','linewidth',2); hold on; grid on;
loglog(sample_size, err_sp_del1_de3_r4,'b-o','linewidth',2); hold on; grid on;
loglog(sample_size, err_sp_del10_de3_r4,'k-o','linewidth',2); hold on; grid on;

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('\epsilon = 0.1','\epsilon = 1.0','\epsilon = 10', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e3, 0.5,['Spike', ', d = ' (num2str(d)), ', r = ' (num2str(r))], 'color','r','fontsize',20,'fontweight','bold');

%% plot of 5th row in Fig. 1 \|\hat{U}\hat{U}^T - UU^T \|_F against noise level
nl = [10, 1, 0.1, 0.01, 0.001];
d = 100;
r = 2;
err_gs_ne4de2r2 = [1.9778    1.1388    0.0995    0.0098    0.0012];
err_gs_ne5de2r2 = [1.9436    0.9746    0.1029    0.0102    0.0010];
err_gs_ne6de2r2 = [1.9828    0.9969    0.0956    0.0096    0.0010];

figure; box on;
xticklabels({'10','1','0.1','0.01','0.001'})
loglog(nl, err_gs_ne4de2r2,'r-o','linewidth',2); hold on; grid on;
loglog(nl, err_gs_ne5de2r2,'b-o','linewidth',2); hold on; grid on;
loglog(nl, err_gs_ne6de2r2,'k-o','linewidth',2); hold on; grid on;

set(gca,'fontsize',20);
xlabel('Noise Level \delta');
ylabel('Error');
legend('n = 1e4','n = 1e5','n = 1e6', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e-1, 1e-2, 'Gaussian, d = 400, r = 4','color','r','fontsize',20,'fontweight','bold');

%% plot of 5th row in Fig. 1 \|\hat{U}\hat{U}^T - UU^T \|_F against noise level
nl = [10, 1, 0.1, 0.01, 0.001];
d = 400;
r = 4;
err_gs_ne4d4e2r4 = [2.8166    2.5774    0.4840    0.0483    0.0059];
err_gs_ne5d4e2r4 = [2.8074    2.5686    0.4765    0.0476    0.0049];
err_gs_ne6d4e2r4 = [2.8052    2.5821    0.4837    0.0481    0.0048];

figure; box on;
xticklabels({'10','1','0.1','0.01','0.001'})
loglog(nl, err_gs_ne4d4e2r4,'r-o','linewidth',2); hold on; grid on;
loglog(nl, err_gs_ne5d4e2r4,'b-o','linewidth',2); hold on; grid on;
loglog(nl, err_gs_ne6d4e2r4,'k-o','linewidth',2); hold on; grid on;

set(gca,'fontsize',20);
xlabel('Noise Level \delta');
ylabel('Error');
legend('n = 1e4','n = 1e5','n = 1e6', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e-1, 1e-2, 'Gaussian, d = 400, r = 4','color','r','fontsize',20,'fontweight','bold');

%% plot of 5th row in Fig. 1 \|\hat{U}\hat{U}^T - UU^T \|_F against noise level
nl = [10, 1, 0.1, 0.01, 0.001];
d = 1000;
r = 4;
err_gs_ne4de3r4 = [2.8241    2.7860    0.6678    0.0667    0.0081];
err_gs_ne5de3r4 = [2.8246    2.7852    0.6536    0.0651    0.0067];
err_gs_ne6de3r4 = [2.8236    2.7170    0.6482    0.0653    0.0066];

figure; box on;
xticklabels({'10','1','0.1','0.01','0.001'})
loglog(nl, err_gs_ne4de3r4,'r-o','linewidth',2); hold on; grid on;
loglog(nl, err_gs_ne5de3r4,'b-o','linewidth',2); hold on; grid on;
loglog(nl, err_gs_ne6de3r4,'k-o','linewidth',2); hold on; grid on;

set(gca,'fontsize',20);
xlabel('Noise Level \delta');
ylabel('Error');
legend('n = 1e4','n = 1e5','n = 1e6', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e-1, 1e-2, 'Gaussian, d = 1000, r = 4','color','r','fontsize',20,'fontweight','bold');




























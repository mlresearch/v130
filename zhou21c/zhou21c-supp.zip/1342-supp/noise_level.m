%% gaussian perturbation with different noise level
lambda = 0.7;
d = 4*1e2; %  dimension d
alpha = log(d)/d;
r = 4;  % rank r
R = repmat(eye(r), d/r, 1);
Z = R(randperm(d), :);
B_0 = lambda.*eye(r) + (1-lambda).*ones(r,r);
B = alpha.*B_0;
L = Z*B*Z';  %  L_0
[U,S,V] = svd(L);
delta = [1, 0.1, 0.01, 0.001, 0.0001];
S = normrnd(0, 1, d, d);
S_0 = tril(S);
S_1 = S_0 + S_0' - diag(diag(S_0));
sample_size = 1e6;  % sample size n
err_gs = [];  % error rate against \delta
for i = 1:100
for k = [1 2 3 4 5]
   n = sample_size;
   mu = zeros(d,1);
   A = L + delta(k).*S_1;  % matrix A
   b = 0.01;  % \sigma
   f_A = A*A/norm(L) + A + b*eye(d);  % f(A) in the paper: we choose f(x) = \lambda^{-1}x^2 + x + \sigma
   cov = f_A^2;
   Y = mvnrnd(mu, cov, n);
   cov_h = Y'*Y./n;
   [U_h,S_h,V_h] = svd(cov_h);
   thres = 6*(norm(L) * norm(A-L))/2;
   err_gs(i,k) = norm(U_h(:,1:r)*U_h(:,1:r)' - U(:,1:r)*U(:,1:r)', 'fro');
end
end

ex_err_gs = mean(err_gs);

%%
nl = [10, 1, 0.1, 0.01, 0.001];
figure; box on;
xticklabels({'10','1','0.1','0.01','0.001'})
loglog(nl, ex_err_gs,'r-o','linewidth',2); hold on; grid on;
set(gca,'fontsize',20);
xlabel('Noise Level \delta');
ylabel('Error');
legend('Gaussian', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(1e-1, 1e-2, ['d = ' (num2str(d)), ', r = ' (num2str(r)), ', n = ' (num2str(sample_size))],'color','r','fontsize',20,'fontweight','bold');

%% parameter initialization
lambda = 0.7;
d = 1*1e2; % parameter d: number of nodes of the network
alpha = log(d)/d; 
r = 4; % rank r
R = repmat(eye(r), d/r, 1);
Z = R(randperm(d), :);
B_0 = lambda.*eye(r) + (1-lambda).*ones(r,r);
B = alpha.*B_0;
L = Z*B*Z'; % L_0 in the paper: connectivity matrix

%% construct stochastic block model (random graph)
[U,S,V] = svd(L);
P = rand(d);
A = double((P < L)); % A in the paper: 
S_0 = A - L;
delta = norm(S_0);
low_A = tril(A);
S_g = low_A + low_A' - 2*diag(diag(A));
%[U_1,S_1,V_1] = svd(S_g);
a = norm(L); % \lambda_1 of L_0
b = 0.01; % \sigma in the paper
f_A = S_g^2./norm(L) + S_g + b*eye(d); % f(A) in the paper: we choose f(x) = \lambda^{-1}x^2 + x + \sigma
cov = f_A^2;
sample_size = [10, 1e2, 1e3, 1e4, 1e5]; % sample size n

%% compute \| \hat{U}\hat{U}^T - UU^T \|_F
err_g = []; % err_1 in (6.3)
for k = [1 2 3 4 5]
   n = sample_size(k);
   mu = zeros(d,1);
   Y = mvnrnd(mu, cov, n); % observation
   cov_h = Y'*Y./n;
   [U_h,S_h,V_h] = svd(cov_h);
   thres = 6*(norm(L) * norm(A-L))/2;
   err_g(k) = norm(U_h(:,1:r)*U_h(:,1:r)' - U(:,1:r)*U(:,1:r)', 'fro');
   member = kmeans(U_h, 3);
end


%% construct spiked covariance model
A = L + delta * eye(d);
f_A = A^2./norm(L) + A + b*eye(d);  % f(A) in the paper: we choose f(x) = \lambda^{-1}x^2 + x + \sigma
cov = f_A^2;
err_sp = []; % err_2 in (6.3)
for k = [1 2 3 4 5]
   n = sample_size(k);
   mu = zeros(d,1);
   Y = mvnrnd(mu, cov, n);
   cov_h = Y'*Y./n;
   [U_h,S_h,V_h] = svd(cov_h);
   thres = 6*(norm(L) * norm(A-L))/2;
   err_sp(k) = norm(U_h(:,1:r)*U_h(:,1:r)' - U(:,1:r)*U(:,1:r)', 'fro');
   member = kmeans(U_h, 3);
end

%% plot err_1 and err_2

figure; box on;
semilogx(sample_size, err_g,'r-o','linewidth',2); hold on; grid on;
semilogx(sample_size, err_sp,'k-+','linewidth',2);grid on;

%loglog(D, normal_rate, 'k--','linewidth',2);
set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('Random Graph','Spike','location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(45,0.3, ['d = ' (num2str(d)), ', r = ' (num2str(r))],'color','r','fontsize',20,'fontweight','bold');





%% d = 40 r = 2
err_g4e1 =  [1.6406    1.5901    1.5955    1.6037    1.5850];
err_sp4e1 = [1.6329    0.8588    0.2704    0.0922    0.0287];
sample_size = [10, 1e2, 1e3, 1e4, 1e5];

figure; box on;
semilogx(sample_size, err_sp4e1,'k-+','linewidth',2); grid on;
set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('Spike', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(45,0.3, 'd = 40, r = 2','color','r','fontsize',20,'fontweight','bold');

%% d = 400
err_g4e2 =  [2.7934    2.6118    2.5760    2.5521    2.5489];
err_sp4e2 = [2.7580    2.6068    1.4835    0.5070    0.1579];
sample_size = [10, 1e2, 1e3, 1e4, 1e5];

figure; box on;
semilogx(sample_size, err_g4e2,'r-o','linewidth',2); hold on; grid on;

semilogx(sample_size, err_sp4e2,'k-+','linewidth',2);grid on;

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('Random Graph','Spike','Bound','location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(45,0.3, 'd = 400, r = 4','color','r','fontsize',20,'fontweight','bold');


%% d = 4000
err_g1e3 =  [2.7845    2.7524    2.6579    2.6243    2.6310];
err_sp1e3 = [2.8207    2.7535    1.9825    0.7719    0.2484];
sample_size = [10, 1e2, 1e3, 1e4, 1e5];

figure; box on;
semilogx(sample_size, err_g1e3,'r-o','linewidth',2); hold on; grid on;

semilogx(sample_size, err_sp1e3,'k-+','linewidth',2);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('Random Graph','Spike','Bound','location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(45,0.3, 'd = 1000, r = 4','color','r','fontsize',20,'fontweight','bold');

%% plot of err_1 and err_2

figure; box on;

semilogx(sample_size, err_sp4e1,'k-+','linewidth',2); grid on;
set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Error');
legend('Spike', 'location', 'northeast')
set(gca,'yminorgrid','off','xminorgrid','off');
text(45,0.3, 'd = 40, r = 2','color','r','fontsize',20,'fontweight','bold');



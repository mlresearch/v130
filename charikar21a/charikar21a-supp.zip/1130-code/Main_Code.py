import numpy as np
import time
import json
from algs.hals import HALS
from algs.onmfs import ONMFS
from algs.onmf_ding import ONMF_Ding
from algs.onmf_a import ONMF_A
from algs.pnmf import PNMF
from algs.nhl import NHL
from algs.nmf import NMF
from algs.onmf_em import ONMF_EM
from algs.onmf_apx import ONMF_apx
from algs.onmf_ding_double import ONMF_Ding_double
from utils import divide

def create_orthogonal_factor (m,k):
    asgn = np.random.randint(k, size = m)
    factors = np.zeros((m,k))
    for i in range(m):
        factors[i,asgn[i]] = np.random.exponential()
    return factors

def create_factor(m,k):
    return np.random.exponential(1, size = (m,k))


def non_orthogonality(U):
    gram = U.T @ U
    diag = np.diag(gram)

    k = np.shape(diag)

    diag_1 = divide(np.ones(k), diag)
    diag_sqrt = np.diag(np.sqrt(diag_1))
    diag_2 = np.diag(diag)
    return np.linalg.norm(diag_sqrt @ (gram - diag_2) @ diag_sqrt,ord = "fro")


def run(name, alg, double, noise, m, n, k, num_runs):
    temp_error = []
    temp_noisy_error = []
    temp_non_ort = []
    temp_non_ortF = []
    temp_time = []
    for _ in range(num_runs):
        print("############## alg: " + alg.name + ", k: " + str(k) + ", noise: " + str(noise) +  ", trial: " + str(_))
        if double:
            U = create_orthogonal_factor(m, k)
        else:
            U = create_factor(m, k)
        V = create_orthogonal_factor(n, k)

        X_truth = U @ V.T
        X = X_truth + np.random.exponential(noise,size = (m,n))

        if double:
            start_time = time.time()
            F, S, G = alg.func(X,k, True)
            time_elapsed = time.time() - start_time
            temp_error.append(np.linalg.norm(F @ S @ G.T - X_truth, ord = "fro"))
            temp_noisy_error.append(np.linalg.norm(F @ S @ G.T - X, ord = "fro"))
        else:
            start_time = time.time()
            F, G = alg.func(X,k)
            time_elapsed = time.time() - start_time
            temp_error.append(np.linalg.norm(F @ G.T - X_truth, ord = "fro"))
            temp_noisy_error.append(np.linalg.norm(F @ G.T - X, ord = "fro"))

        temp_time.append(time_elapsed)
        temp_non_ort.append(non_orthogonality(G))
        temp_non_ortF.append(non_orthogonality(F))

    recovery = np.median(temp_error)
    reconstruction = np.median(temp_noisy_error)
    non_ort = np.median(temp_non_ort)
    non_ortF = np.median(temp_non_ortF)
    runtime = np.median(temp_time)

    data = {}
    data['name'] = name
    if double:
        data['orthogonality'] = "double"
    else:
        data['orthogonality'] = "single"
    data['alg'] = alg.name
    data['noise'] = noise
    data['m'] = m
    data['n'] = n
    data['k'] = k
    data['recovery error'] = recovery
    data['reconstruction error'] = reconstruction
    data['non_ort_W'] = non_ort
    data['non_ort_A'] = non_ortF
    data['running time'] = runtime
    data['number of independent runs'] = num_runs
    out_file = 'json/result_' + name + '.json'
    with open('json/result_' + name + '.json', 'w') as outfile:
        json.dump(data, outfile)
    print()
    print("Experiment results are written in " + out_file)



if __name__ == "__main__":
    single_alg_name_list = ["ONMF-apx", "ONMF-Ding", "HALS", "NHL", "NMF", "ONMF-A", "EM-ONMF", "ONMFS", "PNMF"]
    single_alg_list = [ONMF_apx, ONMF_Ding, HALS, NHL, NMF, ONMF_A, ONMF_EM, ONMFS, PNMF]
    double_alg_name_list = ["ONMF-apx", "ONMF-Ding", "NMF"]
    double_alg_list = [ONMF_apx, ONMF_Ding, NMF]

    print("Please enter a name for the experiment: ")
    name = input()
    print()

    print("Please select an orthogonality setting. Enter 'd' for double-factor and anything else for single-factor. ")
    double = input() == 'd'

    if double:
        alg_name_list = double_alg_name_list
        alg_list = double_alg_list
    else:
        alg_name_list = single_alg_name_list
        alg_list = single_alg_list

    print()

    print("What algorithm do you want to run in this experiment? Please enter an algorithm name in the following list:")
    for s in alg_name_list:
        print(s)
    print()
    valid = False
    while not valid:
        alg = input()
        try:
            i = alg_name_list.index(alg)
            valid = True
            alg = alg_list[i]
        except ValueError:
            print("Invalid algorithm name. Try again.")

    print()

    print("Please enter the following parameters of the experiment seperated by spaces: ")
    print("noise level, m, n, inner dimension k, number of independent runs.")

    if double:
        default = '0.0 100 500 5 7'
    else:
        default = '0.0 100 5000 10 7'

    print("Enter 'd' for the default parameters '" + default + "'. ")
    meta = input()
    if meta == 'd':
        meta = default
    meta = meta.split()
    run (name, alg, double, float(meta[0]), int(meta[1]), int(meta[2]), int(meta[3]), int(meta[4]))

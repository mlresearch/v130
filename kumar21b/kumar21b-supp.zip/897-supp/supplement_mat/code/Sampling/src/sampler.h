/*
 * sampler.h
 *
 *  Created on: Feb 5, 2020
 *      Author: -
 */
#ifndef SRC_SAMPLING_H_
#define SRC_SAMPLING_H_

#include <iostream>
#include <vector>
#include "gsl/gsl_rng.h"
#include "gsl/gsl_randist.h"
#include "gsl/gsl_sf_bessel.h"

class sampler {
private:
	gsl_rng *generator;

public:
	/**
	 * Initialize random number generator
	 */
	sampler();

	/**
	 * Free random number generator
	 */
	~sampler();

	/**
	 * Change seed
	 */
	void set_seed(unsigned long int s);

	/**
	 * Sample from a Gaussian distribution with mean m and standard deviation std.
	 */
	double sample_gaussian_dist(double m, double std);

	/**
	 * Get the likelihood weight for a point from Gaussian distribution with mean m and standard deviation std.
	 */
	double weight_gaussian_dist(double m, double std, double x);

	/**
	 * Sample from a bernoulli distribution with parameter p.
	 */
	unsigned int sample_bernoulli_dist(double p);

	/**
	 * Get the likelihood weight for a point from a bernoulli distribution with parameter p.
	 */
	double weight_bernoulli_dist(unsigned int k, double p);

	/**
	 * Sample from a multinomial distribution
	 */
	unsigned int sample_discrete_dist(unsigned int size, double* p);

};

#endif /* SRC_SAMPLING_H_ */

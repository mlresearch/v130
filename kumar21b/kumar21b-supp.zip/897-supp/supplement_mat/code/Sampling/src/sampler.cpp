/*
 * sampler.cpp
 *
 *  Created on: Feb 5, 2020
 *      Author: -
 */
#include "sampler.h"
#include <ctime>

using namespace std;

sampler::sampler() {
	const gsl_rng_type * t;
	gsl_rng_env_setup();
	t = gsl_rng_default;
	generator = gsl_rng_alloc(t);
}

void sampler::set_seed(unsigned long int s) {
	gsl_rng_set(generator, s);
}

sampler::~sampler() {
	gsl_rng_free(generator);
}

double sampler::sample_gaussian_dist(double m, double std) {
	double s = gsl_ran_gaussian(generator, std);
	return s+m;
}

double sampler::weight_gaussian_dist(double m, double std, double x) {
	x = x-m;
	return gsl_ran_gaussian_pdf(x, std);
}

unsigned int sampler::sample_discrete_dist(unsigned int size, double* p) {
	gsl_ran_discrete_t* temp =  gsl_ran_discrete_preproc(size, p);
	return gsl_ran_discrete(generator, temp);
}

unsigned int sampler::sample_bernoulli_dist(double p) {
	return gsl_ran_bernoulli(generator, p);
}

double sampler::weight_bernoulli_dist(unsigned int k, double p) {
	return gsl_ran_bernoulli_pdf(k, p);
}


int main() {
	int i;
	sampler *samplerObj = new sampler();
	int x;
	clock_t begin = clock();
	for(i=0; i<10; i++) {
		x = (int)samplerObj->sample_bernoulli_dist(0.9);
	}
	clock_t end = clock();
	double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
	cout << "Time elapsed in secs: " << elapsed_secs <<"\n";
	return 0;
}

class Logger():
    VERBOSE = False

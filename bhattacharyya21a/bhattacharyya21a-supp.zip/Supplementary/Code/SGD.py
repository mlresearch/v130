import numpy as np
from matplotlib import pyplot as plt
import sys
import csv
from copy import copy, deepcopy

#************************Global Variables***************************************

d = 10                                  # number of nodes
n = 50000                               # number of samples

truncbox = [2 for i in range(d)]        # Truncation Box that truncates each co-ordinate support to (-2,2)
epsilon=0.1                             # Desired Accuracy
threshold = 0.1                         # Thresholding value for precision matrix.

#************** Permutation of Identity as Precision Matrix ********************

def Precision_M(d):
    Identity = np.identity(d)
    for i in range(d-1):
        for j in range(d-1):
            if i == j:
                Identity[i][j+1]=0.2
    for i in range(1,d):
        for j in range(1,d):
            if i == j:
                Identity[i][j-1]=0.2
    return Identity

iprecision = Precision_M(d)
icovariance = np.linalg.inv(iprecision)
mean = [0 for i in range(d)]

#**********************Sampling from Truncated Gaussian************************

def sampling(d,n):
    x=[[0 for i in range(d)] for j in range(n)]
    flag = 1
    i=0
    while i<n:
        flag=1
        x[i] = np.random.multivariate_normal(mean,icovariance)
        for j in range(d):
            if x[i][j]<truncbox[j] and x[i][j]> -truncbox[j]:
                flag = flag and 1
            else:
                flag = flag and 0
        if flag == 1:
            i = i+1
        else:
            i = i
    return x


samples = sampling(d,n)

#************************Evaluating Gradient************************************

#Evaluation of the x part in the gradient

#Evaluating average of xx^T
def x_outer_product(n,d,samples):
    outer_product = np.zeros((d,d))
    for i in range(n):
        outer_product=np.outer(samples[i],samples[i])+outer_product
    return -outer_product/(n*2)

#Evaluating average of x
def x_mean(n,d,samples):
    average = np.zeros(d)
    for i in range(n):
        average = samples[i]+average
    return average/n

#Evaluation of the z part in the gradient
Tn_samples=np.asarray(samples).T
Sample_Cov = np.cov(Tn_samples)
Sample_Mean = np.mean(Tn_samples,axis = 1)

#Evaluating zz^T
def z_outer_product(z):
    return -np.outer(z,z)/2

#Evaluating z
def z_mean(z):
    return z

#Function for checking if point is in truncbox
def oracle(z):
    flag = 1
    for i in range(d):
        if z[i]<truncbox[i] and z[i]>-truncbox[i]:
            flag = flag and 1
        else:
            flag = flag and 0
    return flag

#Evaluating non-zero entires in the precision matrix used in setting regularizer
def nonzero(precision_matrix):
    nz = np.count_nonzero(precision_matrix)
    return nz

#Function for evaluating Hamming distance of a matrix from true precision matrix
def Hamming(Theta):
    hdistance = 0
    for i in range(d):
        for j in range(d):
            if i != j:
                if Theta[i][j] > 0 and Theta[i][j]< threshold:
                    Theta[i][j] = 0
                elif Theta[i][j]< 0 and Theta[i][j] > -threshold:
                    Theta[i][j] = 0
    for i in range(d):
        for j in range(d):
            if Theta[i][j] == 0 and iprecision[i][j]!=0:
                hdistance = hdistance + 1
            elif Theta[i][j] != 0 and iprecision[i][j]==0:
                hdistance = hdistance + 1
            else:
                hdistance = hdistance
    return hdistance
#**********************************SGD******************************************

#Initlising local values in SGD
ITER=1000000
Frob_norm=[]
hdistance=[]
eta = 0.01
ming=0

#Choosing appropriate regularizer according to Lemma 7
lambda_reg = 2*(epsilon/(1000*np.sqrt(nonzero(np.linalg.inv(Sample_Cov))+d)))

#Setting Inital Mean to (0,0...,0) and Intial Theta to inverse of sample covariance matrix
Theta_0=np.linalg.inv(Sample_Cov)
v_0= [0 for i in range(d)]
next_Theta=Theta_0

#Evaluation of x part of the Gradient
grad_true_Theta = x_outer_product(n,d,samples)
grad_true_v = x_mean(n,d,samples)

#Intialising loop
i=0
while i < ITER:
    #Get current parameters
    curr_Theta = next_Theta
    curr_v = v_0

    #Making Theta symmetric
    curr_Theta = (0.5*curr_Theta)+(0.5*(curr_Theta.T))

    #Checking min eigen value conditions
    ming = min(np.linalg.eigvalsh(curr_Theta))
    if ming<0.00001:
       curr_Theta = curr_Theta-(ming-0.0001)*np.identity(d)

    curr_Sigma = np.linalg.inv(curr_Theta)
    curr_mu = v_0

    #Sampling from trunated gaussian with parameters as estiamted precision matrix
    check_mem = 0
    while(not check_mem):
      z = np.random.multivariate_normal(curr_mu,curr_Sigma)
      check_mem = oracle(z)

    #Evaluation of z part in gradient with z sampled from updated truncated gaussian
    grad_z_Theta = z_outer_product(z)
    grad_z_v = z

    #Evaluating gradient of L1 norm of Theta
    grad_l1_Theta = curr_Theta/np.abs(curr_Theta)
    for j in range(d):
        for k in range(d):
            if j==k:
                grad_l1_Theta=0

    #Update Theta
    next_Theta = curr_Theta + 1/(np.sqrt(i+1))*(grad_true_Theta - grad_z_Theta-lambda_reg*grad_l1_Theta)


    #Calculating Frobenius norm and Hamming distance between current update and precision matrix
    next_frob = np.linalg.norm(np.asarray(next_Theta)-np.asarray(iprecision))
    Frob_norm.append(next_frob)
    temp_theta = deepcopy(next_Theta)
    hdistance.append(Hamming(temp_theta))

    #Loop Break when gradient is less than epsilon
    if np.linalg.norm(grad_true_Theta - grad_z_Theta-lambda_reg*grad_l1_Theta)< epsilon:
        break

    i=i+1
    if (i-1)%1000==0:
        print(Frob_norm[i-1])


#*******************************Code for Plotting Results***********************

def running_mean(x, N):
    cumsum = np.cumsum(np.insert(x, 0, 0))
    return (cumsum[N:] - cumsum[:-N]) / float(N)
'''
#Code for plotting hamming distance vs Iterations
hdistance_mean=running_mean(hdistance,10)
plt.plot(hdistance_mean)
plt.xlabel("Iterations")
plt.ylabel("Hamming Distance")
plt.plot(hdistance_mean,"b")
plt.show()
plt.savefig('Hamming.png')


#Code for saving number of samples vs Frobenius norm of difference between estimate and true precision matrix
with open('samples.csv', 'ab') as file:
    writer = csv.writer(file)
    writer.writerow([n,Frob_norm[-1]])
'''
#Code for plotting Frobenius norm of difference between estimate and true precision matrix

Frob_norm_mean = running_mean(Frob_norm,10)
def plot(frob):
    x = np.arange(0,ITER,100)
    y = []
    for i in range(0,ITER,100):
        y.append(Frob_norm[i])
    plt.title("Accuracy vs Iterations")
    plt.xlabel("Iterations")
    plt.ylabel("Frobenius norm of difference")
    plt.plot(x,y,"ob")
    plt.show()
    plt.savefig('accuiteration.png')

plot(Frob_norm_mean)

import numpy as np
from matplotlib import pyplot as plt
from scipy.interpolate import interp1d

x = [50,100,250,500,750,1000,2500,5000]
y = [42,34,22,12,4,2,0,0]
plt.title("Hamming Distance vs Samples")
plt.xlabel("Samples")
plt.ylabel("Hamming Distance")
plt.plot(x,y,"b")
plt.plot(x,y,"ob")
plt.show()
plt.savefig('samples_hamming.png')

plot(values)

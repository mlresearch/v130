The project samples from a truncated gaussian and uses projected SGD to obtain sparse precision matrix.
The code also evaluates frobenius norm of difference between precision matrix and estimate as well as hamming distance between the two as a measure of accuracy.
We also include codes for the required plots.

The first code is SGD.py
-The code is written in Python 2.0 and requires packages like numpy, maptplotlib, copy, sys and csv.
-The code requires a 'samples.csv' file from where it is being executed to save samples vs accuracy.
-The code in the present state will plot the graph of frobenius error vs iterations.
-It also includes code for plotting hamming distance between estimates vs iterations which has been commented out.
Please comment out the hamming distance part to plot that.
-A simple 'python SGD.py' will execute the code.

The second provided code is plot.py
-The code is written in Python 2.0 and requires packages like numpy, maptplotlib and scipy
-We run the 'SGD.py' code for various values of initial samples and store the values in the plot.py array
-x stores the number of values and y stores the hamming distance and the code generates the plot

The last provided file is 'samples.csv'
-We saved the number of samples vs the accuracy in a .csv file
-We later used the values from the csv file and used 'plot.py' for plotting our samples vs accuracy plot

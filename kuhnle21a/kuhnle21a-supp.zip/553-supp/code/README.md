## Quick Streaming Algorithms for Maximization of Monotone Submodular Functions in Linear Time

This is the implementation of all algorithms evaluated in the paper,
for both revenue max and maximum cover applications.

### Dependencies 
GNU g++, GNU make utility

### Binaries
. `maxcov`, the main program to run all algorithms on maximum cover
. `revmax`, the main program to run all algorithms on revenue max
. `preproc`, for preprocessing edge lists to custom binary format

### Format of input graph

The programs take as input a custom binary format; the program
`preproc` is provided to convert an undirected edge list format
to the binary format. 

Each line describes an edge
```
<From id> <To id> <Weight (only if weighted)>
```
The node ids must be nonnegative integers; they are not restricted to lie in any range.
The `Weight` must be an unsigned integer.

If `graph.el` is an edge list in the above format, then
```
preproc graph.el graph.bin
```
generates the `graph.bin` file in the correct binary format for input to the other programs.

### Parameters 
```
-g <graph filename in binary format>
-k <cardinality constraint>
-G [run StandardGreedy]
-S [run SieveStream++]
-P [run P-Pass]
-L [run LTL]
-K [run Chakrabarti&Kale]
-Q [run QuickStream]
-R [run QS + BR]
-o <outputFileName>
-N <repetitions>
-e <accuracy parameter epsilon (default 0.1)>
-p [Only with -Q, run QuickStream++]
-t <Tradeoff in error, only applies to P-Pass>
-c <blocksize, only applies to QuickStream(++)>
-q [quiet mode]

```
### Example
```
bash gen-table.bash
```
Should generate the following table, for maxcover
on a Barabasi-Albert random graph
with n = 4997, k = 50.
```
      Algorithm       Objective         Queries
         GREEDY            3865          248831
  SIEVESTREAM++            3380          135138
         P-PASS            3864         1362850
            LTL            3651           11495
            C&K            3809            9996
        QS + BR            3864          104542
  QuickStream_1            1997            4998
QuickStream_1++            3864            5381
  QuickStream_2            1873            2501
QuickStream_2++            3864            2993
  QuickStream_8            3739             632
QuickStream_8++            3864            1477			
```
### Reproduce Experiments in Paper
Scripts are provided to partially reproduce the experiments in the paper,
namely the experiments with small k values for the maximum cover application
on web-Google. To reproduce these experiments, simply run the command: 
```
make reproduce
```
If Python 3 is installed with matplotlib, the results will be plotted in the exp subfolders
as PDF files.


Requirements:
	Python 3
	Numpy
	Scipy
	Sckit-learn
	Cvxpy
	Pandas
	
Synthetic dataset experiments:
	constrained_vs_unconstrained_n_100_r_1.py
	constrained_vs_unconstrained_n_100_r_5.py
	constrained_vs_unconstrained_n_200_r_5.py
	sdp_vs_hsvt_matrix_completion_n_100_r_1.py
	sdp_vs_hsvt_matrix_completion_n_100_r_5.py
	sdp_vs_hsvt_pcr_n_100_r_1.py
	sdp_vs_hsvt_pcr_n_100_r_5.py
	cross_val.py
	approx_lr.py

Real dataset experiments:
	cmb_data_regression.py
	qsar_exps.py


Please download the following datasets into the working directory to run real dataset experiments:
	https://archive.ics.uci.edu/ml/datasets/QSAR+aquatic+toxicity
	http://archive.ics.uci.edu/ml/datasets/condition+based+maintenance+of+naval+propulsion+plants
	

To run an experiment, run the command:
	python [filename.py]

import numpy as np
import random as rand
import matplotlib
import matplotlib.pyplot as plt
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
from cvxpy import *
from scipy.stats import bernoulli, ortho_group

rng = np.random.RandomState(seed=42)

def gen_mask(m, n, prob_masked=0.5, rng = np.random.RandomState(seed=42)):
    return bernoulli.rvs(p=prob_masked, size=(m, n), random_state=rng)

def gen_factorization_with_noise_orth_rand(m, n, k, sigma = 1 , s = 10, rng = np.random.RandomState(seed=42)):
    U = ortho_group.rvs(m, 1, rng)[:, :k].reshape((m, k))
    V = ortho_group.rvs(n, 1, rng)[:, :k].reshape((n, k))
    S = np.diag(np.ones(k)*s)
    N = rng.randn(m, n) * sigma #gen_noise(m, n, sigma, rng)
    R = N + np.dot(np.dot(U, S), V.T) #rng.randn(m, n) * sigma + np.dot(np.dot(U, S), V.T)
    return U, S, V, R

def nuclear_norm_solve_unconstrained(A, mask, lmbda = 10.0):
    X = Variable(shape=A.shape)
    # objective = Minimize(lmbda*norm(X,"nuc") + 0.5*sum(pow(multiply(mask, X - A), 2)))
    objective = Minimize(norm(X,"nuc") + (0.5/float(lmbda))*sum(pow(multiply(mask, X - A), 2)))
    problem = Problem(objective)
    problem.solve(solver=SCS)
    return X.value

def nuclear_norm_solve_constrained_frob_delta(A, mask, delta = 10.0):
    X = Variable(shape=A.shape)
    objective = Minimize(norm(X,"nuc"))
    constraint = [sum(pow(multiply(mask, X - A), 2)) <= delta**2]
    problem = Problem(objective, constraint)
    problem.solve(solver=SCS)
    return X.value

def nuclear_norm_solve_constrained_individual_delta(A, mask, delta = 10.0):
    X = Variable(shape=A.shape)
    objective = Minimize(norm(X,"nuc"))
    # constraint = [max(pow(multiply(mask, X - A), 2)) <= delta**2]
    constraint = []
    for i in range(A.shape[0]):
      for j in range(A.shape[1]):
        if mask[i,j]:
          constraint += [atoms.elementwise.abs.abs(X[i,j]-A[i,j]) <= delta]
    problem = Problem(objective, constraint)
    problem.solve(solver=SCS)
    return X.value


def compute_hsvt(A, mask, r=1):
    A_ = np.multiply(A, mask)/(np.sum(mask)/(mask.shape[0]*mask.shape[1]))
    # A_ = np.multiply(A, mask)
    U, S, Vt = np.linalg.svd(A_)
    return np.dot(np.dot(U[:, :r], np.diag(S[:r])), Vt[:r, :])

def calc_cost_frob(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.linalg.norm((pred - truth), 'fro')
    return cost

def calc_cost_nuc(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.linalg.norm((pred - truth), 'nuc')
    return cost

def calc_cost_spectral(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.linalg.norm((pred - truth), 2)
    return cost

def calc_cost_max(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.max(np.abs(pred - truth))
    return cost

def semi_randomize_mask(mask, col_frac=0.9, row_frac=0.9, rnd=True,):
    """If rnd=True, randomly choose fractions of given columns and rows,
       Otherwise choose first fraction of columns and rows"""
    m = mask.shape[0]
    n = mask.shape[1]
    new_mask = mask.copy()
    if rnd:
      rows = rng.choice(np.arange(m), int(row_frac*m), replace=False)
      for row in rows:
        cols = rng.choice(np.arange(n), int(col_frac*n), replace=False)
        for col in cols:
          new_mask[row, col] = 1
      return new_mask
    else:
      rows = np.arange(int(m*row_frac))
      for row in rows:
        cols = np.arange(int(n*col_frac))
        for col in cols:
          new_mask[row, col] = 1
      return new_mask

def semi_randomize_mask_adverse(mask, E, l):
    """open highest noise elements"""
    m = mask.shape[0]
    n = mask.shape[1]
    remaining = np.ones((m,n)) - mask
    unmasked_E = np.abs(np.multiply(remaining, E))
    picked = np.argsort(unmasked_E, axis=None)[-l:]
    new_mask = np.zeros((m, n)).flatten()
    new_mask[picked] = 1
    new_mask = new_mask.reshape((m, n))
    new_mask = mask + new_mask
    return new_mask

def semi_randomize_mask_positive_noise(mask, E):
    """open elements with positive noise"""
    pos = E > 0
    new_mask = np.logical_or(mask, pos).astype(int)
    return new_mask
    
    
# k = 5
n = 100
p = 0.4
k = 5
s = 1
n_iter = 5
sigma_list = np.array([0.0001, 0.0005, 0.001, 0.0015, 0.002])
print(sigma_list)
errs_constrained = np.zeros((len(sigma_list), n_iter))
errs_unconstrained = np.zeros((len(sigma_list), n_iter))
for i, sigma in enumerate(sigma_list):
  delta_inf =  4 * sigma * np.sqrt(np.log(n)) 
  lmbda = 5 * sigma * np.sqrt(n*p)
  print('delta inf: ', delta_inf)
  print('lambda: ', lmbda)
  for j in range(n_iter):    
    U, S, V, R = gen_factorization_with_noise_orth_rand(n, n, k, sigma, s, rng)
    R_star = np.dot(np.dot(U, S), V.T)
    mask = gen_mask(n, n, p, rng)
    R_hat_constrained_rand = nuclear_norm_solve_constrained_individual_delta(R, mask, delta_inf)
    R_hat_unconstrained_rand = nuclear_norm_solve_unconstrained(R, mask, lmbda)
    frob_err_constrained = calc_cost_frob(U, S, V, R_hat_constrained_rand)
    frob_err_unconstrained = calc_cost_frob(U, S, V, R_hat_unconstrained_rand)
    errs_constrained[i, j] = frob_err_constrained
    errs_unconstrained [i, j] = frob_err_unconstrained
  print('sigma: ', sigma, ' done.')
R_star_frob = np.sqrt(s*k)
# scale
errs_constrained = errs_constrained/R_star_frob
errs_unconstrained  = errs_unconstrained/R_star_frob

errs_constrained_mean = np.mean(errs_constrained, axis=1)
errs_unconstrained_mean = np.mean(errs_unconstrained, axis=1)
errs_constrained_std = np.std(errs_constrained, axis=1)
errs_unconstrained_std = np.std(errs_unconstrained, axis=1)

print(errs_constrained_mean)
print(errs_unconstrained_mean)
print(errs_constrained_std)
print(errs_unconstrained_std)



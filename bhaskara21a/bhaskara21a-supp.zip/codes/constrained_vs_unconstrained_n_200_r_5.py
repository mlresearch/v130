import numpy as np
import random as rand
import matplotlib
import matplotlib.pyplot as plt
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
from cvxpy import *
from scipy.stats import bernoulli, ortho_group
from functions import *

rng = np.random.RandomState(seed=42)

print('this is started now.')

# k = 5
n = 200
p = 0.4
k = 5
s = 1
n_iter = 5
sigma_list = np.array([0.0001, 0.0005, 0.001, 0.0015, 0.002])
print(sigma_list)
errs_constrained = np.zeros((len(sigma_list), n_iter))
errs_unconstrained = np.zeros((len(sigma_list), n_iter))
for i, sigma in enumerate(sigma_list):
  print('snr fro: ', np.sum(np.sqrt(np.power(np.arange(s, s+(s*k)+1, s), 2)))/(sigma*n))
  delta_inf =  4 * sigma * np.sqrt(np.log(n)) 
  lmbda = 5 * sigma * np.sqrt(n*p)
  print('delta inf: ', delta_inf)
  print('lambda: ', lmbda)
  for j in range(n_iter):    
    U, S, V, R = gen_factorization_with_noise_orth_rand(n, n, k, sigma, s, rng)
    R_star = np.dot(np.dot(U, S), V.T)
    mask = gen_mask(n, n, p, rng)
    R_hat_constrained_rand = nuclear_norm_solve_constrained_individual_delta(R, mask, delta_inf)
    R_hat_unconstrained_rand = nuclear_norm_solve_unconstrained(R, mask, lmbda)
    frob_err_constrained = calc_cost_frob(U, S, V, R_hat_constrained_rand)
    frob_err_unconstrained = calc_cost_frob(U, S, V, R_hat_unconstrained_rand)
    errs_constrained[i, j] = frob_err_constrained
    errs_unconstrained [i, j] = frob_err_unconstrained
  print('sigma: ', sigma, ' done.')
R_star_frob = np.sqrt(s*k)
# scale
errs_constrained = errs_constrained/R_star_frob
errs_unconstrained  = errs_unconstrained/R_star_frob


errs_constrained_mean = np.mean(errs_constrained, axis=1)
errs_unconstrained_mean = np.mean(errs_unconstrained, axis=1)
errs_constrained_std = np.std(errs_constrained, axis=1)
errs_unconstrained_std = np.std(errs_unconstrained, axis=1)

print(errs_constrained_mean)
print(errs_unconstrained_mean)
print(errs_constrained_std)
print(errs_unconstrained_std)

print('done')

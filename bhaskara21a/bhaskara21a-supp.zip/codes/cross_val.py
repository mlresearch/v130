import numpy as np
import random as rand
import matplotlib
import matplotlib.pyplot as plt
import sklearn.datasets as ds
from sklearn.linear_model import LinearRegression as LR
from sklearn.preprocessing import StandardScaler
from sklearn.utils.extmath import randomized_svd
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
from cvxpy import *
from scipy.stats import bernoulli, ortho_group

rng = np.random.RandomState(seed=42)

def gen_mask(m, n, prob_masked=0.5, rng = np.random.RandomState(seed=42)):
    return bernoulli.rvs(p=prob_masked, size=(m, n), random_state=rng)

def gen_factorization_with_noise_orth_rand(m, n, k, sigma = 1 , s = 10, rng = np.random.RandomState(seed=42)):
    U = ortho_group.rvs(m, 1, rng)[:, :k].reshape((m, k))
    V = ortho_group.rvs(n, 1, rng)[:, :k].reshape((n, k))
    S = [s]
    cur = s
    for i in range(1, k):
      S += [cur * 0.5]
      cur = cur * 0.5
    S = S/np.linalg.norm(S, 2)
    S = np.diag(S)
    N = rng.randn(m, n) * sigma #gen_noise(m, n, sigma, rng)
    R = N + np.dot(np.dot(U, S), V.T) #rng.randn(m, n) * sigma + np.dot(np.dot(U, S), V.T)
    return U, S, V, R

def nuclear_norm_solve_constrained_individual_delta(A, mask, delta = 10.0):
    X = Variable(shape=A.shape)
    objective = Minimize(norm(X,"nuc"))
    # constraint = [max(pow(multiply(mask, X - A), 2)) <= delta**2]
    constraint = []
    for i in range(A.shape[0]):
      for j in range(A.shape[1]):
        if mask[i,j]:
          constraint += [atoms.elementwise.abs.abs(X[i,j]-A[i,j]) <= delta]
    problem = Problem(objective, constraint)
    problem.solve(solver=SCS)
    return X.value

def semi_randomize_mask(mask, col_frac=0.9, row_frac=0.9, rnd=True, rng=np.random.RandomState(seed=42)):
    """If rnd=True, randomly choose fractions of given columns and rows,
       Otherwise choose first fraction of columns and rows"""
    m = mask.shape[0]
    n = mask.shape[1]
    new_mask = mask.copy()
    if rnd:
      rows = rng.choice(np.arange(m), int(row_frac*m), replace=False)
      for row in rows:
        cols = rng.choice(np.arange(n), int(col_frac*n), replace=False)
        for col in cols:
          new_mask[row, col] = 1
      return new_mask
    else:
      rows = np.arange(int(m*row_frac))
      for row in rows:
        cols = np.arange(int(n*col_frac))
        for col in cols:
          new_mask[row, col] = 1
      return new_mask

def compute_hsvt(A, mask, r=1):
    A_ = np.multiply(A, mask)/(np.sum(mask)/(mask.shape[0]*mask.shape[1]))
    # A_ = np.multiply(A, mask)
    U, S, Vt = np.linalg.svd(A_)
    return np.dot(np.dot(U[:, :r], np.diag(S[:r])), Vt[:r, :])

# first try for a single iteration

# generate data
m, n = 200, 100
k = 100
sigma = 0.0001
s = 10
p = 0.4
U, S, V, R = gen_factorization_with_noise_orth_rand(m, n, k, sigma, s, rng)
M_star = np.dot(np.dot(U, S), V.T)
_, S_, _ = np.linalg.svd(R)
plt.plot(np.arange(1, 21), S_[:20])
plt.show()

beta_star = rng.randn(n)
Y = np.matmul(M_star, beta_star)

# split
train_size = 100
X_train, Y_train = R[:train_size, :], Y[:train_size]
X_test, Y_test = R[train_size:, :], Y[train_size:]
print(X_train.shape, Y_train.shape)
print(X_test.shape, Y_test.shape)

# training
m, n = X_train.shape[0], X_train.shape[1]
delta_inf =  4 * sigma * np.sqrt(np.log(n))
mask = gen_mask(m, n, p, rng)
mask_sr = semi_randomize_mask(mask, 0.9, 0.3, False, rng)

R_hat_NNM_sr = nuclear_norm_solve_constrained_individual_delta(X_train, mask_sr, delta_inf)
_, S_, _ = np.linalg.svd(R_hat_NNM_sr)
plt.plot(np.arange(1, 11), S_[:10])
plt.show()

# get low rank approximation of the recovered
rank = 5      # 5 seems to be good
U, S, VT = randomized_svd(R_hat_NNM_sr, rank)
X_train_nnm =  np.dot(U[:,:rank], np.dot(np.diag(S)[:rank,:rank], VT[:rank,:]))

# compute hsvt as well for this rank
X_train_hsvt = compute_hsvt(X_train, mask_sr, rank)

# train regression
# nnm
lr_nnm = LR()
lr_nnm.fit(X_train_nnm, Y_train)
lr_predicted_on_train_nnm = lr_nnm.predict(X_train)
err_train_nnm = np.linalg.norm(lr_predicted_on_train_nnm-Y_train, ord=2)/float(X_train.shape[0])
# hsvt
lr_hsvt = LR()
lr_hsvt.fit(X_train_hsvt, Y_train)
lr_predicted_on_train_hsvt = lr_hsvt.predict(X_train)
err_train_hsvt = np.linalg.norm(lr_predicted_on_train_hsvt-Y_train, ord=2)/float(X_train.shape[0])

print('nnm train error: ', err_train_nnm)
print('hsvt train error: ', err_train_hsvt)

# test regreesion
lr_predicted_on_test_nnm = lr_nnm.predict(X_test)
lr_predicted_on_test_hsvt = lr_hsvt.predict(X_test)
err_test_nnm = np.linalg.norm(lr_predicted_on_test_nnm-Y_test, ord=2)/float(X_test.shape[0])
err_test_hsvt = np.linalg.norm(lr_predicted_on_test_hsvt-Y_test, ord=2)/float(X_test.shape[0])

print('nnm test error: ', err_test_nnm)
print('hsvt test error: ', err_test_hsvt)


# Average results over 5 iterations

n_iter = 5
m, n = 200, 100
k = 100
sigma = 0.0001
s = 10
p = 0.4
train_size = 100

errs_train_nnm, errs_train_hsvt, errs_test_nnm, errs_test_hsvt = [], [], [], []
S_values_of_recovered = []

for i in range(n_iter):
  U, S, V, R = gen_factorization_with_noise_orth_rand(m, n, k, sigma, s, rng)
  M_star = np.dot(np.dot(U, S), V.T)

  beta_star = rng.randn(n)
  Y = np.matmul(M_star, beta_star)
  
  X_train, Y_train = R[:train_size, :], Y[:train_size]
  X_test, Y_test = R[train_size:, :], Y[train_size:]

  delta_inf =  4 * sigma * np.sqrt(np.log(X_train.shape[1]))
  mask = gen_mask(X_train.shape[0], X_train.shape[1], p, rng)
  mask_sr = semi_randomize_mask(mask, 0.9, 0.3, False, rng)

  R_hat_NNM_sr = nuclear_norm_solve_constrained_individual_delta(X_train, mask_sr, delta_inf)
  _, S_, _ = np.linalg.svd(R_hat_NNM_sr)
  S_values_of_recovered.append(S_)

  rank = 5
  U, S, VT = randomized_svd(R_hat_NNM_sr, rank)
  X_train_nnm =  np.dot(U[:,:rank], np.dot(np.diag(S)[:rank,:rank], VT[:rank,:]))
  X_train_hsvt = compute_hsvt(X_train, mask_sr, rank)

  lr_nnm = LR()
  lr_nnm.fit(X_train_nnm, Y_train)
  lr_predicted_on_train_nnm = lr_nnm.predict(X_train)
  err_train_nnm = np.linalg.norm(lr_predicted_on_train_nnm-Y_train, ord=2)/float(X_train.shape[0])
  lr_hsvt = LR()
  lr_hsvt.fit(X_train_hsvt, Y_train)
  lr_predicted_on_train_hsvt = lr_hsvt.predict(X_train)
  err_train_hsvt = np.linalg.norm(lr_predicted_on_train_hsvt-Y_train, ord=2)/float(X_train.shape[0])

  lr_predicted_on_test_nnm = lr_nnm.predict(X_test)
  lr_predicted_on_test_hsvt = lr_hsvt.predict(X_test)
  err_test_nnm = np.linalg.norm(lr_predicted_on_test_nnm-Y_test, ord=2)/float(X_test.shape[0])
  err_test_hsvt = np.linalg.norm(lr_predicted_on_test_hsvt-Y_test, ord=2)/float(X_test.shape[0])

  errs_train_nnm.append(err_train_nnm)
  errs_train_hsvt.append(err_train_hsvt)
  errs_test_nnm.append(err_test_nnm)
  errs_test_hsvt.append(err_test_hsvt)

  print('iteration: ', i, ' done.')

errs_train_nnm_mean = np.mean(errs_train_nnm)
errs_train_hsvt_mean = np.mean(errs_train_hsvt)
errs_test_nnm_mean = np.mean(errs_test_nnm)
errs_test_hsvt_mean = np.mean(errs_test_hsvt)

errs_train_nnm_std = np.std(errs_train_nnm)
errs_train_hsvt_std = np.std(errs_train_hsvt)
errs_test_nnm_std = np.std(errs_test_nnm)
errs_test_hsvt_std = np.std(errs_test_hsvt)

S_values_of_recovered = np.array(S_values_of_recovered)
S_mean = np.mean(S_values_of_recovered, axis=0)
S_std = np.std(S_values_of_recovered, axis=0)

print(errs_train_nnm_mean)
print(errs_train_hsvt_mean)
print(errs_test_nnm_mean)
print(errs_test_hsvt_mean)
print(errs_train_nnm_std)
print(errs_train_hsvt_std)
print(errs_test_nnm_std)
print(errs_test_hsvt_std)
print(' ')

top_s = 10
print(S_mean[:top_s])
print(S_std[:top_s])

plt.errorbar(np.arange(1, 11), S_mean[:top_s], S_std[:top_s])
plt.show()


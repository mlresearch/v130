import numpy as np
import random as rand
import matplotlib
import matplotlib.pyplot as plt
import sklearn.datasets as ds
from sklearn.linear_model import LinearRegression as LR
from sklearn.preprocessing import StandardScaler
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
from cvxpy import *
from scipy.stats import bernoulli, ortho_group

rng = np.random.RandomState(seed=42)

def gen_mask(m, n, prob_masked=0.5, rng = np.random.RandomState(seed=42)):
    return bernoulli.rvs(p=prob_masked, size=(m, n), random_state=rng)

def gen_factorization_with_noise_orth_rand(m, n, k, sigma = 1 , s = 10, rng = np.random.RandomState(seed=42)):
    U = ortho_group.rvs(m, 1, rng)[:, :k].reshape((m, k))
    V = ortho_group.rvs(n, 1, rng)[:, :k].reshape((n, k))
    S = np.diag(np.ones(k)*s)
    N = rng.randn(m, n) * sigma #gen_noise(m, n, sigma, rng)
    R = N + np.dot(np.dot(U, S), V.T) #rng.randn(m, n) * sigma + np.dot(np.dot(U, S), V.T)
    return U, S, V, R

def nuclear_norm_solve_unconstrained(A, mask, lmbda = 10.0):
    X = Variable(shape=A.shape)
    # objective = Minimize(lmbda*norm(X,"nuc") + 0.5*sum(pow(multiply(mask, X - A), 2)))
    objective = Minimize(norm(X,"nuc") + (0.5/float(lmbda))*sum(pow(multiply(mask, X - A), 2)))
    problem = Problem(objective)
    problem.solve(solver=SCS)
    return X.value

def nuclear_norm_solve_constrained_frob_delta(A, mask, delta = 10.0):
    X = Variable(shape=A.shape)
    objective = Minimize(norm(X,"nuc"))
    constraint = [sum(pow(multiply(mask, X - A), 2)) <= delta**2]
    problem = Problem(objective, constraint)
    problem.solve(solver=SCS)
    return X.value

def nuclear_norm_solve_constrained_individual_delta(A, mask, delta = 10.0):
    X = Variable(shape=A.shape)
    objective = Minimize(norm(X,"nuc"))
    # constraint = [max(pow(multiply(mask, X - A), 2)) <= delta**2]
    constraint = []
    for i in range(A.shape[0]):
      for j in range(A.shape[1]):
        if mask[i,j]:
          constraint += [atoms.elementwise.abs.abs(X[i,j]-A[i,j]) <= delta]
    problem = Problem(objective, constraint)
    problem.solve(solver=SCS)
    return X.value


def compute_hsvt(A, mask, r=1):
    A_ = np.multiply(A, mask)/(np.sum(mask)/(mask.shape[0]*mask.shape[1]))
    # A_ = np.multiply(A, mask)
    U, S, Vt = np.linalg.svd(A_)
    return np.dot(np.dot(U[:, :r], np.diag(S[:r])), Vt[:r, :])

def calc_cost_frob(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.linalg.norm((pred - truth), 'fro')
    return cost

def calc_cost_nuc(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.linalg.norm((pred - truth), 'nuc')
    return cost

def calc_cost_spectral(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.linalg.norm((pred - truth), 2)
    return cost

def calc_cost_max(U, S, V, A_hat):
    pred = A_hat
    truth = np.dot(np.dot(U, S), V.T)
    cost = np.max(np.abs(pred - truth))
    return cost

def semi_randomize_mask(mask, col_frac=0.9, row_frac=0.9, rnd=True,):
    """If rnd=True, randomly choose fractions of given columns and rows,
       Otherwise choose first fraction of columns and rows"""
    m = mask.shape[0]
    n = mask.shape[1]
    new_mask = mask.copy()
    if rnd:
      rows = rng.choice(np.arange(m), int(row_frac*m), replace=False)
      for row in rows:
        cols = rng.choice(np.arange(n), int(col_frac*n), replace=False)
        for col in cols:
          new_mask[row, col] = 1
      return new_mask
    else:
      rows = np.arange(int(m*row_frac))
      for row in rows:
        cols = np.arange(int(n*col_frac))
        for col in cols:
          new_mask[row, col] = 1
      return new_mask

def semi_randomize_mask_adverse(mask, E, l):
    """open highest noise elements"""
    m = mask.shape[0]
    n = mask.shape[1]
    remaining = np.ones((m,n)) - mask
    unmasked_E = np.abs(np.multiply(remaining, E))
    picked = np.argsort(unmasked_E, axis=None)[-l:]
    new_mask = np.zeros((m, n)).flatten()
    new_mask[picked] = 1
    new_mask = new_mask.reshape((m, n))
    new_mask = mask + new_mask
    return new_mask

def semi_randomize_mask_positive_noise(mask, E):
    """open elements with positive noise"""
    pos = E > 0
    new_mask = np.logical_or(mask, pos).astype(int)
    return new_mask
    
    
# Generate synthetic dataset
n = 100
r = 5
sigma = 10**(-9)
M_star = np.inner(rng.randn(n,r),rng.randn(n,r))
M = M_star + sigma*rng.randn(n, n)
beta_star = rng.randn(n) 
Y = np.matmul(M_star,beta_star)
r = np.linalg.matrix_rank(M_star)

# k = 1
p = 0.3
k = 1
s = 1
n_iter = 5
Y_HSVT_sr_Te = np.array([np.array([0 for i in range(np.size(Y))]) for i in range(n_iter)])
Y_HSVT_Te = np.array([np.array([0 for i in range(np.size(Y))]) for i in range(n_iter)])
Y_NNM_sr_Te = np.array([np.array([0 for i in range(np.size(Y))]) for i in range(n_iter)])
Y_NNM_Te = np.array([np.array([0 for i in range(np.size(Y))]) for i in range(n_iter)])
delta_inf =  4 * sigma * np.sqrt(np.log(n)) 
lmbda = 5 * sigma * np.sqrt(n*p)
print('delta inf: ', delta_inf)
print('lambda: ', lmbda)
R_star = M_star
R = M
for i in range(n_iter): 
  print('Iteration',i+1)
  mask = gen_mask(n, n, p, rng)
  R_hat_NNM = nuclear_norm_solve_constrained_individual_delta(R, mask, delta_inf)
  R_hat_HSVT = compute_hsvt(R, mask, r=5)
  mask_sr = semi_randomize_mask(mask)
  R_hat_NNM_sr = nuclear_norm_solve_constrained_individual_delta(R, mask_sr, delta_inf)
  R_hat_HSVT_sr = compute_hsvt(R, mask_sr, r=5)
  
  lr_HSVT = LR()
  lr_HSVT.fit(R_hat_HSVT,Y)
  lr_NNM = LR()
  lr_NNM.fit(R_hat_NNM,Y)
  Y_HSVT_train = lr_HSVT.predict(R)
  Y_HSVT_Te[i] = Y_HSVT_train
  Y_NNM_train = lr_NNM.predict(R)
  Y_NNM_Te[i] = Y_NNM_train
  
  lr_HSVT_sr = LR()
  lr_HSVT_sr.fit(R_hat_HSVT_sr,Y)
  lr_NNM_sr = LR()
  lr_NNM_sr.fit(R_hat_NNM_sr,Y)
  Y_HSVT_sr_train = lr_HSVT_sr.predict(R)
  Y_HSVT_sr_Te[i] = Y_HSVT_sr_train
  Y_NNM_sr_train = lr_NNM_sr.predict(R)
  Y_NNM_sr_Te[i] = Y_NNM_sr_train

Y_HSVT = np.mean(Y_HSVT_Te,0)
Y_NNM = np.mean(Y_NNM_Te,0)
Y_HSVT_sr = np.mean(Y_HSVT_sr_Te,0)
Y_NNM_sr = np.mean(Y_NNM_sr_Te,0)

p = 0.5
k = 1
s = 1
n_iter = 5
sigma_list = np.array([0.0001, 0.0005, 0.001, 0.0015, 0.002])*0.1
print(sigma_list)
errs_constrained_rand = np.zeros((len(sigma_list), n_iter))
errs_hsvt_rand = np.zeros((len(sigma_list), n_iter))
errs_constrained_semirand = np.zeros((len(sigma_list), n_iter))
errs_hsvt_semirand = np.zeros((len(sigma_list), n_iter))
for i, sigma in enumerate(sigma_list):
  delta_inf =  4 * sigma * np.sqrt(np.log(n)) 
  print('delta inf: ', delta_inf)
  for j in range(n_iter):    
    R_star = M_star
    R = R_star + sigma*rng.randn(n,n)
    mask = gen_mask(n, n, p, rng)
    R_hat_constrained_rand = nuclear_norm_solve_constrained_individual_delta(R, mask, delta_inf)
    R_hat_hsvt_rand = compute_hsvt(R, mask, r=5)
    mask_sr = semi_randomize_mask(mask, 0.1, 1.0, False)
    R_hat_constrained_semirand = nuclear_norm_solve_constrained_individual_delta(R, mask_sr, delta_inf)
    R_hat_hsvt_semirand = compute_hsvt(R, mask_sr, r=5)
    lr_constrained_rand = LR()
    lr_constrained_semirand = LR()
    lr_hsvt_rand = LR()
    lr_hsvt_semirand = LR()
    lr_constrained_rand.fit(R_hat_constrained_rand,Y)
    lr_constrained_semirand.fit(R_hat_constrained_semirand,Y)
    lr_hsvt_rand.fit(R_hat_hsvt_rand,Y)
    lr_hsvt_semirand.fit(R_hat_hsvt_semirand,Y)
    Y_constrained_rand = lr_constrained_rand.predict(R)
    Y_constrained_semirand = lr_constrained_semirand.predict(R)
    Y_hsvt_rand = lr_hsvt_rand.predict(R)
    Y_hsvt_semirand = lr_hsvt_semirand.predict(R)  
    errs_constrained_rand[i, j] = np.linalg.norm(Y_constrained_rand-Y,ord=2)
    errs_constrained_semirand[i, j] = np.linalg.norm(Y_constrained_semirand-Y,ord=2)
    errs_hsvt_rand[i, j] = np.linalg.norm(Y_hsvt_rand-Y,ord=2)
    errs_hsvt_semirand[i, j] = np.linalg.norm(Y_hsvt_semirand-Y,ord=2)
  print('sigma: ', sigma, ' done.')

errs_constrained_rand = errs_constrained_rand/float(n)
errs_constrained_semirand = errs_constrained_semirand/float(n)
errs_hsvt_rand = errs_hsvt_rand/float(n)
errs_hsvt_semirand =errs_hsvt_semirand/float(n)

errs_constrained_rand_mean = np.mean(errs_constrained_rand, axis=1)
errs_hsvt_rand_mean = np.mean(errs_hsvt_rand, axis=1)
errs_constrained_semirand_mean = np.mean(errs_constrained_semirand, axis=1)
errs_hsvt_semirand_mean = np.mean(errs_hsvt_semirand, axis=1)
errs_constrained_rand_std = np.std(errs_constrained_rand, axis=1)
errs_hsvt_rand_std = np.std(errs_hsvt_rand, axis=1)
errs_constrained_semirand_std = np.std(errs_constrained_semirand, axis=1)
errs_hsvt_semirand_std = np.std(errs_hsvt_semirand, axis=1)

print(errs_constrained_rand_mean)
print(errs_hsvt_rand_mean)
print(errs_constrained_semirand_mean)
print(errs_hsvt_semirand_mean)
print(errs_constrained_rand_std)
print(errs_hsvt_rand_std)
print(errs_constrained_semirand_std)
print(errs_hsvt_semirand_std)


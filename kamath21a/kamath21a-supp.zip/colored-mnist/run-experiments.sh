#!/usr/bin/env bash

# Script to run a grid of experiments for main.py.
# Fills in results-nll, results-square to be processed with plot-results.ipynb.
# Amenable to running more than one in parallel without duplicating work,
# just set CUDA_VISIBLE_DEVICES.
# (Across machines on a slower shared filesystem, might duplicate sometimes.)
# Tries to clean up after itself if a run crashed or whatever,
# but if the notebook complains about a bad file (that isn't currently running),
# delete it and run this script again.

# By Danica J. Sutherland. Licensed under CC BY-NC 4.0; see main.py.


PYTHON=${PYTHON:-python}

cd $(dirname $0)

i=0

for steps in 501; do
  for rep in $(seq 100); do
    for arch in split normal; do
      if [[ $arch == split ]]; then
        archargs="--split-arch";
      else
        archargs="";
      fi

      for invariant in digit color; do
        for loss in nll square; do
          if [[ $loss == nll ]]; then
            lossargs="--logistic";
            types=(good 05)
          else
            lossargs="--square-loss";
            types=(good 10)
          fi

          for type in "${types[@]}"; do
            if [[ $type == good ]]; then
              p_base=0.25;
              p1=0.1;
              p2=0.2;
              ptest=0.9;
            elif [[ $loss == square ]]; then
              if [[ $type == 10 ]]; then
                p_base=0.1;
                p1=0.2;
                p2=0.25;
              else
                echo "??? - $loss $type"
                exit -1
              fi
              ptest=0.9;
            else
              if [[ $type == 05 ]]; then
                p_base=0.05;
                p1=0.1;
                p2=0.2;
                ptest=0.9;
              else
                echo "??? - $loss $type"
                exit -1
              fi
            fi
            if [[ $invariant == digit ]]; then
              envargs="--train-envs=(($p_base,$p1),($p_base,$p2)) --test-envs=(($p_base,$ptest),)"
            else
              envargs="--train-envs=(($p1,$p_base),($p2,$p_base)) --test-envs=(($ptest,$p_base),)"
            fi

            for algo in irmv1 erm grayscale coloronly; do
              if [[ $algo == irmv1 ]]; then
                algoargs="--random-params"
              elif [[ $algo == erm ]]; then
                algoargs="--random-params --no-penalty"
              elif [[ $algo == grayscale ]]; then
                algoargs="--random-params --grayscale-model"
              else
                algoargs="--random-params --color-only-model"
              fi

              fn=results_${loss}/${invariant}-${type}/${algo}-${arch}/${steps}/${rep}.txt

              ((i++))
              if [[ ! -e $fn ]]; then
                echo "$i: $fn"
                mkdir -p $(dirname $fn)
                if ! $PYTHON main.py $algoargs $lossargs $archargs $envargs --n-restarts 1 --steps $steps > $fn; then
                  echo "ERROR. will dump command output, delete the remnant, then crash" >&2
                  cat $fn >&2
                  rm $fn
                  exit 1
                fi
              fi
            done
          done
        done
      done
    done
  done
done

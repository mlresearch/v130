#!/usr/bin/env python

# This file was modified from
# https://github.com/facebookresearch/InvariantRiskMinimization/blob/fc185d0f828a98f57030ba3647efc7394d1be95a/code/colored_mnist/main.py
# (by Martin Arjovsky, Leon Bottou, Ishaan Gulrajani, and David Lopez-Paz);
# modifications by Danica J. Sutherland.
# The license mentioned in the below is CC BY-NC 4.0:
#    https://creativecommons.org/licenses/by-nc/4.0/


# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.


import argparse
from ast import literal_eval

import numpy as np
import torch
from torchvision import datasets
from torch import nn, optim, autograd

parser = argparse.ArgumentParser(description="Colored MNIST")


class SetRandomsAction(argparse.Action):
    def __init__(self, option_strings, dest, nargs=None, **kwargs):
        super().__init__(
            option_strings, nargs=0, dest="hidden_dim", default=256, **kwargs
        )

    def __call__(self, parser, namespace, values, option_string=None):
        namespace.hidden_dim = int(2 ** np.random.uniform(6, 9))
        namespace.l2_regularizer_weight = 10 ** np.random.uniform(-2, -5)
        namespace.lr = 10 ** np.random.uniform(-2.5, -3.5)
        namespace.penalty_anneal_iters = np.random.randint(50, 250)
        namespace.penalty_weight = 10 ** np.random.uniform(2, 6)


parser.add_argument("--random-params", action=SetRandomsAction)

parser.add_argument("--hidden_dim", "--hidden-dim", type=int, default=256)
parser.add_argument(
    "--l2_regularizer_weight", "--l2-regularizer-weight", type=float, default=0.001
)
parser.add_argument("--lr", type=float, default=0.001)
parser.add_argument("--n_restarts", "--n-restarts", type=int, default=10)

parser.add_argument(
    "--nll",
    "--logistic",
    "--cross-entropy",
    dest="loss",
    action="store_const",
    const="nll",
    default="nll",
)
parser.add_argument(
    "--square-loss", "--squared-loss", dest="loss", action="store_const", const="square"
)

parser.add_argument(
    "--penalty_anneal_iters", "--penalty-anneal-iters", type=int, default=100
)
parser.add_argument("--penalty_weight", "--penalty-weight", type=float, default=10000.0)


class NoPenaltyAction(argparse.Action):
    def __init__(self, option_strings, dest, nargs=None, **kwargs):
        super().__init__(
            option_strings, dest="penalty_weight", default=10000.0, nargs=0, **kwargs
        )

    def __call__(self, parser, namespace, values, option_string=None):
        namespace.penalty_weight = 0
        namespace.penalty_anneal_iters = 0


parser.add_argument("--no_penalty", "--no-penalty", action=NoPenaltyAction)

parser.add_argument("--steps", type=int, default=501)
parser.add_argument("--split_arch", "--split-arch", action="store_true")

g = parser.add_mutually_exclusive_group()
g.add_argument("--grayscale_model", "--grayscale-model", action="store_true")
g.add_argument("--color-only-model", action="store_true")

parser.add_argument(
    "--shuffler-seed", type=int, default=np.random.SeedSequence().entropy
)

parser.add_argument(
    "--unbiased_gradient", "--unbiased-gradient", action="store_true", default=False
)
parser.add_argument(
    "--biased_gradient",
    "--biased-gradient",
    action="store_false",
    dest="unbiased_gradient",
)

parser.add_argument(
    "--train_envs",
    "--train-envs",
    type=literal_eval,
    default="((0.25,0.2), (0.25,0.1))",
)
parser.add_argument(
    "--test_envs", "--test-envs", type=literal_eval, default="((0.25,0.9),)"
)
flags = parser.parse_args()

print("Flags:")
for k, v in sorted(vars(flags).items()):
    print("\t{}: {}".format(k, v))

final_train_accs = []
final_test_accs = []

for restart in range(flags.n_restarts):
    print("Restart", restart)

    # Load MNIST, make train/val splits, and shuffle train set examples

    mnist = datasets.MNIST("~/datasets/mnist", train=True, download=True)
    mnist_train = (mnist.data[:50000], mnist.targets[:50000])
    mnist_val = (mnist.data[50000:], mnist.targets[50000:])

    # shuffle Xs
    rng = np.random.default_rng(flags.shuffler_seed + restart)
    rng.shuffle(mnist_train[0].numpy())
    rng.shuffle(mnist_val[0].numpy())

    # shuffle Ys in the same order
    rng = np.random.default_rng(flags.shuffler_seed + restart)
    rng.shuffle(mnist_train[1].numpy())
    rng.shuffle(mnist_val[1].numpy())

    # Build environments

    def make_environment(images, labels, label_flip, color_flip):
        def torch_bernoulli(p, size):
            return (torch.rand(size) < p).float()

        def torch_xor(a, b):
            return (a - b).abs()  # Assumes both inputs are either 0 or 1

        # 2x subsample for computational convenience
        images = images.reshape((-1, 28, 28))[:, ::2, ::2]

        # Assign a binary label based on the digit; flip label with probability label_flip
        labels = digit_labels = (labels < 5).float()
        labels = torch_xor(labels, torch_bernoulli(label_flip, len(labels)))

        # Assign a color based on the label; flip the color with probability color_flip
        colors = torch_xor(labels, torch_bernoulli(color_flip, len(labels)))

        # Apply the color to the image by zeroing out the other color channel
        images = torch.stack([images, images], dim=1)
        images[torch.tensor(range(len(images))), (1 - colors).long(), :, :] *= 0
        return {
            "images": (images.float() / 255.0).cuda(),
            "labels": labels[:, None].cuda(),
            "digit_labels": digit_labels[:, None].cuda(),
            "colors": colors[:, None].cuda(),
        }

    n_train_e = len(flags.train_envs)
    train_envs = [
        make_environment(
            mnist_train[0][i::n_train_e], mnist_train[1][i::n_train_e], l, c
        )
        for i, (l, c) in enumerate(flags.train_envs)
    ]
    n_test_e = len(flags.test_envs)
    test_envs = [
        make_environment(mnist_val[0][i::n_test_e], mnist_val[1][i::n_test_e], l, c)
        for i, (l, c) in enumerate(flags.test_envs)
    ]
    envs = train_envs + test_envs

    # Define and instantiate the model

    class MLP(nn.Module):
        def __init__(self):
            super(MLP, self).__init__()
            if flags.grayscale_model:
                lin1 = nn.Linear(14 * 14, flags.hidden_dim)
            elif flags.color_only_model:
                lin1 = nn.Linear(2, flags.hidden_dim)
            else:
                lin1 = nn.Linear(2 * 14 * 14, flags.hidden_dim)
            lin2 = nn.Linear(flags.hidden_dim, flags.hidden_dim)
            lin3 = nn.Linear(flags.hidden_dim, 1)
            for lin in [lin1, lin2, lin3]:
                nn.init.xavier_uniform_(lin.weight)
                nn.init.zeros_(lin.bias)
            self._main = nn.Sequential(lin1, nn.ReLU(True), lin2, nn.ReLU(True), lin3)

        def forward(self, input):
            if flags.grayscale_model:
                out = input.view(input.shape[0], 2, 14 * 14).sum(dim=1)
            elif flags.color_only_model:
                out = input.sum(dim=(2, 3)).sign().float()
            else:
                out = input.view(input.shape[0], 2 * 14 * 14)
            out = self._main(out)
            return out

    class SplitMLP(nn.Module):
        def __init__(self):
            super().__init__()

            if not flags.color_only_model:
                self.img_branch = nn.Sequential(
                    nn.Linear(14 * 14, flags.hidden_dim),
                    nn.ReLU(True),
                    nn.Linear(flags.hidden_dim, flags.hidden_dim),
                    nn.ReLU(True),
                    nn.Linear(flags.hidden_dim, 1),
                )

            if not flags.grayscale_model:
                self.color_branch = nn.Linear(2, 1)

            self.top_net = nn.Sequential(
                nn.Linear(1 if flags.color_only_model or flags.grayscale_model else 2, 8),
                nn.ReLU(True),
                nn.Linear(8, 1),
            )

        def forward(self, input):
            to_top = []

            if not flags.color_only_model:
                gray = input.view(input.shape[0], 2, 14 * 14).sum(dim=1)
                to_top.append(self.img_branch(gray))

            if not flags.grayscale_model:
                colors = input.sum(dim=(2, 3)).sign().float()
                to_top.append(self.color_branch(colors))

            return self.top_net(torch.cat(to_top, dim=1))

    mlp = (SplitMLP() if flags.split_arch else MLP()).cuda()

    # Define loss function helpers

    if flags.loss == "nll":

        def mean_loss(logits, y):
            return nn.functional.binary_cross_entropy_with_logits(logits, y)

    elif flags.loss == "square":

        def mean_loss(logits, y):
            # y is 0/1; we want to treat it as -1/1, so use 2 y - 1
            return (logits - (2 * y - 1)).square().mean() / 2

    else:
        raise ValueError(f"bad loss value {flags.loss}")

    def mean_accuracy(preds, y):
        return ((preds - y).abs() < 1e-2).float().mean()

    def penalty(logits, y):
        scale = torch.tensor(1.0).cuda().requires_grad_()
        if flags.unbiased_gradient:
            n_end = -1 if len(logits) % 2 == 1 else None
            (g1,) = autograd.grad(
                mean_loss(logits[0:n_end:2] * scale, y[0:n_end:2]),
                [scale],
                create_graph=True,
            )
            (g2,) = autograd.grad(
                mean_loss(logits[1:n_end:2] * scale, y[1:n_end:2]),
                [scale],
                create_graph=True,
            )
            return torch.sum(g1 * g2)
        else:
            (g,) = autograd.grad(
                mean_loss(logits * scale, y), [scale], create_graph=True
            )
            return torch.sum(g ** 2)

    # Train loop

    cols = [
        (6, ">6d", "step"),
        (9 * len(train_envs), "8.5f", "train loss"),
        (7 * len(train_envs), ">6.1%", "train accs"),
        (9 * len(train_envs), ">8.2e", "train penalties"),
        (max(9, 7 * len(test_envs)), "8.5f", "test loss"),
        (max(9, 7 * len(test_envs)), ">6.1%", "test accs"),
        (7 * len(envs), ">6.1%", "match color"),
        (7 * len(envs), ">6.1%", "match digit"),
    ]

    def pretty_print(*values):
        def format_val(v, fmt, col_width):
            if not isinstance(v, str):
                v = np.atleast_1d(v)
                v = " ".join(f"{x:{fmt}}" for x in v)
                # v = np.array2string(v, precision=5, floatmode="fixed")
            return v.ljust(col_width)

        str_values = [format_val(v, fmt, w) for v, (w, fmt, n) in zip(values, cols)]
        print("   ".join(str_values))

    optimizer = optim.Adam(mlp.parameters(), lr=flags.lr)

    pretty_print(*(n for w, f, n in cols))

    for step in range(flags.steps):
        for env in envs:
            logits = mlp(env["images"])
            env["loss"] = mean_loss(logits, env["labels"])
            env["preds"] = (logits > 0).float()
            env["acc"] = mean_accuracy(env["preds"], env["labels"])
            env["matched_color"] = mean_accuracy(env["preds"], env["colors"])
            env["matched_digit"] = mean_accuracy(env["preds"], env["digit_labels"])
            env["penalty"] = penalty(logits, env["labels"])

        train_loss = torch.stack([e["loss"] for e in train_envs]).mean()
        train_acc = torch.stack([e["acc"] for e in train_envs]).mean()
        train_penalty = torch.stack([e["penalty"] for e in train_envs]).mean()

        weight_norm = torch.tensor(0.0).cuda()
        for w in mlp.parameters():
            weight_norm += w.norm().pow(2)

        loss = train_loss.clone()
        loss += flags.l2_regularizer_weight * weight_norm
        penalty_weight = (
            flags.penalty_weight if step >= flags.penalty_anneal_iters else 1.0
        )
        loss += penalty_weight * train_penalty
        if penalty_weight > 1.0:
            # Rescale the entire loss to keep gradients in a reasonable range
            loss /= penalty_weight

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        test_accs = torch.stack([e["acc"] for e in test_envs])
        test_acc = test_accs.mean()
        if step % 100 == 0:
            pretty_print(
                int(step),
                torch.stack([e["loss"].detach().cpu() for e in train_envs]).numpy(),
                torch.stack([e["acc"].detach().cpu() for e in train_envs]).numpy(),
                torch.stack([e["penalty"].detach().cpu() for e in train_envs]).numpy(),
                torch.stack([e["loss"].detach().cpu() for e in test_envs]).numpy(),
                test_accs.detach().cpu().numpy(),
                torch.stack([e["matched_color"].detach().cpu() for e in envs]).numpy(),
                torch.stack([e["matched_digit"].detach().cpu() for e in envs]).numpy(),
            )

    final_train_accs.append(train_acc.detach().cpu().numpy())
    final_test_accs.append(test_acc.detach().cpu().numpy())
    print("Final train acc (mean/std across restarts so far):")
    print(np.mean(final_train_accs), np.std(final_train_accs))
    print("Final test acc (mean/std across restarts so far):")
    print(np.mean(final_test_accs), np.std(final_test_accs))

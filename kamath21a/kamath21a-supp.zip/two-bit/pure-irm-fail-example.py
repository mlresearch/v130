#!/usr/bin/env python3

# Author : Pritish Kamath

import sys
import numpy as np
import sympy
from sympy.abc import x

'''
	Symbol x denotes 'theta' (notation from the paper)
	For symbolic accuracy:
		- probabilities are multiplied by 3
		- E[Y | X=x] is multiplied by 30
	This affects the conditional expectation by factor 30.
	Both are indexed according to the following convention:
	0 = (-1,-1)		1 = ( 0,-1)		2 = (+1,-1)
	3 = (-1, 0)		4 = ( 0, 0)		5 = (+1, 0)
	6 = (-1,+1)		7 = ( 0,+1)		8 = (+1,+1)
'''

probs = [1-3*x, 1-3*x, 1-3*x,
         1+6*x, 1+6*x, 1+6*x,
         1-3*x, 1-3*x, 1-3*x]
funct = [-18+30*x*x+20*x, -9+60*x*x-20*x,  -90*x*x,
         -9+60*x*x-20*x,  0,               9+20*x-60*x*x,
         90*x*x,          9+20*x-60*x*x,   18-30*x*x-20*x]


def CondEx(mask):
	'''
	Compute symbolic conditional expectation:
	E[Y | X in S]
	where 'mask' = indicator-vector(S)
	'''
	Num = sum([e[0]*e[1]*e[2] for e in zip(probs,funct,mask)])
	Den = sum([e[0]*e[1] for e in zip(probs,mask)])
	return sympy.simplify(Num/Den)

def Enum_Masks(k,include_empty=False):
	'''
	Generate all possible sets of size k
	include_empty : whether to include the empty set or not
	'''
	if k==1:
		return [[0], [1]] if include_empty else [[1]]
	masks = Enum_Masks(k-1,True)
	ans = [[0]+e for e in masks] + [[1]+e for e in masks]
	if not include_empty:
		ans.pop(0)
	return ans

def enumerate_subsets(print_all=False):
	'''
	- Enumerate over all non-empty subsets of [9]
	- Compute (symbolic) E[Y | X in S] in terms of theta=x
	- Print S and E[Y | X in S] (if print_all=False : only print when independent of theta)
	'''
	all_masks = Enum_Masks(9)
	ans_all, ans_no_theta = 0, 0
	for m in all_masks:
		cex = CondEx(m);
		ans_all += 1
		if print_all:
			print(f'Mask: {m}; E[Y | X in S] = {cex/30}')
		if x not in cex.free_symbols:
			ans_no_theta += 1
			if not print_all:
				print(f'Mask: {m}; E[Y | X in S] = {cex/30}')

	print(f'\nTotal number of subsets S is : {ans_all}')
	print(f'Total number of subsets S for which E[Y | X in S] is independent of theta : {ans_no_theta}')

if __name__ == '__main__':
	if (len(sys.argv) > 1):
		enumerate_subsets(print_all=True)
	else:
		enumerate_subsets(print_all=False)
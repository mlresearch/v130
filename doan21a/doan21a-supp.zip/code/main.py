import matplotlib as mpl
mpl.use('Agg')
import argparse
import numpy as np
import dataloaders.base
from dataloaders.datasetGen import SplitGen, PermutedGen,RotatedGen
import matplotlib.pyplot as plt
import torch
from collections import defaultdict
import random
import tools
import pickle
import os

class AddGaussianNoise(object):
    def __init__(self, mean=0., std=1.):
        self.std = std
        self.mean = mean
        
    def __call__(self, tensor):
        return tensor + torch.randn(tensor.size()) * self.std + self.mean
    
    def __repr__(self):
        return self.__class__.__name__ + '(mean={0}, std={1})'.format(self.mean, self.std)





parser = argparse.ArgumentParser()
parser.add_argument("--seed", default=1, type=int)              # Sets Gym, PyTorch and Numpy seeds
parser.add_argument("--val_size", default=256, type=int)
parser.add_argument("--nepoch", default=10, type=int)             # Number of epoches
parser.add_argument("--batch_size", default=32, type=int)      # Batch size 
parser.add_argument("--memory_size", default=100, type=int)     # size of the memory
parser.add_argument("--hidden_dim", default=100, type=int)      # size of the hidden layer                 
parser.add_argument('--lr',default=1e-3, type=float)  
parser.add_argument('--n_tasks',default=15, type=int)  
parser.add_argument('--workers',default=2, type=int) 
parser.add_argument('--eval_freq',default=1000, type=int) 

parser.add_argument('--model_type',default="mlp", type=str,
                    help="The type (mlp|lenet|) of backbone network", required=False)
parser.add_argument('--model_name', type=str, default='MLP',
                              help="The name of actual model for the backbone", required=False)
## methods parameters
parser.add_argument("--all_features",default=0, type=int) # Leave it to 0, this is for the case when using Lenet, projecting orthogonally only against the linear layers seems to work better

## Dataset
parser.add_argument('--subset_size',default=1000, type=int, help="number of samples per class, ex: for MNIST, \
            subset_size=1000 wil results in a dataset of total size 10,000") 
parser.add_argument('--dataset',default="split_cifar", type=str)
parser.add_argument("--is_split", action="store_true")
parser.add_argument('--first_split_size',default=5, type=int) 
parser.add_argument('--other_split_size',default=5, type=int)
parser.add_argument("--rand_split",default=False, action="store_true")
parser.add_argument('--force_out_dim', type=int, default=10,
                              help="Set 0 to let the task decide the required output dimension", required=False)

## choosing method
parser.add_argument('--method',default="ogd", type=str,help="sgd,ogd,pca,agem,gem-nt")

## PCA-OGD
parser.add_argument('--pca_sample',default=3000, type=int) 
## agem
parser.add_argument("--agem_mem_batch_size", default=256, type=int)     # size of the memory
parser.add_argument('--margin_gem',default=0.5, type=float)
## EWC
parser.add_argument('--ewc_reg',default=1e-2, type=float) 
parser.add_argument('--fisher_sample',default=5, type=int)
config = parser.parse_args()
config.device=torch.device("cuda" if torch.cuda.is_available() else "cpu")

np.set_printoptions(suppress=True)

config_dict=vars(config)
    
torch.manual_seed(config.seed)
np.random.seed(config.seed)
random.seed(config.seed)


torch.backends.cudnn.benchmark=True
torch.backends.cudnn.enabled=True





### dataset path
dataset_root_path="..."


########################################################################################
### dataset ############################################################################ 
if config.dataset=="permuted":
    config.force_out_dim=10
   
    train_dataset, val_dataset = dataloaders.base.__dict__['MNIST'](dataset_root_path, False ,subset_size=config.subset_size)
    
    train_dataset_splits, val_dataset_splits, task_output_space = PermutedGen(train_dataset, val_dataset,config.n_tasks,remap_class= False)
        
elif config.dataset=="rotated":
    config.force_out_dim=10
    import dataloaders.base
    Dataset = dataloaders.base.__dict__["MNIST"]
    n_rotate=config.n_tasks  
   
    rotate_step=5
  
        
    dataroot=dataset_root_path
  
    train_dataset_splits, val_dataset_splits, task_output_space = RotatedGen(Dataset=Dataset,
                                                                                      dataroot=dataroot,
                                                                                      train_aug=False,
                                                                                      n_rotate=n_rotate,
                                                                                      rotate_step=rotate_step,
                                                                                      remap_class=False
                                                                                      ,subset_size=config.subset_size)
       
        
elif config.dataset=="split_mnist":
    config.first_split_size=2
    config.other_split_size=2
    config.force_out_dim=0
    config.is_split=True
    import dataloaders.base
    Dataset = dataloaders.base.__dict__["MNIST"]
   
        
    dataroot=dataset_root_path
    if config.subset_size<50000:
        train_dataset, val_dataset = Dataset(dataroot,False, angle=0,noise=None,subset_size=config.subset_size)
    else:
        train_dataset, val_dataset = Dataset(dataroot,False, angle=0,noise=None)
    train_dataset_splits, val_dataset_splits, task_output_space = SplitGen(train_dataset, val_dataset,
                                                                           first_split_sz=config.first_split_size,
                                                                           other_split_sz=config.other_split_size,
                                                                           rand_split=config.rand_split,
                                                                           remap_class=True)
 
   
    config.n_tasks = len(task_output_space.items())



elif config.dataset=="split_cifar":
    config.force_out_dim=0
    config.first_split_size=5
    config.other_split_size=5
    config.is_split=True
    import dataloaders.base
    Dataset = dataloaders.base.__dict__["CIFAR100"]
   
    dataroot=dataset_root_path
    
    train_dataset, val_dataset = Dataset(dataroot,False, angle=0)
    train_dataset_splits, val_dataset_splits, task_output_space = SplitGen(train_dataset, val_dataset,
                                                                               first_split_sz=config.first_split_size,
                                                                               other_split_sz=config.other_split_size,
                                                                               rand_split=config.rand_split,
                                                                               remap_class=True)
    config.n_tasks=len(train_dataset_splits)
    
    
    
    
config.out_dim = {'All': config.force_out_dim} if config.force_out_dim > 0 else task_output_space

val_loaders = [torch.utils.data.DataLoader(val_dataset_splits[str(task_id)],
                                                   batch_size=256,shuffle=False,
                                                   num_workers=config.workers)
               for task_id in range(1, config.n_tasks + 1)]




trainer=tools.Trainer(config,val_loaders)

t=0
########################################################################################
### start training #####################################################################
for task_in in range(config.n_tasks):
    rr=0
   
    train_loader = torch.utils.data.DataLoader(train_dataset_splits[str(task_in+1)],
                                                       batch_size=config.batch_size,
                                                       shuffle=True,
                                                       num_workers=config.workers)
    ### train for EPOCH times
    
    print('task id '+str(task_in+1))
   
    for epoch in range(config.nepoch):
        
        
         trainer.ogd_basis.to(trainer.config.device) 
         
         for i, (input, target, task) in enumerate(train_loader):
          
            trainer.task_id = int(task[0])
            t+=1
            rr+=1
            inputs = input.to(trainer.config.device)
            target = target.long().to(trainer.config.device)
           
            out = trainer.forward(inputs,task).to(trainer.config.device)
            loss = trainer.criterion(out, target)
            
            if config.method=="ewc" and (task_in+1)>1:
                loss+=config.ewc_reg*trainer.penalty(trainer.model)                
            
            loss.backward()
            trainer.optimizer_step()
            ### validation accuracy
           
            if rr%trainer.config.eval_freq==0: 
                for element in range(task_in+1):
                    trainer.acc[element]['test_acc'].append(trainer.test_error(element))
                    trainer.acc[element]['training_steps'].append(t)
        
                    
    
        
    for element in range(task_in+1):
        trainer.acc[element]['test_acc'].append(trainer.test_error(element))
        trainer.acc[element]['training_steps'].append(t)
        
    
    ## update memory at the end of each tasks depending on the method

    if config.method in ['ogd','pca']:
        train_loader2 = torch.utils.data.DataLoader(train_dataset_splits[str(task_in+1)],
                                                       batch_size=256,
                                                       shuffle=True,
                                                       num_workers=config.workers)
        print('memory update')
        trainer.ogd_basis.to(trainer.config.device)
        trainer.update_mem(train_loader2,task_in+1)
        
    if config.method=="agem":
        train_loader2 = torch.utils.data.DataLoader(train_dataset_splits[str(task_in+1)],
                                                       batch_size=256,
                                                       shuffle=True,
                                                       num_workers=config.workers)
        trainer.update_agem_memory(train_loader2,task_in+1)
    
        trainer.consolidate(trainer._diag_fisher(train_loader2))
    if config.method=="gem-nt":  ## GEM-NT
        train_loader2 = torch.utils.data.DataLoader(train_dataset_splits[str(task_in+1)],
                                                       batch_size=256,
                                                       shuffle=True,
                                                       num_workers=config.workers)
        
        trainer.update_gem_no_transfer_memory(train_loader2,task_in+1)
    
    if config.method=="ewc":
        trainer.update_means()
        train_loader2 = torch.utils.data.DataLoader(train_dataset_splits[str(task_in+1)],
                                                       batch_size=1,
                                                       shuffle=True,
                                                       num_workers=config.workers)
        
        
        








from torch.nn.utils.convert_parameters import _check_param_device, parameters_to_vector, vector_to_parameters
import torch.nn as nn
import torch
from collections import defaultdict
from tqdm.auto import tqdm
from dataloaders.wrapper import Storage
from types import MethodType
# import models
from copy import deepcopy
import torch.nn.functional as F
from importlib import import_module
import numpy as np

class Memory(Storage):
    def reduce(self, m):
        self.storage = self.storage[:m]
        
        
def count_parameter(model):
    return sum(p.numel() for p in model.parameters())

class Trainer(object):
    def __init__(self, config,val_loaders):
        self.config=config
        
       
        self.model = self.create_model()
        
        # self.model=model.to(self.config.device)
        self.optimizer = torch.optim.SGD(params=self.model.parameters(),lr=self.config.lr,momentum=0,weight_decay=0)
        self.criterion = nn.CrossEntropyLoss()
        
        
        
        n_params = count_parameter(self.model)
        self.ogd_basis = torch.empty(n_params, 0).to(self.config.device)
        # self.ogd_basis = None
   
        self.mem_dataset = None

   
        self.ogd_basis_ids = defaultdict(lambda: torch.LongTensor([]).to(self.config.device))

        self.val_loaders = val_loaders

        self.task_count = 0
        self.task_memory = {}
        
       
        ### FOR GEM no transfer
        self.task_mem_cache = {}

        self.task_grad_memory = {}
        self.task_grad_mem_cache = {}
        
        
        self.acc={}
        for element in range(self.config.n_tasks):
            self.acc[element]={}
            self.acc[element]['test_acc']=[]
            self.acc[element]['training_acc']=[]
            self.acc[element]['training_steps']=[]
        
        if self.config.method=="gem-nt":
            self.quadprog = import_module('quadprog')
            self.grad_to_be_saved={}
        if self.config.method=="agem":
            self.agem_mem = list()
            self.agem_mem_loader = None
            
        
        self.gradient_count=0
        self.gradient_violation=0
        self.eval_freq=config.eval_freq
        
        if self.config.method=="ewc":
            ## split cifar
            if self.config.is_split:
                if self.config.all_features:
                    if hasattr(self.model,"conv"):
                        r=list(self.model.linear.named_parameters())+list(self.model.conv.named_parameters())
                        self.params = {n: p for n, p in r if p.requires_grad}
                    else:
                        self.params = {n: p for n, p in self.model.linear.named_parameters() if p.requires_grad}
                else:
                        self.params = {n: p for n, p in self.model.linear.named_parameters() if p.requires_grad}
                   
            ### rotated
            else:
                self.params = {n: p for n, p in self.model.named_parameters() if p.requires_grad}
            
            self._means = {}
            
            for n, p in deepcopy(self.params).items():
                self._means[n] = p.data
            
            self._precision_matrices ={}
            for n, p in deepcopy(self.params).items():
                p.data.zero_()
                self._precision_matrices[n] = p.data
    
    
     
        
    def create_model(self):
      
        cfg = self.config
        print(cfg.model_type)
        if cfg.model_type=="mlp":
            import models.mlp
            model = models.mlp.MLP(hidden_dim=cfg.hidden_dim)
        elif cfg.model_type=="lenet":
            import models.lenet
            model = models.lenet.LeNetC(hidden_dim=cfg.hidden_dim)
       
                                                                               # in_channel=in_channel)
        n_feat = model.last.in_features
       
        model.last = nn.ModuleDict()
        for task,out_dim in cfg.out_dim.items():
           
            model.last[task] = nn.Linear(n_feat,out_dim)

      

        # Redefine the task-dependent function
        def new_logits(self, x):
            outputs = {}
            for task, func in self.last.items():
                outputs[task] = func(x)
            return outputs

        # Replace the task-dependent function
        model.logits = MethodType(new_logits, model)
        model.to(self.config.device)
        return model

    def forward(self, x, task):
        # TODO : Check :-)
        ##################################
        task_key = task[0]
        out = self.model.forward(x)
        # print(out)
        if self.config.is_split :
            try:
                return out[task_key]
            except:
                return out[int(task_key)]
        else :
            # return out
            return out["All"] 
    
    def get_params_dict(self, last, task_key=None):
        if self.config.is_split :
            if last:
                return self.model.last[task_key].parameters()
            else:
              
                if self.config.all_features:
                    if hasattr(self.model,"conv"):
                        return list(self.model.linear.parameters())+list(self.model.conv.parameters())
                    else:
                        return self.model.linear.parameters()
                    
                        
                else:
                    return self.model.linear.parameters()
                # return self.model.linear.parameters()
        else:
            return self.model.parameters()
        
    

    
    
    def optimizer_step(self):
        
        task_key = str(self.task_id)
        
        grad_vec = parameters_to_grad_vector(self.get_params_dict(last=False))
        cur_param = parameters_to_vector(self.get_params_dict(last=False))
        
        if self.config.method in ['ogd','pca']:
       
            proj_grad_vec = self.project_vec(grad_vec,
                                        proj_basis=self.ogd_basis)
            new_grad_vec = grad_vec - proj_grad_vec
           
        elif self.config.method=="agem" and self.agem_mem_loader is not None :
            self.optimizer.zero_grad()
            data, target, task = next(iter(self.agem_mem_loader))
            # data = self.to_device(data)
            data=data.to(self.config.device)
            target = target.long().to(self.config.device)
          
            output = self.forward(data, task)
            mem_loss = self.criterion(output, target)
            mem_loss.backward()
            mem_grad_vec = parameters_to_grad_vector(self.get_params_dict(last=False))
            
            self.gradient_count+=1
              
            # print(self.ogd_basis)
            new_grad_vec = self._project_agem_grad(batch_grad_vec=grad_vec,
                                                   mem_grad_vec=mem_grad_vec)
        elif self.config.method=="gem-nt":
         
            if self.task_count >= 1:
                
                 for t,mem in self.task_memory.items():
                    self.optimizer.zero_grad()
                   
                    mem_out = self.forward(self.task_mem_cache[t]['data'].to(self.config.device),self.task_mem_cache[t]['task'])
                    
                    mem_loss = self.criterion(mem_out, self.task_mem_cache[t]['target'].long().to(self.config.device))
               
                    mem_loss.backward()
                  
                    self.task_grad_memory[t]=parameters_to_grad_vector(self.get_params_dict(last=False))
                   
                    mem_grad_vec = torch.stack(list(self.task_grad_memory.values()))
                   
                    new_grad_vec = self.project2cone2(grad_vec, mem_grad_vec)
                    
            else:
                new_grad_vec = grad_vec
            
        else:
            new_grad_vec = grad_vec
            
        cur_param -= self.config.lr * new_grad_vec#.to(self.config.device)
        vector_to_parameters(cur_param, self.get_params_dict(last=False))
        # vector_to_parameters(cur_param, self.model.parameters())
        if self.config.is_split :
            # Update the parameters of the last layer without projection, when there are multiple heads)
            cur_param = parameters_to_vector(self.get_params_dict(last=True, task_key=task_key))
            grad_vec = parameters_to_grad_vector(self.get_params_dict(last=True, task_key=task_key))
            cur_param -= self.config.lr * grad_vec
            vector_to_parameters(cur_param, self.get_params_dict(last=True, task_key=task_key))
        # ZERO GRAD
        self.optimizer.zero_grad()
        
    def test_error(self,task_idx):
        self.model.eval()
        acc = 0
        acc_cnt = 0
        with torch.no_grad():
            for idx, data in enumerate(self.val_loaders[task_idx]):
               
                    data, target, task = data
                   
                    data = data.to(self.config.device)
                    target = target.to(self.config.device)
        
                    outputs = self.forward(data,task)
        
                    acc += self.accuracy(outputs, target)
                    acc_cnt += float(target.shape[0])
        return acc/acc_cnt
    
    def accuracy(self,outputs,target):
        topk=(1,)       
        with torch.no_grad():
                maxk = max(topk)
              
                _, pred = outputs.topk(maxk, 1, True, True)
                pred = pred.t()
                correct = pred.eq(target.view(1, -1).expand_as(pred))
             
                res = []
                for k in topk:
                    correct_k = correct[:k].view(-1).float().sum().item()
                    res.append(correct_k)
        
                if len(res)==1:
                    return res[0]
                else:
                    return res
    
    ########################################################################################
    ### getting new/updating basis ######################################################### 
    def _get_new_ogd_basis(self,train_loader, device,optimizer, model,forward):
        new_basis = []
    
        
        for _,element in enumerate(train_loader):

            inputs=element[0].to(device)
          
            targets = element[1].to(device)
            
            task=element[2]
            
            out = forward(inputs,task)
          
            assert out.shape[0] == 1
          
            pred = out[0,int(targets.item())].cpu()
          
            optimizer.zero_grad()
            pred.backward()
        
          
            new_basis.append(parameters_to_grad_vector(self.get_params_dict(last=False)).cpu())
         
        del out,inputs,targets
        torch.cuda.empty_cache()
        new_basis = torch.stack(new_basis).T
      
        return new_basis
    
    def _get_new_gem_m_basis(self, device,optimizer, model,forward):
        new_basis = []
    
        
      
        for t,mem in self.task_memory.items():
          
         
            for index in range(len(self.task_mem_cache[t]['data'])):

            
                inputs=self.task_mem_cache[t]['data'][index].to(device).unsqueeze(0)
                
                targets=self.task_mem_cache[t]['target'][index].to(device).unsqueeze(0)
                
                task=self.task_mem_cache[t]['task'][0]
                
                out = forward(inputs,task)
               
                mem_loss = self.criterion(out, targets.long().to(self.config.device))
                optimizer.zero_grad()
                mem_loss.backward()
                new_basis.append(parameters_to_grad_vector(self.get_params_dict(last=False)).cpu())
            
        del out,inputs,targets
        torch.cuda.empty_cache()
        new_basis = torch.stack(new_basis).T
        return new_basis
    
    

    
    ########################################################################################
    ### memory update for each different projection based methods ##########################    
    def update_mem(self,train_loader,task_count):
        
        self.task_count =task_count
    
      
        num_sample_per_task = self.config.memory_size # // (self.config.n_tasks-1)
        num_sample_per_task = min(len(train_loader.dataset), num_sample_per_task)
    
        memoire=[]
        for i in range(task_count):
             memoire.append(num_sample_per_task)
      
        
        for storage in self.task_memory.values():
            ## reduce prend l'élément de 0 a num_sample_per_task
            storage.reduce(num_sample_per_task)
           
       
        self.task_memory[0] = Memory()  # Initialize the memory slot
      
        if self.config.method=="pca":
           
            randind = torch.randperm(len(train_loader.dataset))[:self.config.pca_sample]
        else:
            randind = torch.randperm(len(train_loader.dataset))[:num_sample_per_task]  # randomly sample some data
        for ind in randind:  # save it to the memory
          
            self.task_memory[0].append(train_loader.dataset[ind])


        ####################################### Grads MEM ###########################
      
        for storage in self.task_grad_memory.values():
            storage.reduce(num_sample_per_task)
    

       
        if self.config.method in ['ogd','pca']:
            ogd_train_loader = torch.utils.data.DataLoader(self.task_memory[0],
                                                       batch_size=1,
                                                       shuffle=False,
                                                       num_workers=1)
          
        
        
        self.task_memory[0] = Memory()
      
        new_basis_tensor = self._get_new_ogd_basis(ogd_train_loader,
                                              self.config.device,
                                              self.optimizer,
                                              self.model,
                                              self.forward).cpu()
        
        if self.config.method=="ogd":
            if self.config.save_weights:
                if self.task_count==1:
                    self.v=new_basis_tensor.clone().detach()
                    
        if self.config.method=="pca":
          
            try:
                _,_,v1=torch.pca_lowrank(new_basis_tensor.T.cpu(), q=num_sample_per_task, center=True, niter=2)
               
            except:
                _,_,v1=torch.svd_lowrank((new_basis_tensor.T+1e-4*new_basis_tensor.T.mean()*torch.rand(new_basis_tensor.T.size(0), new_basis_tensor.T.size(1))).cpu(), q=num_sample_per_task, niter=2, M=None)
            
            if self.config.save_weights:
                if self.task_count==1:
                    self.v=v1.clone().detach()
                
            del new_basis_tensor
            new_basis_tensor=v1.cpu()
            torch.cuda.empty_cache()
          
        if self.config.is_split:
            if self.config.all_features:
                if hasattr(self.model,"conv"):
                        n_params = count_parameter(self.model.linear)+count_parameter(self.model.conv)
                else:
                        n_params = count_parameter(self.model.linear)
            else:
                
                n_params = count_parameter(self.model.linear)
               
        else:
            n_params = count_parameter(self.model)
            
        
     
        self.ogd_basis = torch.empty(n_params, 0).cpu()
      
      
        for t, mem in self.task_grad_memory.items():
         
            task_ogd_basis_tensor=torch.stack(mem.storage,axis=1).cpu()
           
            self.ogd_basis = torch.cat([self.ogd_basis, task_ogd_basis_tensor], axis=1).cpu()
          
      
        self.ogd_basis=new_orthonormalize(self.ogd_basis,new_basis_tensor,self.config.device,normalize=True)
      
    
        # (g) Store in the new basis
        ptr = 0
     
        for t in range(len(memoire)):
            
            
            task_mem_size=memoire[t]
            idxs_list = [i + ptr for i in range(task_mem_size)]
           
            self.ogd_basis_ids[t] = torch.LongTensor(idxs_list).to(self.config.device)
            
           
            self.task_grad_memory[t] = Memory()  # Initialize the memory slot

            
       
           
            if self.config.method=="pca":
                longueur=num_sample_per_task
            else:
                longueur=task_mem_size
            for ind in range(longueur):  # save it to the memory
                self.task_grad_memory[t].append(self.ogd_basis[:, ptr].cpu())
                ptr += 1
                

    def update_agem_memory(self, train_loader,task_id):
        
        self.task_count =task_id
        num_sample_per_task = self.config.memory_size #// (self.config.n_tasks-1)
        randind = torch.randperm(len(train_loader.dataset))[:num_sample_per_task]
        for ind in randind:  # save it to the memory
            self.agem_mem.append(train_loader.dataset[ind])
            
    
        
        mem_loader_batch_size = min(self.config.agem_mem_batch_size, len(self.agem_mem))
        self.agem_mem_loader = torch.utils.data.DataLoader(self.agem_mem,
                                                   batch_size=mem_loader_batch_size,
                                                   shuffle=True,
                                                   num_workers=1)
        
    def update_gem_no_transfer_memory(self,train_loader,task_id):
        
        self.task_count=task_id
       
        num_sample_per_task = self.config.memory_size 
        
        num_sample_per_task = min(len(train_loader.dataset), num_sample_per_task)
     
        self.task_memory[self.task_count] = Memory()
        randind = torch.randperm(len(train_loader.dataset))[:num_sample_per_task]  # randomly sample some data
        for ind in randind:  # save it to the memory
            self.task_memory[self.task_count].append(train_loader.dataset[ind])
            
      
        for t, mem in self.task_memory.items():
          
            mem_loader = torch.utils.data.DataLoader(mem,
                                                     batch_size=len(mem),
                                                     shuffle=False,
                                                     num_workers=1)
            assert len(mem_loader) == 1, 'The length of mem_loader should be 1'
            for i, (mem_input, mem_target, mem_task) in enumerate(mem_loader):
                pass
              
            self.task_mem_cache[t] = {'data': mem_input, 'target': mem_target, 'task': mem_task}
    
    
    ########################################################################################
    ### projection methods for GEM methods #################################################
            
    def project_vec(self,vec, proj_basis):
        if proj_basis.shape[1] > 0 :  # param x basis_size
            dots = torch.matmul(vec, proj_basis)  # basis_size
            out = torch.matmul(proj_basis, dots)
            return out
        else:
            return torch.zeros_like(vec) 
        
    def _project_agem_grad(self, batch_grad_vec, mem_grad_vec):
   
        if torch.dot(batch_grad_vec, mem_grad_vec) >= 0:
            return batch_grad_vec
        else :
            self.gradient_violation+=1
          
            
          
            frac = torch.dot(batch_grad_vec, mem_grad_vec) / torch.dot(mem_grad_vec, mem_grad_vec)
           
            new_grad = batch_grad_vec - frac * mem_grad_vec
           
            check = torch.dot(new_grad, mem_grad_vec)
            assert torch.abs(check) < 1e-5
            return new_grad

    def project2cone2(self, gradient, memories):
        """
            Solves the GEM dual QP described in the paper given a proposed
            gradient "gradient", and a memory of task gradients "memories".
            Overwrites "gradient" with the final projected update.
            input:  gradient, p-vector
            input:  memories, (t * p)-vector
            output: x, p-vector
            Modified from: https://github.com/facebookresearch/GradientEpisodicMemory/blob/master/model/gem.py#L70
        """
       
        margin = self.config.margin_gem
        memories_np = memories.cpu().contiguous().double().numpy()
        gradient_np = gradient.cpu().contiguous().view(-1).double().numpy()
        t = memories_np.shape[0]
       
        P = np.dot(memories_np, memories_np.transpose())
        P = 0.5 * (P + P.transpose())
        q = np.dot(memories_np, gradient_np) * -1
        G = np.eye(t)
        P = P + G * 0.001
        h = np.zeros(t) + margin
        # print(P)
        v = self.quadprog.solve_qp(P, q, G, h)[0]
        x = np.dot(v, memories_np) + gradient_np
        new_grad = torch.Tensor(x).view(-1)
       
        new_grad = new_grad.to(self.config.device)
        return new_grad

    ########################################################################################
    ### EWC methods ########################################################################        
    def consolidate(self,precision_matrices):
       for index in self._precision_matrices:
           self._precision_matrices[index]+=precision_matrices[index]
                 
    def update_means(self):

        for n, p in deepcopy(self.params).items():
            self._means[n] = p.data
            
    def penalty(self, model: nn.Module):
        loss = 0
        
        for index in self.params:
            _loss = self._precision_matrices[index] *0.5* (self.params[index] - self._means[index]) ** 2
            loss += _loss.sum()
        return loss
            
    def _diag_fisher(self,train_loader):
        precision_matrices = {}
        
        for n, p in deepcopy(self.params).items():
            p.data.zero_()
            precision_matrices[n] = p.data

        self.model.eval()
        k=1
        for _,element in enumerate(train_loader):
            if k>=self.config.fisher_sample:
                break
            self.model.zero_grad()
            inputs=element[0].to(self.config.device)
            targets = element[1].long().to(self.config.device)
           
            task=element[2]
            out = self.forward(inputs,task)
            assert out.shape[0] == 1
          
            pred = out.cpu()

           
            loss=F.log_softmax(pred, dim=1)[0][targets.item()]
            loss.backward()

            for index in self.params:
                precision_matrices[index].data += self.params[index].grad.data ** 2 / self.config.fisher_sample
            
        precision_matrices = {n: p for n, p in precision_matrices.items()}
        return precision_matrices



########################################################################################
### other utils function ###############################################################
def new_orthonormalize(main_vectors, additional_vectors,device,normalize=True): 
    ## more memory efficient than the next method
    for element in range(additional_vectors.size()[1]):
        
 
        
        coeff=torch.mv(main_vectors.t(),additional_vectors[:,element])
        pv=torch.mv(main_vectors, coeff)
        d=(additional_vectors[:,element]-pv)/torch.norm(additional_vectors[:,element]-pv,p=2)
        main_vectors=torch.cat((main_vectors,d.view(-1,1)),dim=1)
        del pv
        del d
    return main_vectors.to(device)
            
                
def orthonormalize(vectors, normalize=True):
    assert (vectors.size(1) <= vectors.size(0)), 'number of vectors must be smaller or equal to the ddbension'
    orthonormalized_vectors = torch.zeros_like(vectors)
    if normalize:
        orthonormalized_vectors[:, 0] = vectors[:, 0] / torch.norm(vectors[:, 0], p=2)
    else:
        orthonormalized_vectors[:, 0] = vectors[:, 0]

    for i in tqdm(range(1, orthonormalized_vectors.size(1)), desc="orthonormalizing ..."):
   
        vector = vectors[:, i]
        V = orthonormalized_vectors[:, :i]
        PV_vector = torch.mv(V, torch.mv(V.t(), vector))
        if normalize:
            orthonormalized_vectors[:, i] = (vector - PV_vector) / torch.norm(vector - PV_vector, p=2)
        else:
            orthonormalized_vectors[:, i] = (vector - PV_vector)

    return orthonormalized_vectors




def parameters_to_grad_vector(parameters):
    # Flag for the device where the parameter is located
    param_device = None
    vec = []
    for param in parameters:
        # Ensure the parameters are located in the same device
        param_device = _check_param_device(param, param_device)
        vec.append(param.grad.view(-1))
        
    return torch.cat(vec)


def grad_vector_to_parameters(vec, parameters):
    # Ensure vec of type Tensor
    if not isinstance(vec, torch.Tensor):
        raise TypeError('expected torch.Tensor, but got: {}'
                        .format(torch.typename(vec)))
    # Flag for the device where the parameter is located
    param_device = None
    # Pointer for slicing the vector for each parameter
    pointer = 0
    for param in parameters:
        # Ensure the parameters are located in the same device
        param_device = _check_param_device(param, param_device)
        # The length of the parameter
        num_param = param.numel()
        # Slice the vector, reshape it, and replace the old data of the parameter
        # param.data = vec[pointer:pointer + num_param].view_as(param).data
        param.grad = vec[pointer:pointer + num_param].view_as(param).clone()
        # Increment the pointer
        pointer += num_param   
        


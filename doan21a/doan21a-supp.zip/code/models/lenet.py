

import torch.nn as nn


class LeNet(nn.Module):

    def __init__(self, out_dim=10, in_channel=1, img_sz=32, hidden_dim=500):
        super(LeNet, self).__init__()
        feat_map_sz = img_sz//4
        self.n_feat = 50 * feat_map_sz * feat_map_sz
        self.hidden_dim = hidden_dim

        self.conv = nn.Sequential(
            nn.Conv2d(in_channel, 20, 5, padding=2),
            nn.BatchNorm2d(20),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(20, 50, 5, padding=2),
            nn.BatchNorm2d(50),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.Flatten(),
         
        )
        self.linear = nn.Sequential(
            nn.Linear(self.n_feat, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True),
        )
        
      
        
        self.last = nn.Linear(hidden_dim, out_dim)  # Subject to be replaced dependent on task

    def features(self, x):
        x = self.conv(x)
     
       
        x = self.linear(x.view(-1, self.n_feat))
       
        # x=self.linear(x)
        return x

    def logits(self, x):
        x = self.last(x)
        return x

    def forward(self, x):
        x = self.features(x)
        x = self.logits(x)
        return x


def LeNetC(out_dim=10, hidden_dim=500):  # LeNet with color input
    return LeNet(out_dim=out_dim, in_channel=3, img_sz=32, hidden_dim=hidden_dim)
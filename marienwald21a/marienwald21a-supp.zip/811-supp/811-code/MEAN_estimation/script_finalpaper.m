ntrials = 20;

comparison_exp("UNIF.0",ntrials)
comparison_exp("UNIF.1",ntrials)
comparison_exp("UNIF.2",ntrials)
comparison_exp("UNIF.3",ntrials)
comparison_exp("CLUSTER.1",ntrials)
comparison_exp("CLUSTER.2",ntrials)
comparison_exp("CLUSTER.3",ntrials)
comparison_exp("CLUSTER.4",ntrials)
comparison_exp("SPHERE.0",ntrials)
comparison_exp("SPHERE.1",ntrials)
comparison_exp("SPHERE.2",ntrials)
comparison_exp("SPHERE.3",ntrials)
comparison_exp("SPARSE.1",ntrials)
comparison_exp("SPARSE.2",ntrials)
comparison_exp("SPARSE.3",ntrials)
comparison_exp("SPARSE.4",ntrials)
comparison_exp("SPARSE.5",ntrials)
comparison_exp("SPARSE.6",ntrials)





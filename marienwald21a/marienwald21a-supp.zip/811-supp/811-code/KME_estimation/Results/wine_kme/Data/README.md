**Please download the data set (train, test, validation.csv) before running the experiments and put it here.**            

References for WINE data set:             
[https://www.kaggle.com/dbahri/wine-ratings]          
and                      
>Gupta, Maya R., Bahri, Dara, Cotter, Andrew and Canini, Kevin. (2018). Diminishing Returns Shape Constraints for Interpretability and Regularization. In *Proceedings of the 32nd International Conference on Neural Information Processing Systems (NeurIPS '18).
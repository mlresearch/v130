#load data for shuttle
import os
import numpy as np
import random
import math
import pandas as pd
from sklearn.random_projection import johnson_lindenstrauss_min_dim
from avlk_validation_helpers import distortion_ratio, dimension_reduction

def load_data(filename, data_name):
    out = []

    if data_name == "shuttle":
        delim = ' '
        f = open(filename, 'r')
        for line in f.readlines():
            y = line.strip().split(delim)
            out.append(y)

    if data_name == "blog":
        out = pd.read_csv(filename).to_numpy()

    if data_name == "seizure":
        out = pd.read_csv(filename).to_numpy()
        m = out.shape[1]
        out = out[:, 1 : m - 1]

    if data_name == "covtype":
        delim = ','
        f = open(filename, 'r')
        for line in f.readlines():
            y = line.strip().split(delim)
            out.append(y[:10])

    return out

def subsample(data, sample_sizes, sample_direc, data_name, num_instances):
    for size in sample_sizes:
        direc = "{}/{}_{}".format(sample_direc, data_name, str(size))
        if not os.path.exists(direc):
            os.makedirs(direc)
        for i in range(num_instances):
            file_direc = direc + '/{}.txt'.format(str(i))
            sample_f = open(file_direc, 'w')
            samples = random.sample(list(data), size)
            for pt in samples:
                sample_f.write(' '.join([str(y) for y in pt]))
                sample_f.write("\n")
    return

# assume data is a numpy array
def scale_dimensions(data):
    dim_max = data.max(axis=0)
    dim_min = data.min(axis=0)
    dim_dif = dim_max - dim_min
    dif_max = max(dim_dif)
    scales = dif_max / np.array(dim_dif, dtype='float64')
    return np.array(data * scales, dtype='int')

def subsample_rescale(data, sample_sizes, sample_direc, data_name, num_instances):
    for size in sample_sizes:
        direc = "{}/{}_{}".format(sample_direc, data_name, str(size))
        if not os.path.exists(direc):
            os.makedirs(direc)
        for i in range(num_instances):
            file_direc = direc + '/{}.txt'.format(str(i))
            sample_f = open(file_direc, 'w')
            samples = random.sample(data, size)
            samples = list(scale_dimensions(np.array(samples, dtype='int')))
            for pt in samples:
                sample_f.write(' '.join([str(y) for y in pt]))
                sample_f.write("\n")
    return
'''
def check_distortion(data, sample_sizes, sample_direc, data_name, num_instances):
    for size in sample_sizes:
        for i in num_instances:
            direc = "{}/{}_{}/{}.txt".format(sample_direc, data_name, str(size), str(i))
            f = open(filename, 'r')
            delim = ' '
            data = []
            for line in f.readlines():
                y = line.strip().split(delim)
                data.append([float(x) for x in y])
            projected_data = dimension_reduction(data, 5)
'''

if __name__ == "__main__":
    np.random.seed(0)
    random.seed(0)
    filename = "./covtype.data/covtype.data"
    data_name = 'covtype'
    #sample_direc = "./samples"
    sample_direc = './samples_' + data_name
    num_instances = 5

    sample_sizes = [2 ** i * 100 for i in range(7)]
    data = load_data(filename, data_name)
    print(data)
    subsample(data, sample_sizes, sample_direc, data_name, num_instances)
    #subsample_rescale(data, sample_sizes, sample_direc, data_name, num_instances)

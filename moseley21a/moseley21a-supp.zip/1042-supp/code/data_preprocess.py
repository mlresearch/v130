import sys
import numpy as np
np.set_printoptions(threshold=sys.maxsize)
import random
import matplotlib.pyplot as plt
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import minimum_spanning_tree, connected_components, shortest_path
from scipy.spatial.distance import euclidean


# put the graph into grids grid_size * grid_size
def grid_subgraph(coors, edges, times, grid_size):
    #edges: (i,j) has format like [i,j, distance]
    #coors: [[index, lat, long]]
    #indices of nodes = [size]
    #grid_size is the # of blocks lat/long is divided into
    assert len(edges) == len(times)
    n = len(coors)
    longs = [x[1] for x in coors]
    lats = [x[2] for x in coors]
    lat_max = max(lats)
    lat_min = min(lats)
    long_max = max(longs)
    long_min = min(longs)

    sub_nodes = []
    sub_edges = []
    sub_times = []

    lat_len = (lat_max - lat_min) / grid_size
    long_len = (long_max - long_min) / grid_size

    #randomly select a block of size lat_len * long_len
    #if too few points or two sparse edges, resample
    while True:
        lat_start = random.uniform(lat_min, lat_max - lat_len)
        long_start = random.uniform(long_min, long_max - long_len)
        lat_end = lat_start + lat_len
        long_end = long_start + long_len

        sub_nodes = [node + 1 for node in range(n) if long_start <= coors[node][1] <= long_end and lat_start <= coors[node][2] <= lat_end]
        sub_n = len(sub_nodes)
        node_dict = {sub_nodes[i]: i for i in range(sub_n)}
        if sub_n < n / (grid_size ** 2 * 5):
            continue

        edge_dict = {}
        time_dict = {}
        sub_edges = []
        sub_times = []

        #take all the edges induced by the sub_nodes
        for i in range(len(edges)):
            assert edges[i][0] == times[i][0] and edges[i][1] == times[i][1]
            if edges[i][0] in node_dict and edges[i][1] in node_dict:
                row_index = node_dict.get(edges[i][0])
                col_index = node_dict.get(edges[i][1])
                #check if this is repeated edge
                if (row_index, col_index) not in edge_dict:
                    edge_dict[(row_index, col_index)] = edges[i][2]
                    time_dict[(row_index, col_index)] = times[i][2]
                elif time_dict[(row_index, col_index)] > times[i][2]:
                    time_dict[(row_index, col_index)] = times[i][2]

        for (row, col) in edge_dict.keys():
            sub_edges.append([row, col, edge_dict.get((row, col))])
            sub_times.append([row, col, time_dict.get((row, col))])


        # get the biggest component
        sparse_edges = csr_matrix((np.array(sub_edges, dtype=int)[:, 2], (np.array(sub_edges, dtype=int)[:, 0], np.array(sub_edges, dtype=int)[:, 1])), shape=(sub_n, sub_n))
        n_components, labels = connected_components(csgraph=sparse_edges)
        num_pts = [np.count_nonzero(labels == j) for j in range(n_components)]
        max_label = num_pts.index(max(num_pts))

        # take the subgraph
        comp_edges = []
        comp_times = []
        comp_nodes = [sub_nodes[i] for i in range(sub_n) if labels[i] == max_label]
        comp_n = num_pts[max_label]
        assert len(comp_nodes) == comp_n
        node_dict = {comp_nodes[i]: i for i in range(comp_n)}
        for i in range(len(sub_edges)):
            row = sub_edges[i][0]
            col = sub_edges[i][1]
            if sub_nodes[row] in node_dict and sub_nodes[col] in node_dict:
                comp_edges.append([node_dict.get(sub_nodes[row]), node_dict.get(sub_nodes[col]), sub_edges[i][2]])
                comp_times.append([node_dict.get(sub_nodes[row]), node_dict.get(sub_nodes[col]), sub_times[i][2]])
        assert len(sub_edges) == len(sub_times)
        sub_edges = comp_edges
        sub_times = comp_times
        sub_nodes = comp_nodes
        sub_n = comp_n
        if len(sub_nodes) >= n / (grid_size ** 2 * 5) and len(sub_edges) >= 1.3 * len(sub_nodes) and len(sub_nodes) <= 30000:
            break

    return sub_nodes, sub_edges, sub_times, [long_start, long_end, lat_start, lat_end]

def load_data(filename):
    out = []
    delim = ' '

    f = open(filename, 'r')
    for i in range(7):
        next(f)
    for line in f.readlines():
        y = line.strip().split(delim)
        y = [int(x) for x in y[1:]]
        out.append(y)
    return out

#plotting G = (V, E)
#coors: [n, lat, long]
def draw_graph(coors, edges, filename):
    plt.figure('Line fig')
    gr = plt.gca()
    gr.set_xlabel("longtitude")
    gr.set_ylabel("latitude")
    m = len(edges)
    for i in range(m):
        gr.plot([coors[edges[i][0] - 1][1], coors[edges[i][1] - 1][1]], [coors[edges[i][0] - 1][2], coors[edges[i][1] - 1][2]], linewidth=1)

    plt.savefig(filename)
    plt.show()

    return


#dict_1, dict_2 are the edges
#(rows_1, cols_1) are the edges in MST for metric 1 (-1)
#(rows_2, cols_2) are the edges in MST for metric_2 (-1)
def compare_metric(dict_1, dict_2, rows_1, cols_1, rows_2, cols_2, n):
    assert len(rows_1) == n - 1
    assert len(cols_1) == n - 1
    assert len(rows_2) == n - 1
    assert len(cols_2) == n - 1
    obj_1 = sum([dict_1.get((rows_1[j], cols_1[j])) for j in range(n - 1)])
    obj_2 = sum([dict_2.get((rows_2[j], cols_2[j])) for j in range(n - 1)])
    fake_obj_1 = sum([dict_1.get((rows_2[j], cols_2[j])) for j in range(n - 1)])
    fake_obj_2 = sum([dict_2.get((rows_1[j], cols_1[j])) for j in range(n - 1)])
    return float(fake_obj_1 / obj_1), float(fake_obj_2 / obj_2)

def write_list(edges, times, coors, city_name):
    with open('{}_dist_list.txt'.format(city_name), 'w') as f:
        for line in edges:
            f.write("{} {} {}\n".format(line[0], line[1], line[2]))
        f.close()

    with open('{}_time_list.txt'.format(city_name), 'w') as f:
        for line in times:
            f.write("{} {} {}\n".format(line[0], line[1], line[2]))
        f.close()

    with open('{}_coor_list.txt'.format(city_name), 'w') as f:
        for line in coors:
            f.write("{} {} {}\n".format(line[0], line[1], line[2]))
        f.close()
    return

def check_speed(edges, times):
    m = len(edges)
    speed_list = [0.4, 0.6, 0.8, 1.0]
    for i in range(m):
        token = 0
        upper = (edges[i][2] + 0.5) / (times[i][2] - 0.5)
        lower = (edges[i][2] - 0.5) / (times[i][2] + 0.5)
        for speed in speed_list:
            if lower < speed < upper:
                token = 1
        if token == 0:
            return False
    return True

def speed_subgraph(edges, times, speed_list, num_nodes):
    #build all dictionaries for value checking
    edge_dict = {}
    time_dict = {}

    #get all the highway edges
    filtered_edges = []
    filtered_times = []
    m = len(edges)
    assert len(edges) == len(times)
    for i in range(m):
        assert edges[i][0] == times[i][0] and edges[i][1] == times[i][1]
        lower = (edges[i][2] - 0.5) / (times[i][2] + 0.5)
        upper = (edges[i][2] + 0.5) / (times[i][2] - 0.5)
        for speed in speed_list:
            if lower < speed < upper:
                if (edges[i][0], edges[i][1]) not in edge_dict:
                    filtered_edges.append(edges[i])
                    filtered_times.append(times[i])
                    edge_dict[(edges[i][0], edges[i][1])] = edges[i][2]
                    time_dict[(times[i][0], times[i][1])] = times[i][2]
                else:
                    if edges[i][2] < edge_dict[(edges[i][0], edges[i][1])]:
                        edge_dict[(edges[i][0], edges[i][1])] = edges[i][2]
                    if times[i][2] < time_dict[(times[i][0], times[i][1])]:
                        time_dict[(times[i][0], times[i][1])] = times[i][2]
    edges = filtered_edges
    times = filtered_times

    # get the biggest component
    sparse_edges = csr_matrix((np.array(edges, dtype=int)[:, 2], (np.array(edges, dtype=int)[:, 0] - 1, np.array(edges, dtype=int)[:, 1] - 1)), shape=(num_nodes, num_nodes))
    n_components, labels = connected_components(csgraph=sparse_edges)
    num_pts = [np.count_nonzero(labels == j) for j in range(n_components)]
    max_label = num_pts.index(max(num_pts))
    print("number of points connected in the highway: %d" % num_pts[max_label])

    # take the subgraph
    nodes = [i + 1 for i in range(num_nodes) if labels[i] == max_label]
    n = num_pts[max_label]
    assert len(nodes) == n
    node_dict = {nodes[i]: i for i in range(n)}
    edges = [[node_dict.get(edge[0]), node_dict.get(edge[1]), edge[2]] for edge in edges if edge[0] in node_dict and edge[1] in node_dict]
    times = [[node_dict.get(time[0]), node_dict.get(time[1]), time[2]] for time in times if time[0] in node_dict and time[1] in node_dict]
    assert len(edges) == len(times)
    m = len(edges)
    print("number of edges in the highway graph: %d" % m)

    return edges, times, nodes

#test if a random grid is good enough
def grid_test(sub_edges, sub_times, sub_coors):

    edge_dict = {(edge[0], edge[1]): edge[2] for edge in sub_edges}
    time_dict = {(time[0], time[1]): time[2] for time in sub_times}

    n = len(sub_nodes)
    m = len(sub_edges)
    print("# of nodes is subgraph is: %d, # of edges in subgraph is: %d" %(n, m))

    data_edges = np.array([edge[2] for edge in sub_edges], dtype=int)
    data_times = np.array([time[2] for time in sub_times], dtype=int)

    data_rows = np.array([edge[0] for edge in sub_edges], dtype=int)
    data_cols = np.array([edge[1] for edge in sub_edges], dtype=int)

    #get the edge MST
    sparse_edges = csr_matrix((data_edges, (data_rows, data_cols)), shape=(n, n))
    shortest_paths = shortest_path(csgraph=sparse_edges, method='D', directed=False)
    MST_edge = minimum_spanning_tree(csgraph=sparse_edges).tocoo()
    edge_numbers = MST_edge.data
    edge_rows = MST_edge.row
    edge_cols = MST_edge.col
    for i in range(n - 1):
        assert edge_numbers[i] == edge_dict.get((edge_rows[i], edge_cols[i]))

    #get the time MST
    sparse_times = csr_matrix((data_times, (data_rows, data_cols)), shape=(n, n))
    shortest_times = shortest_path(csgraph=sparse_times, method='D', directed=False)
    MST_time = minimum_spanning_tree(csgraph=sparse_times).tocoo()
    time_numbers = MST_time.data
    time_rows = MST_time.row
    time_cols = MST_time.col
    for i in range(n - 1):
        assert time_numbers[i] == time_dict.get((time_rows[i], time_cols[i]))

    #get the complete graph
    euclid_dist = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            euclid_dist[i][j] = euclidean(sub_coors[i], sub_coors[j])

    MST_euclid = minimum_spanning_tree(csgraph=euclid_dist).tocoo()
    euclid_rows = MST_euclid.row
    euclid_cols = MST_euclid.col

    #compare costs
    edge_cost = sum(MST_edge.data)
    edge_cost_euclid_MST = sum([shortest_paths[euclid_rows[i]][euclid_cols[i]] for i in range(n - 1)])
    edge_cost_time_MST = sum([shortest_paths[time_rows[i]][time_cols[i]] for i in range(n - 1)])

    time_cost = sum(MST_time.data)
    time_cost_edge_MST = sum([shortest_times[edge_rows[i]][edge_cols[i]] for i in range(n - 1)])
    time_cost_euclid_MST = sum([shortest_times[euclid_rows[i]][euclid_cols[i]] for i in range(n - 1)])

    euclid_cost = sum(MST_euclid.data)
    euclid_cost_edge_MST = sum([euclid_dist[edge_rows[i]][edge_cols[i]] for i in range(n - 1)])
    euclid_cost_time_MST = sum([euclid_dist[time_rows[i]][time_cols[i]] for i in range(n - 1)])

    ratio_matrix = np.ones((3, 3))
    ratio_matrix[0][1] = float(edge_cost_time_MST) / edge_cost
    ratio_matrix[0][2] = float(edge_cost_euclid_MST) / edge_cost
    ratio_matrix[1][0] = float(time_cost_edge_MST) / time_cost
    ratio_matrix[1][2] = float(time_cost_euclid_MST) / time_cost
    ratio_matrix[2][0] = euclid_cost_edge_MST / euclid_cost
    ratio_matrix[2][1] = euclid_cost_time_MST / euclid_cost

    return ratio_matrix

def grid_plot(coors, boundaries):
    plt.title('Grid Boxes')
    plt.xlabel("longtitude")
    plt.ylabel("latitude")
    longs = [coor[1] for coor in coors]
    lats = [coor[2] for coor in coors]
    plt.scatter(longs, lats, marker='o', facecolors='none', edgecolors='black')
    #boundary = [long_start, long_end, lat_start, lat_end]
    for boundary in boundaries:
        plt.plot([boundary[0], boundary[0], boundary[1], boundary[1], boundary[0]], [boundary[2], boundary[3], boundary[3], boundary[2], boundary[2]], linewidth=1)
    return

def check(coors):
    for i in range(len(coors) - 1):
        assert coors[i][0] == i + 1
    return

def check_edges(edges, coors, nodes, city):
    all_coors = load_data("{}_latlong.co".format(city))
    all_coors = np.array([[x, y / 1e6, z / 1e6] for x, y, z in all_coors])
    all_edges = load_data("{}_dist.gr".format(city))
    all_edge_dict = {(edge[0], edge[1]): edge[2] for edge in all_edges if edge[0] < edge[1]}
    n = len(coors)
    m = len(edges)
    for i in range(n):
        node = nodes[i]
        assert abs(coors[i][0] - all_coors[node - 1][1]) <= 0.001 or abs(coors[i][1] - all_coors[node - 1][2]) <= 0.001

    for j in range(m):
        assert edges[j][2] == all_edge_dict[(nodes[edges[j][0]], nodes[edges[j][1]])]

    return


if __name__ == "__main__":
    random.seed(5)
    num_instances = 5
    grid_size = 400

    city = 'lks'
    direc = 'samples'
    edges = load_data("{}_dist.gr".format(city))
    coors = load_data("{}_latlong.co".format(city))
    check(coors)
    coors = np.array([[x, y / 1e6, z / 1e6] for x, y, z in coors])
    times = load_data("{}_time.gr".format(city))

    n = len(coors)
    m = int(len(edges) / 2)

    assert check_speed(edges, times)

    print("# of nodes: %d, # of edges: %d" % (n, m))

    edges = [edge for edge in edges if edge[0] < edge[1]]
    times = [time for time in times if time[0] < time[1]]

    boundaries = []

    ratio_f = open("./{}/{}/{}_ratio_matrix.txt".format(direc, grid_size, city), 'w')
    boundary_f = open("./{}/{}/{}_boundaries.txt".format(direc, grid_size, city), 'w')
    for j in range(num_instances):
        while True:
            sub_nodes, sub_edges, sub_times, boundary = grid_subgraph(coors, edges, times, grid_size)
            print("# of nodes: %d, # of edges: %d" % (len(sub_nodes), len(sub_edges)))

            sub_coors = [coors[node - 1][1:] for node in sub_nodes]

            check_edges(sub_edges, sub_coors, sub_nodes, city)
            #ratio_matrix = grid_test(sub_edges, sub_times, sub_coors)
            #if data set is not good, do another round
            
            #if ratio_matrix[2][0] < 1.1 or ratio_matrix[2][1] < 1.1:
            #    print("bad dataset")
            #    continue

            #print(ratio_matrix)

            boundaries.append(boundary)

            with open("./{}/{}/{}_subnodes_{}.txt".format(direc, grid_size, city, j), 'w') as f:
                for node in sub_nodes:
                    f.write("{} ".format(str(node)))
                f.close()

            with open("./{}/{}/{}_subedges_{}.txt".format(direc, grid_size, city, j), 'w') as f:
                for line in sub_edges:
                    f.write("{} {} {}\n".format(line[0], line[1], line[2]))
                f.close()

            with open("./{}/{}/{}_subtimes_{}.txt".format(direc, grid_size, city, j), 'w') as f:
                for line in sub_times:
                    f.write("{} {} {}\n".format(line[0], line[1], line[2]))
                f.close()

            with open("./{}/{}/{}_subcoors_{}.txt".format(direc, grid_size, city, j), 'w') as f:
                for line in sub_coors:
                    f.write("{} {}\n".format(line[0], line[1]))
                f.close()

            '''
            ratio_f.write("      edge      time      latlong\n")
            ratio_f.write("edge  ")
            ratio_f.write("{}  {}  {}\n".format(ratio_matrix[0][0], ratio_matrix[0][1], ratio_matrix[0][2]))
            ratio_f.write("time  ")
            ratio_f.write("{}  {}  {}\n".format(ratio_matrix[1][0], ratio_matrix[1][1], ratio_matrix[1][2]))
            ratio_f.write("latlong  ")
            ratio_f.write("{}  {}  {}\n".format(ratio_matrix[2][0], ratio_matrix[2][1], ratio_matrix[2][2]))
            if j != num_instances - 1:
                ratio_f.write("\n")
                ratio_f.write("\n")
            '''
            boundary_f.write("{} {}\n".format(boundary[0], boundary[1]))
            boundary_f.write("{} {}\n".format(boundary[2], boundary[3]))
            boundary_f.write("\n \n")

            break

    ratio_f.close()
    boundary_f.close()

    #plot all the grids

    grid_plot(coors, boundaries)
    plt.savefig("./{}/{}/{}_all_grids.png".format(direc, grid_size, city))
    plt.show()

    '''
    speed_list = [1.0, 0.8, 0.6]

    #get the subgraph
    edges, times, nodes = speed_subgraph(edges, times, speed_list, n)
    n = len(nodes)
    edge_dict = {(edge[0], edge[1]): edge[2] for edge in edges}
    time_dict = {(time[0], time[1]): time[2] for time in times}
    node_dict = {nodes[i]: i for i in range(n)}
    
    #figure out the latlong distances
    latlongs = []
    for edge in edges:
        index1 = nodes[edge[0]] - 1
        index2 = nodes[edge[1]] - 1
        latlongs.append([edge[0], edge[1], euclidean(coors[index1, 1:], coors[index2, 1:])])

    latlong_dict = {(latlong[0], latlong[1]): latlong[2] for latlong in latlongs}

    data_edges = np.array([edge[2] for edge in edges], dtype=int)
    data_times = np.array([time[2] for time in times], dtype=int)
    data_latlongs = np.array([latlong[2] for latlong in latlongs])
    data_rows = np.array([edge[0] for edge in edges], dtype=int)
    data_cols = np.array([edge[1] for edge in edges], dtype=int)

    sparse_edges = csr_matrix((data_edges, (data_rows, data_cols)), shape=(n, n))
    MST_edge = minimum_spanning_tree(csgraph=sparse_edges).tocoo()
    edge_numbers = MST_edge.data
    edge_rows = MST_edge.row
    edge_cols = MST_edge.col

    sparse_times = csr_matrix((data_times, (data_rows, data_cols)), shape=(n, n))
    MST_time = minimum_spanning_tree(csgraph=sparse_times).tocoo()
    time_numbers = MST_time.data
    time_rows = MST_time.row
    time_cols = MST_time.col

    sparse_latlongs = csr_matrix((data_latlongs, (data_rows, data_cols)), shape=(n, n))
    MST_latlong = minimum_spanning_tree(csgraph=sparse_latlongs).tocoo()
    latlong_numbers = MST_latlong.data
    latlong_rows = MST_latlong.row
    latlong_cols = MST_latlong.col

    metric_m = np.ones((3, 3))

    ratio_1, ratio_2 = compare_metric(edge_dict, time_dict, edge_rows, edge_cols, time_rows, time_cols, n)
    metric_m[0][1] = ratio_1
    metric_m[1][0] = ratio_2
    ratio_1, ratio_2 = compare_metric(edge_dict, latlong_dict, edge_rows, edge_cols, latlong_rows, latlong_cols, n)
    metric_m[0][2] = ratio_1
    metric_m[2][0] = ratio_2
    ratio_1, ratio_2 = compare_metric(time_dict, latlong_dict, time_rows, time_cols, latlong_rows, latlong_cols, n)
    metric_m[1][2] = ratio_1
    metric_m[2][1] = ratio_2

    with open('./ny_metric_comparison.txt', 'w') as f:
        f.write("      edge      time      latlong\n")
        f.write("edge  ")
        f.write("{}  {}  {}\n".format(metric_m[0][0], metric_m[0][1], metric_m[0][2]))
        f.write("time  ")
        f.write("{}  {}  {}\n".format(metric_m[1][0], metric_m[1][1], metric_m[1][2]))
        f.write("latlong  ")
        f.write("{}  {}  {}\n".format(metric_m[2][0], metric_m[2][1], metric_m[2][2]))
        f.close()
    

    '''


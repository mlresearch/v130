import math
import numpy as np
from heapq import heapify, heappop, heappush
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import minimum_spanning_tree
from scipy.spatial.distance import euclidean
import time
import cProfile, pstats
import io

from numba import njit


def convert_to_string(vector):
    return ",".join([str(x) for x in vector])

def create_key_dict(hashed_keys):
    n = hashed_keys.shape[1]
    num_repeats = hashed_keys.shape[0]
    return {(pt, i): convert_to_string(hashed_keys[i, pt, :]) for i in range(num_repeats) for pt in range(n)}


# finds all hashing functions for a threshold
# dim = (# of repetition, # of dimensions, # of concatenation)
def generate_hashing_functions(delta, dim):
    rand_a = np.random.normal(0, 1.0, dim)
    rand_b = np.random.uniform(0, delta, (dim[0], dim[2]))
    return rand_a, rand_b

#hash the points into buckets
def bucketize(points, a, b, delta):
    #points: n*k, a: # of repeats * n * # of concats
    n = points.shape[0]
    hashed_keys = np.einsum("ij,kjl->kil", points, a) + np.repeat(b[:, np.newaxis, :], n, axis=1)
    hashed_keys = np.array(np.floor(hashed_keys / delta), dtype=int)
    num_repetition = hashed_keys.shape[0]
    num_concats = hashed_keys.shape[2]

    ds = []
    for i in range(num_repetition):
        buckets = {}
        for pt in range(n):
            key_value = convert_to_string(hashed_keys[i][pt])
            if key_value in buckets:
                buckets[key_value].append(pt)
            else:
                buckets[key_value] = [pt]
        ds.append(buckets)

    return ds, hashed_keys

# given a data structure and keys shape: # of repeats * # of concats
# n_neighbors is the upper-bound of neighbors to grab in a query
def NNquery(data_structure, key_dict, pt, n_neighbors):
    neighbors = set()
    num_repeats = len(data_structure)
    # do we need permute here?
    permute = list(np.random.permutation(num_repeats))
    collide = 0
    for i in permute:
        for neighbor in data_structure[i][key_dict[(pt, i)]]:
            if neighbor != pt:
                if collide < n_neighbors:
                    collide += 1
                    neighbors.add(neighbor)
                else:
                    break
        if collide >= n_neighbors:
            break
    return neighbors

# merge two components containing two points
def merge_components(pt1, pt2, comp_dict, comp_number_dict, point_comp_dict):
    head1 = point_comp_dict[pt1]
    head2 = point_comp_dict[pt2]
    if head1 == head2:
        return comp_dict[head1], False
    comp1 = comp_dict.pop(head1)
    comp2 = comp_dict.pop(head2)
    if comp_number_dict[head1] >= comp_number_dict[head2]:
        new_comp = comp1 + comp2
        comp_dict[head1] = new_comp
        comp_number_dict[head1] += comp_number_dict[head2]
        comp_number_dict.pop(head2)
        for pt in comp2:
            point_comp_dict[pt] = head1
    else:
        new_comp = comp2 + comp1
        comp_dict[head2] = new_comp
        comp_number_dict[head2] += comp_number_dict[head1]
        comp_number_dict.pop(head1)
        for pt in comp1:
            point_comp_dict[pt] = head2
    return new_comp, True


#given a data structure (buckets), a matrix of hashed_keys, a threshold and # of neighbors to check, for a list of components add some edges
#shape of data_structure: # of repeats * dictionrary of buckets, hashed_keys: # of repeats * n * # of concats
#comp_dict: which point belongs to which components
def LSH_round(comp_dict, comp_number_dict, point_comp_dict, key_dict, data_structure, hashed_keys, dist_matrix, delta, n_neighbors, tree_edges):

    num_repeats = hashed_keys.shape[0]
    comp_heap = [(len(comp_dict[head]), head, comp_dict[head]) for head in comp_dict.keys()]
    heapify(comp_heap)
    while comp_heap:
        (length, head, comp) = heappop(comp_heap)

        #check if it has already been merged with somebody else
        if length != comp_number_dict.get(head):
            continue

        #delete all points
        for pt in comp:
            for i in range(num_repeats):
                #key = convert_to_string(hashed_keys[i][pt][:])
                # if code is too slow consider implement it as a heap or a sorted array
                data_structure[i][key_dict[(pt, i)]].remove(pt)

        for pt in comp:
            neighbors = NNquery(data_structure, key_dict, pt, n_neighbors)
            for neighbor in neighbors:
                if dist_matrix[pt][neighbor] <= delta:
                    new_comp, merge_or_not = merge_components(pt, neighbor, comp_dict, comp_number_dict, point_comp_dict)
                    if merge_or_not:
                        #insert the new component into the heap
                        heappush(comp_heap, (len(new_comp), new_comp[0], new_comp))
                        #keep record of the edge
                        tree_edges.append([min(pt, neighbor), max(pt, neighbor), dist_matrix[pt][neighbor]])

        for pt in comp:
            for i in range(num_repeats):
                #key = convert_to_string(hashed_keys[i][pt][:])
                # if code is too slow consider implement it as a heap or a sorted array
                data_structure[i][key_dict[(pt, i)]].append(pt)

    return

#assume minimum distance is 1
def full_LSH(points, dist_matrix, d_min, eps, num_concats, num_repeats, n_neighbors, num_trials):
    (n, k) = points.shape
    dim = (num_repeats, k, num_concats)

    comp_dict = {i: [i] for i in range(n)}
    comp_number_dict = {i: 1 for i in range(n)}
    point_comp_dict = {i: i for i in range(n)}

    delta = float(d_min) / (1 + eps)
    width = (1 + eps) * delta

    tree_edges = []

    while len(comp_dict) > 1:
        # increase the threshold
        delta = delta * (1 + eps)
        width = width * (1 + eps)

        for i in range(num_trials):
            a, b = generate_hashing_functions(width, dim)
            ds, hashed_keys = bucketize(points, a, b, width)
            #create the key dictionary
            key_dict = create_key_dict(hashed_keys)
            LSH_round(comp_dict, comp_number_dict, point_comp_dict, key_dict, ds, hashed_keys, dist_matrix, delta, n_neighbors, tree_edges)
            if len(comp_dict) <= 1:
                break
    assert len(tree_edges) == n - 1
    return tree_edges

if __name__ == "__main__":

    np.random.seed(0)

    rho = 0.2
    k = 2
    eps = 1

    sample_sizes = [2 ** i * 100 for i in range(9)]

    for n in sample_sizes:
        print("sample size: %d " % n)
        num_concats = 4
        num_repeats = 3
        num_trials = 4
        n_neighbors = num_repeats

        dim = (num_repeats, k, num_concats)

        points = np.random.randint(low=0, high=n, size=(n, 2))
        dist_matrix = np.zeros((n, n))

        for i in range(n):
            for j in range(n):
                dist_matrix[i][j] = euclidean(points[i, :], points[j, :])

        print("starting MST now...")
        dist = np.triu(dist_matrix)

        begin = time.time()
        tree = minimum_spanning_tree(csgraph=dist).tocoo()
        real_obj = sum(tree.data)
        print("real obj: %f" % real_obj)
        end = time.time()
        print(end - begin)

        print("starting LSH now...")
        d_min = int(float(real_obj) / (2 * n))
        pr = cProfile.Profile()
        pr.enable()
        begin = time.time()
        tree_edges = full_LSH(points, dist_matrix, d_min, eps, num_concats, num_repeats, n_neighbors, num_trials)
        end = time.time()
        fake_obj = sum([edge[2] for edge in tree_edges])
        print("fake obj: %f" % fake_obj)
        print(end - begin)
        print("ratio: %f" % (fake_obj / real_obj))
        pr.disable()

        pr.dump_stats("profile")
        s = io.StringIO()
        p = pstats.Stats('profile', stream=s)

        p.strip_dirs().sort_stats('cumulative').print_stats()
        with open('profile.txt', 'w') as f:
            f.write(s.getvalue())
            f.close()
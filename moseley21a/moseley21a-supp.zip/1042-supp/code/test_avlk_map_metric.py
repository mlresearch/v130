from scipy.cluster.hierarchy import average as scipy_avlk
from scipy.cluster.hierarchy import to_tree
from scipy.sparse.csgraph import shortest_path
from scipy.spatial.distance import pdist, euclidean
from scipy.sparse import csr_matrix
from data_preprocess import load_data
from lsh_avlk_with_heaps import full_LSH_with_validation
from avlk_validation_helpers import calculate_hc_obj, vca_obj, create_parent_dict, average_linkage, distortion_ratio

import math
import numpy as np
import time
import statistics as stats
import os

def find_scale(coors, edge_rows, edge_cols, edge_weights):
    euclids = [euclidean(coors[edge_rows[i]], coors[edge_cols[i]]) for i in range(len(edge_weights))]
    return sum(edge_weights) / sum(euclids)

def check_edges(edge_rows, edge_cols, edge_weights, coors, nodes, city):
    all_coors = load_data("{}_latlong.co".format(city))
    all_coors = np.array([[x, y / 1e6, z / 1e6] for x, y, z in all_coors])
    all_edges = load_data("{}_dist.gr".format(city))
    all_edge_dict = {(edge[0], edge[1]): edge[2] for edge in all_edges if edge[0] < edge[1]}
    n = len(coors)
    m = len(edge_weights)
    for i in range(n):
        node = nodes[i]
        assert abs(coors[i][0] - all_coors[node - 1][1]) <= 0.001 or abs(coors[i][1] - all_coors[node - 1][2]) <= 0.001

    for j in range(m):
        assert edge_weights[j] == all_edge_dict[(nodes[edge_rows[j]], nodes[edge_cols[j]])]

    return

def avlk_validation(output, direc, city, num_instance, grid_size, eps, eps1, eps2, scale=1e6):
    print("grid size: %d" % grid_size)

    if not os.path.exists("./{}/{}".format(output, grid_size)):
        os.makedirs("./{}/{}".format(output, grid_size))

    obj_f = open("./{}/{}/{}_avlk_vca_obj.txt".format(output, grid_size, city), 'w')
    dc_f = open("./{}/{}/{}_avlk_dist_computation.txt".format(output, grid_size, city), 'w')
    approx_ratio_f = open("./{}/{}/{}_approx_ratio_stats.txt".format(output, grid_size, city), 'w')
    distortion_f = open("./{}/{}/{}_distortion_ratio_stats.txt".format(output, grid_size, city), 'w')

    obj_f.write("points    edges    lsh_ratio    euclid_ratio    avlk_vca    upperbound_vca\n")
    dc_f.write("points    edges    dist_computation \n")
    approx_ratio_f.write("points    edges    mean    median    60%    70%    80%    90%    max\n")
    distortion_f.write("points    edges    mean    median    60%    70%    80%    90%    max\n")

    for i in range(num_instance):
        print("instance %d" % i)
        coor_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subcoors", i))
        edge_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subedges", i))
        node_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subnodes", i))

        coors = []
        edge_rows = []
        edge_cols = []
        edge_weights = []
        nodes = []
        delim = ' '

        for line in coor_f.readlines():
            y = line.strip().split(delim)
            y = [float(x) * scale for x in y]
            coors.append(y)

        for line in edge_f.readlines():
            y = line.strip().split(delim)
            y = [int(x) for x in y]
            edge_rows.append(y[0])
            edge_cols.append(y[1])
            edge_weights.append(y[2])

        for line in node_f.readlines():
            y = line.strip().split(delim)
            nodes.extend([int(x) for x in y])

        # check_edges(edge_rows, edge_cols, edge_weights, coors, nodes, city)

        # calculate shortest path matrix
        n = len(nodes)
        if n >= 2222:
            continue
        m = len(edge_weights)
        print("# of points: %d, # of edges: %d" % (n, m))
        obj_f.write("{}   {}   ".format(str(n), str(m)))
        dc_f.write("{}   {}   ".format(str(n), str(m)))
        approx_ratio_f.write("{}   {}   ".format(str(n), str(m)))

        edge_weights = np.array(edge_weights, dtype=int)
        edge_rows = np.array(edge_rows, dtype=int)
        edge_cols = np.array(edge_cols, dtype=int)
        sparse_edges = csr_matrix((edge_weights, (edge_rows, edge_cols)), shape=(n, n))
        dist_matrix = shortest_path(csgraph=sparse_edges, method='D', directed=False)
        d_min = min(edge_weights)

        upper_bound = np.sum(dist_matrix) / 2 * n
        #euclidean dist matrix
        euclid_dist = np.zeros((n, n))
        for j in range(n):
            for l in range(j + 1, n):
                euclid_dist[j][l] = euclidean(coors[j], coors[l])
                euclid_dist[l][j] = euclid_dist[j][l]

        # start LSH
        print("start...")
        num_concats = 4
        num_repeats = 3
        num_trials = 4
        n_neighbors = 3 * num_repeats

        coors = np.array(coors)

        #true average linkage
        Z = pdist(dist_matrix)
        cluster_matrix = scipy_avlk(Z)
        scipy_root = to_tree(cluster_matrix)
        avlk_obj, _ = calculate_hc_obj(dist_matrix, scipy_root)

        print("vanilla avlk done")

        euclid_Z = pdist(euclid_dist)
        euclid_cluster_matrix = scipy_avlk(euclid_Z)
        euclid_scipy_root = to_tree(euclid_cluster_matrix)
        euclid_avlk_obj, _ = calculate_hc_obj(dist_matrix, euclid_scipy_root)

        print("euclid avlk done")

        distorts = distortion_ratio(dist_matrix, euclid_dist)

        tree_edges, dc, id_cluster_dict, approx_ratios = full_LSH_with_validation(coors, dist_matrix, d_min, eps, eps1,
                                                                                  eps2, num_concats, num_repeats,
                                                                                  n_neighbors, num_trials)
        print("lsh + validation done")

        parent_dict = create_parent_dict(tree_edges)
        lsh_obj = vca_obj(2 * n - 2, parent_dict, id_cluster_dict, dist_matrix)

        lsh_ratio = float(lsh_obj) / float(avlk_obj)
        euclid_ratio = float(euclid_avlk_obj) / float(avlk_obj)

        _, avlk_approx_ratios = average_linkage(np.copy(euclid_dist), np.copy(dist_matrix))
        print("proxy-avlk validation done")

        print("lsh ratio:", lsh_ratio, "euclid ratio:", euclid_ratio)
        obj_f.write("{}    {}    {}    {}\n".format(lsh_ratio, euclid_ratio, avlk_obj, upper_bound))

        print("# of dist computations:", dc)
        dc_f.write(str(dc) + '\n')

        quantiles1 = [q for q in stats.quantiles(approx_ratios, n=10)]
        quantiles2 = [q for q in stats.quantiles(avlk_approx_ratios, n=10)]
        print("mean:", stats.mean(approx_ratios), stats.mean(avlk_approx_ratios))
        print("median", stats.median(approx_ratios), stats.median(avlk_approx_ratios))
        print("60%", quantiles1[5], quantiles2[5])
        print("70%", quantiles1[6], quantiles2[6])
        print("80%", quantiles1[7], quantiles2[7])
        print("90%", quantiles1[8], quantiles2[8])
        print("max", max(approx_ratios), max(avlk_approx_ratios))

        distort_quantile = [q for q in stats.quantiles(distorts, n=10)]
        #optimize this
        approx_ratio_f.write("{}/{}  {}/{}  {}/{}  {}/{}  {}/{}  {}/{}  {}/{}\n".format(stats.mean(approx_ratios), stats.mean(avlk_approx_ratios), stats.median(approx_ratios), stats.median(avlk_approx_ratios), quantiles1[5], quantiles2[5], quantiles1[6], quantiles2[6], quantiles1[7], quantiles2[7], quantiles1[8], quantiles2[8], max(approx_ratios), max(avlk_approx_ratios)))
        distortion_f.write("{}  {}  {}  {}  {}  {}  {}\n".format(stats.mean(distorts), stats.median(distorts),
                                                                 distort_quantile[5], distort_quantile[6],
                                                                 distort_quantile[7], distort_quantile[8],
                                                                 max(distorts)))
        print("the maximum distortion ratio: %f" % max(distorts))

        obj_f.flush()
        dc_f.flush()
        approx_ratio_f.flush()
        distortion_f.flush()

    obj_f.close()
    dc_f.close()
    approx_ratio_f.close()
    distortion_f.close()

    return


if __name__ == "__main__":
    np.random.seed(0)
    num_instance = 5
    #grid_size_list = [40, 30, 20, 15, 10, 8, 5, 4]
    grid_size_list = [20, 15]
    city = 'ny'
    direc = 'samples'
    output = 'results_avlk_maps'
    scale = 1e6
    #eps_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    eps = 0.3
    eps1 = 2
    eps2 = 0.5
    for grid_size in grid_size_list:
        avlk_validation(output, direc, city, num_instance, grid_size, eps, eps1, eps2, scale)



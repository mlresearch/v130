import matplotlib.pyplot as plt


if __name__ == "__main__":
    city = 'lks'
    #if avlk
    #output = "./results_avlk_maps/dcs_{}_{}.txt".format('avlk', city)
    #if MST/sglk:
    output = "./final/{}_all_dist_counts.txt".format(city)
    output_f = open(output, 'r')
    next(output_f)
    values = []

    for line in output_f.readlines():
        y = line.strip().split(' ')
        new_line = [x for x in y if x != '']
        values.append([int(new_line[0]), int(new_line[2])])

    output_f.close()
    values.sort(key=lambda x: x[0])
    print(values)
    sizes = [val[0] for val in values]
    dcs = [val[1] for val in values]

    plt.xlabel("sample size")
    plt.ylabel("# of distance computations")
    plt.xscale('log')
    #change this according to sglk/avlk
    plt.plot(sizes, dcs, color='blue', label='Proxy-Hash-SL')

    #fit a fake line
    power = 1.2
    constant = float(dcs[0]) / (float(sizes[0]) ** power)
    fake_dcs = [constant * size ** power for size in sizes]
    plt.plot(sizes, fake_dcs, color='black', ls='--', label='Fitted Line, y=cx^{}'.format(power))
    plt.legend()

    #change this according to sglk/avlk
    #plt.savefig("./{}_{}_{}.pdf".format(city, 'dc', 'avlk'))
    plt.savefig("./{}_{}_{}.pdf".format(city, 'dc', 'sglk'))
    plt.show()

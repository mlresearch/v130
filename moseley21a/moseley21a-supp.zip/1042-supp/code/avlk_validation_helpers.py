import numpy as np
import math


#class node, every node has two children
class Node:
    def __init__(self, id = None, left = None, right = None, count = 0):
        self.id = id
        self.left = left
        self.right = right
        self.count = count

    def get_count(self):
        return self.count

    def get_id(self):
        return self.id

    def get_left(self):
        return self.left

    def get_right(self):
        return self.right

    def is_leaf(self):
        if self.left == None and self.right == None:
            return True
        return False

#create a dictionary of parents and their children
def create_parent_dict(edges):
    parent_dict = {}
    for edge in edges:
        parent_dict[edge[2]] = [edge[0], edge[1]]
    return parent_dict

def check_clusters(cluster1, cluster2, cluster):
    cluster_one = sorted(cluster1.copy() + cluster2.copy())
    cluster_two = sorted(cluster.copy())
    if len(cluster_one) != len(cluster_two):
        return False

    for i in range(len(cluster_one)):
        if cluster_one[i] != cluster_two[i]:
            return False

    return True

#rewrite this function later. too many calls.
def vca_obj(root_id, tree_dict, id_cluster_dict, dist_matrix):
    if root_id not in tree_dict:
        return 0.0
    left_id = tree_dict[root_id][0]
    right_id = tree_dict[root_id][1]
    assert check_clusters(id_cluster_dict[left_id], id_cluster_dict[right_id], id_cluster_dict[root_id])
    split = 0.0
    for i in id_cluster_dict[left_id]:
        for j in id_cluster_dict[right_id]:
            split += dist_matrix[i][j]
    value = split * len(id_cluster_dict[root_id])
    return value + vca_obj(left_id, tree_dict, id_cluster_dict, dist_matrix) + vca_obj(right_id, tree_dict, id_cluster_dict, dist_matrix)

#calculate cohen addad objective function using recursion, returns obj, children
def calculate_hc_obj(dist, root):
    if root.is_leaf():
        return 0, [root.get_id()]
    obj_left, tree_left = calculate_hc_obj(dist, root.get_left())
    obj_right, tree_right = calculate_hc_obj(dist, root.get_right())
    obj = 0.0
    count = root.get_count()
    for i in tree_left:
        for j in tree_right:
            obj += dist[i][j] * count

    if len(tree_left) + len(tree_right)!= root.get_count():
        print("Something went wrong...")
    return obj + obj_left + obj_right, tree_left + tree_right


# cluster1 and 2 both in the format of lists, dist_matrix is numpy array, avg_link calculates average linkage
def avg_link(cluster1, cluster2, dist_matrix):
    return float(np.sum(dist_matrix[cluster1, :][:, cluster2])) / (len(cluster1) * len(cluster2))

def min_avg_link(clusters, dist_matrix):
    m = len(clusters)
    assert m >= 2
    min_avg = math.inf
    index_1 = -1
    index_2 = -1
    for i in range(m):
        for j in range(i + 1, m):
            current_score = avg_link(clusters[i], clusters[j], dist_matrix)

            if current_score < min_avg:
                index_1 = i
                index_2 = j

                min_avg = current_score
    return index_1, index_2, min_avg

def find_min(dist):
    u = 0
    v = 1
    d_min = math.inf
    for i in range(len(dist)):
        for j in range(i):
            if dist[i][j] < d_min:
                u = np.minimum(i, j)
                v = np.maximum(i, j)
                d_min = dist[i][j]
    return u, v, d_min

def update_dist(dist, left_index, right_index, left_weight, right_weight):
    new_row = (dist[left_index,:] * left_weight + dist[right_index,:] * right_weight) / (left_weight + right_weight)
    dist = np.vstack((dist, new_row))
    new_row = np.append(new_row, 0)
    new_column = new_row.reshape((-1,1))
    dist = np.hstack((dist, new_column))
    dist = np.delete(dist, [left_index, right_index], axis=0)
    dist = np.delete(dist, [left_index, right_index], axis=1)
    return dist

def average_linkage(dist, dist_prime):
    #do avlk based on dist, but the actual distance measure being dist_prime
    n = dist.shape[0]
    leaves = [Node(id=id, left=None, right=None, count=1) for id in range(n)]
    current_id = n
    approx_ratios = []

    while len(leaves) > 1:
        left_index, right_index, _ = find_min(dist)

        left_node = leaves[left_index]
        right_node = leaves[right_index]
        left_weight = left_node.get_count()
        right_weight = right_node.get_count()
        new_node = Node(id=current_id, left=left_node, right=right_node, count=left_weight + right_weight)
        current_id += 1
        leaves.append(new_node)

        # record ratios
        _, _, real_min = find_min(dist_prime)

        approx_ratios.append(dist_prime[left_index][right_index] / real_min)

        dist = update_dist(dist, left_index, right_index, left_weight, right_weight)
        dist_prime = update_dist(dist_prime, left_index, right_index, left_weight, right_weight)


        del leaves[right_index]
        del leaves[left_index]

    return leaves[0], approx_ratios

def distortion_ratio(dist, dist_prime):
    n = dist.shape[0]
    assert dist_prime.shape[0] == n
    assert n >= 2

    min_ratio = float(dist[1][0]) / dist_prime[1][0]

    for i in range(n):
        for j in range(i):
            if float(dist[i][j]) / dist_prime[i][j] < min_ratio:
                min_ratio = float(dist[i][j]) / dist_prime[i][j]
    scale = 1 / min_ratio

    ratios = []
    for i in range(n):
        for j in range(i):
            this_ratio = scale * float(dist[i][j]) / dist_prime[i][j]
            ratios.append(this_ratio)
    return ratios

def dimension_reduction(data, target_dimension):
    num_dimension = data.shape[1]
    JL_matrix = np.random.normal(loc=0, scale=1.0 / target_dimension, size=(num_dimension, target_dimension))
    return np.matmul(data, JL_matrix)


if __name__ == "__main__":
    dist = np.array([[0., 1.0, 2.5], [1.0, 0., 1.2], [2.5, 1.2, 0.]])
    dist_prime = np.array([[0., 1.2, 5.0], [1.2, 0., 0.4], [5.0, 0.4, 0.]])
    ratios = distortion_ratio(dist, dist_prime)
    print(ratios)
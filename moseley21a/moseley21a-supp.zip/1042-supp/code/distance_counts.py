import math
import numpy as np
#baselines
from scipy.sparse.csgraph import minimum_spanning_tree, shortest_path
from scipy.cluster.hierarchy import single as scipy_single
from scipy.spatial.distance import pdist
from sklearn.cluster import AgglomerativeClustering
from fastcluster import single as fast_single


from scipy.sparse import csr_matrix
from scipy.spatial.distance import euclidean
from data_preprocess import load_data
from lsh_MST_counter import full_LSH
import time

def find_scale(coors, edge_rows, edge_cols, edge_weights):
    euclids = [euclidean(coors[edge_rows[i]], coors[edge_cols[i]]) for i in range(len(edge_weights))]
    return sum(edge_weights) / sum(euclids)

def check_edges(edge_rows, edge_cols, edge_weights, coors, nodes, city):
    all_coors = load_data("{}_latlong.co".format(city))
    all_coors = np.array([[x, y / 1e6, z / 1e6] for x, y, z in all_coors])
    all_edges = load_data("{}_dist.gr".format(city))
    all_edge_dict = {(edge[0], edge[1]): edge[2] for edge in all_edges if edge[0] < edge[1]}
    n = len(coors)
    m = len(edge_weights)
    for i in range(n):
        node = nodes[i]
        assert abs(coors[i][0] - all_coors[node - 1][1]) <= 0.001 or abs(coors[i][1] - all_coors[node - 1][2]) <= 0.001

    for j in range(m):
        assert edge_weights[j] == all_edge_dict[(nodes[edge_rows[j]], nodes[edge_cols[j]])]

    return


def grid_size_distance_counts(output, direc, city, num_instance, grid_size, eps_list, scale=1e6):
    print("grid size: %d" % grid_size)
    out_f = open("./{}/{}/{}_dist_counts.txt".format(output, grid_size, city), 'w')

    for eps in eps_list:
        out_f.write("LSH time_{}  ".format(str(eps)))
    out_f.write("\n")

    for i in range(num_instance):
        print("instance %d" % i)
        coor_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subcoors", i))
        edge_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subedges", i))
        node_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subnodes", i))

        coors = []
        edge_rows = []
        edge_cols = []
        edge_weights = []
        nodes = []
        delim = ' '

        for line in coor_f.readlines():
            y = line.strip().split(delim)
            y = [float(x) * scale for x in y]
            coors.append(y)

        for line in edge_f.readlines():
            y = line.strip().split(delim)
            y = [int(x) for x in y]
            edge_rows.append(y[0])
            edge_cols.append(y[1])
            edge_weights.append(y[2])

        for line in node_f.readlines():
            y = line.strip().split(delim)
            nodes.extend([int(x) for x in y])

        # check_edges(edge_rows, edge_cols, edge_weights, coors, nodes, city)

        # calculate shortest path matrix
        n = len(nodes)
        m = len(edge_weights)
        print("# of points: %d, # of edges: %d" % (n, m))
        out_f.write("{}  ".format(str(n)))

        edge_weights = np.array(edge_weights, dtype=int)
        edge_rows = np.array(edge_rows, dtype=int)
        edge_cols = np.array(edge_cols, dtype=int)
        sparse_edges = csr_matrix((edge_weights, (edge_rows, edge_cols)), shape=(n, n))
        dist_matrix = shortest_path(csgraph=sparse_edges, method='D', directed=False)
        d_min = min(edge_weights)

        # start LSH

        k = 2
        num_concats = 4
        num_repeats = 3
        num_trials = 4
        n_neighbors = num_repeats
        dim = (num_repeats, k, num_concats)

        coors = np.array(coors)

        for eps in eps_list:
            tree_edges, dist_counters = full_LSH(coors, dist_matrix, d_min, eps, num_concats, num_repeats, n_neighbors, num_trials)

            out_f.write("{} ".format(dist_counters))
            out_f.flush()

        out_f.write("\n\n")

    out_f.close()

    return


if __name__ == "__main__":
    num_instance = 5
    grid_size_list = [40, 30, 20, 15, 10, 8, 5, 4]
    city = 'ny'
    direc = 'samples'
    output = 'results'
    scale = 1e6
    eps_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]

    for grid_size in grid_size_list:
        grid_size_distance_counts(output, direc, city, num_instance, grid_size, eps_list, scale)

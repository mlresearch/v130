from scipy.cluster.hierarchy import average as scipy_avlk
from scipy.cluster.hierarchy import to_tree
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import minimum_spanning_tree
from scipy.spatial.distance import pdist, euclidean
from scipy.sparse import csr_matrix
from data_preprocess import load_data
from lsh_MST_counter import full_LSH
from avlk_validation_helpers import calculate_hc_obj, vca_obj, create_parent_dict, average_linkage, find_min, \
    distortion_ratio, dimension_reduction

import math
import numpy as np
import time
import statistics as stats
import os


def pairwise_dist(points, norm):
    n = len(points)
    dist = np.zeros((n, n))
    for i in range(n):
        for j in range(i):
            dist[i][j] = np.linalg.norm(np.array(points[i]) - np.array(points[j]), ord=norm)
            dist[j][i] = dist[i][j]
    return dist


def sglk_validation(output, direc, file_name, num_instance, size, eps):
    print("sample size: %d" % size)

    # create the directory for storing results
    if not os.path.exists("./{}/{}_{}".format(output, file_name, size)):
        os.makedirs("./{}/{}_{}".format(output, file_name, size))

    obj_f = open("./{}/{}_{}/sglk_vca_obj.txt".format(output, file_name, size), 'w')
    dc_f = open("./{}/{}_{}/sglk_dist_computation.txt".format(output, file_name, size), 'w')
    distortion_f = open("./{}/{}_{}/distortion_ratio_stats_4.txt".format(output, file_name, size), 'w')

    obj_f.write("lsh ratio    fake euclid ratio    MST obj\n")
    distortion_f.write("mean    median    60%    70%    80%    90%    max\n")

    for i in range(num_instance):
        print("instance %d" % i)
        input_f = open("./{}/{}_{}/{}.txt".format(direc, file_name, size, i))

        delim = ' '
        data = []

        for line in input_f.readlines():
            y = line.strip().split(delim)
            y = [float(x) for x in y]
            # delete repeating points
            check = True
            for pt in data:
                if np.linalg.norm(np.array(pt) - np.array(y), ord=2) <= 0.0001:
                    check = False
                    break
            if check == False:
                continue
            data.append(y)

        n = len(data)

        # calculate metrics

        dist_matrix = pairwise_dist(data, norm=2)

        data = np.array(data)
        projected_data = dimension_reduction(data, 4)


        fake_dist = pairwise_dist(projected_data, norm=2)
        _, _, d_min = find_min(dist_matrix)
        #d_min = np.sum(dist_matrix) / (n * (n - 1) * 10)
        scale = 3.0
        projected_data = projected_data * scale
        fake_dist = fake_dist * scale

        sparse_dist = csr_matrix(dist_matrix)
        MST_real = minimum_spanning_tree(csgraph=sparse_dist).tocoo()
        MST_cost = sum(MST_real.data)

        sparse_fake_dist = csr_matrix(fake_dist)
        MST_euclid = minimum_spanning_tree(csgraph=sparse_fake_dist).tocoo()

        euclid_rows = MST_euclid.row
        euclid_cols = MST_euclid.col
        assert euclid_rows.shape[0] == n - 1
        MST_fake_cost = sum([dist_matrix[euclid_rows[j]][euclid_cols[j]] for j in range(n - 1)])

        distorts = distortion_ratio(dist_matrix, fake_dist)
        distort_quantile = [q for q in stats.quantiles(distorts, n=10)]
        distortion_f.write("{}  {}  {}  {}  {}  {}  {}\n".format(stats.mean(distorts), stats.median(distorts),
                                                                 distort_quantile[5], distort_quantile[6],
                                                                 distort_quantile[7], distort_quantile[8],
                                                                 max(distorts)))
        print("the maximum distortion ratio: %f" % max(distorts))


        # start LSH
        print("start...")
        num_concats = 4
        num_repeats = 3
        num_trials = 4

        n_neighbors = num_repeats

        # true average linkage
        Z = pdist(dist_matrix)
        cluster_matrix = scipy_avlk(Z)
        scipy_root = to_tree(cluster_matrix)
        avlk_obj, _ = calculate_hc_obj(dist_matrix, scipy_root)

        print("real sglk:", MST_cost)
        print("fake sglk:", MST_fake_cost)

        tree_edges, dc = full_LSH(projected_data, dist_matrix, d_min, eps, num_concats, num_repeats, n_neighbors, num_trials)
        print("lsh + validation done")

        lsh_obj = sum([edge[2] for edge in tree_edges])

        lsh_ratio = float(lsh_obj) / float(MST_cost)
        euclid_ratio = float(MST_fake_cost) / float(MST_cost)

        print("lsh ratio:", lsh_ratio, "euclid ratio:", euclid_ratio)
        obj_f.write("{}    {}    ".format(lsh_ratio, euclid_ratio) + "%.4e\n" % MST_cost)

        print("# of dist computations:", dc)
        dc_f.write(str(dc) + ' ')

        obj_f.flush()
        dc_f.flush()
        distortion_f.flush()

    obj_f.close()
    dc_f.close()
    distortion_f.close()

    return


if __name__ == "__main__":
    num_instance = 5
    sample_sizes = [2 ** k * 100 for k in range(7)]
    data_name = 'seizure'
    direc = 'samples_' + data_name
    output = 'results_with_jl_sglk_new'

    # eps_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    eps = 0.5
    for size in sample_sizes:
        sglk_validation(output, direc, data_name, num_instance, size, eps)



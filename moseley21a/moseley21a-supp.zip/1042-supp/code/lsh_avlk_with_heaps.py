import math
import numpy as np
from heapq import heapify, heappop, heappush
from scipy.cluster.hierarchy import average as scipy_avlk
from scipy.cluster.hierarchy import to_tree
from scipy.sparse.csgraph import minimum_spanning_tree
from scipy.spatial.distance import pdist, euclidean
from scipy.sparse import csr_matrix

from avlk_validation_helpers import calculate_hc_obj, vca_obj, create_parent_dict, min_avg_link, avg_link, average_linkage
import time
import cProfile, pstats
import io
import matplotlib.pyplot as plt

from numba import njit

#below is the list of functions for ANN data structures
def convert_to_string(vector):
    return ",".join([str(x) for x in vector])

#maintain a dictionary (pt, i): the key string of point pt in the ith round
def create_key_dict(hashed_keys):
    n = hashed_keys.shape[1]
    num_repeats = hashed_keys.shape[0]
    return {(pt, i): convert_to_string(hashed_keys[i, pt, :]) for i in range(num_repeats) for pt in range(n)}


# finds all hashing functions for a threshold
# dim = (# of repetition, # of dimensions, # of concatenation)
def generate_hashing_functions(delta, dim):
    rand_a = np.random.normal(0, 1.0, dim)
    rand_b = np.random.uniform(0, delta, (dim[0], dim[2]))
    return rand_a, rand_b

#hash the points into buckets
def bucketize(points, a, b, delta, indices):
    #points: n*k, a: # of repeats * n * # of concats
    n = points.shape[0]
    hashed_keys = np.einsum("ij,kjl->kil", points, a) + np.repeat(b[:, np.newaxis, :], n, axis=1)
    hashed_keys = np.array(np.floor(hashed_keys / delta), dtype=int)
    num_repetition = hashed_keys.shape[0]
    num_concats = hashed_keys.shape[2]

    ds = []
    for i in range(num_repetition):
        buckets = {}
        for pt in range(n):
            if pt in indices:
                key_value = convert_to_string(hashed_keys[i][pt])
                if key_value in buckets:
                    buckets[key_value].append(pt)
                else:
                    buckets[key_value] = [pt]
        ds.append(buckets)

    return ds, hashed_keys


# given a data structure and keys shape: # of repeats * # of concats
# n_neighbors is the upper-bound of neighbors to grab in a query
def NNquery(data_structure, key_dict, pt, n_neighbors):
    neighbors = set()
    num_repeats = len(data_structure)
    # do we need to permute here?
    permute = list(np.random.permutation(num_repeats))
    collide = 0
    for i in permute:
        for neighbor in data_structure[i][key_dict[(pt, i)]]:
            if neighbor != pt:
                if collide < n_neighbors:
                    collide += 1
                    neighbors.add(neighbor)
                else:
                    break
        if collide >= n_neighbors:
            break
    return neighbors


#below is the code for cluster embeddings and cluster mergings
#merge two clusters with embedded centers
def merge_cluster(center1, center2, eps2, center_sample_size, center_dict, deviation_dict, update_dict, dist_matrix):
    #eps1: parameter for choosing number of samples
    #eps2: parameter for re-sampling
    #return: a new center, and the number of distance computations
    cluster1 = center_dict[center1]
    cluster2 = center_dict[center2]
    new_cluster = cluster1.copy() + cluster2.copy()
    s_1 = update_dict[center1]
    s_2 = update_dict[center2]
    new_size = len(cluster1) + len(cluster2)
    s = max(s_1, s_2)

    #if the size grows very little, don't resample
    if new_size <= (1 + eps2) * s:
        if s_2 > s_1:
            update_dict.pop(center1)
            deviation_dict.pop(center1)
            center_dict[center2] += center_dict.pop(center1)
            return center2, 0, new_cluster
        else:
            update_dict.pop(center2)
            deviation_dict.pop(center2)
            center_dict[center1] += center_dict.pop(center2)
            return center1, 0, new_cluster

    #if the size grows significantly, resample
    update_dict.pop(center1)
    update_dict.pop(center2)
    center_dict.pop(center1)
    center_dict.pop(center2)
    deviation_dict.pop(center1)
    deviation_dict.pop(center2)
    new_cluster = cluster1.copy() + cluster2.copy()


    if center_sample_size >= len(new_cluster):
        samples = new_cluster.copy()
    else:
        samples = np.random.choice(new_cluster, size=(center_sample_size, ))

   #samples = np.random.choice(new_cluster, size=(center_sample_size,))
    dist_computations = min(center_sample_size, len(new_cluster)) * len(new_cluster)
    center = None
    total_dist = math.inf
    for sp in samples:
        new_dist = sum(dist_matrix[sp, new_cluster])
        if new_dist < total_dist:
            total_dist = new_dist
            center = sp

    update_dict[center] = len(new_cluster)
    center_dict[center] = new_cluster
    deviation_dict[center] = total_dist / len(new_cluster)
    return center, dist_computations, new_cluster


#given a data structure (buckets), a matrix of hashed_keys, a threshold and # of neighbors to check, for a list of components add some edges
#shape of data_structure: # of repeats * dictionrary of buckets, hashed_keys: # of repeats * n * # of concats
#center_dict: center: list of points in that cluster
#update_dict: dictionary of every current cluster, the latest time when it is updated
#deviation_dict: \sigma value for every current cluster
#center_id_dict: every center and the node id in the tree corresponding to it
#tree_edges: edges in the hierarchical clustering tree
def LSH_round(center_dict, update_dict, deviation_dict, center_id_dict, id_cluster_dict, eps2, center_sample_size, key_dict,
              data_structure, hashed_keys, dist_matrix, delta, n_neighbors, tree_edges):

    num_repeats = hashed_keys.shape[0]
    n = dist_matrix.shape[0]

    #make a heap of centers
    center_heap = [(len(center_dict[center]), center) for center in center_dict.keys()]
    heapify(center_heap)

    dist_computations = 0

    #initialize all the final dictionaries

    final_center_dict = {}
    final_update_dict = {}
    final_deviation_dict = {}
    final_center_id_dict = {}


    while center_heap:
        (length, center) = heappop(center_heap)

        #check if it has already been merged with somebody else
        if center_dict.get(center) is None:
            continue
        if length != len(center_dict.get(center)):
            continue

        '''
        print("querying center: ", center)
        print("clustering: ", center_dict[center])
        '''
        #delete the center first
        for i in range(num_repeats):
            #key = convert_to_string(hashed_keys[i][pt][:])
            # if code is too slow consider implement it as a heap or a sorted array
            data_structure[i][key_dict[(center, i)]].remove(center)

        neighbors = NNquery(data_structure, key_dict, center, n_neighbors)
        merge = False
        for neighbor in neighbors:
            dist_computations += 1
            if dist_matrix[center][neighbor] <= delta:
                merge = True
                for i in range(num_repeats):
                    data_structure[i][key_dict[(neighbor, i)]].remove(neighbor)

                #print("merge: %d, %d, %f" % (center, neighbor, dist_matrix[center][neighbor]))

                new_center, new_dist_computations, _ = merge_cluster(center, neighbor, eps2, center_sample_size, center_dict, deviation_dict, update_dict, dist_matrix)
                dist_computations += new_dist_computations
                # keep record of the edge
                new_id = n + len(tree_edges)
                id1 = center_id_dict[center]
                id2 = center_id_dict[neighbor]
                center_id_dict.pop(center)
                center_id_dict.pop(neighbor)
                center_id_dict[new_center] = new_id
                id_cluster_dict[new_id] = id_cluster_dict[id1].copy() + id_cluster_dict[id2].copy()
                tree_edges.append((id1, id2, new_id))

                #do the filtering test on the new cluster/center
                if deviation_dict[new_center] > 4 * delta:
                    final_center_dict[new_center] = center_dict.pop(new_center)
                    final_update_dict[new_center] = update_dict.pop(new_center)
                    final_deviation_dict[new_center] = deviation_dict.pop(new_center)
                    final_center_id_dict[new_center] = new_id
                else:
                    heappush(center_heap, (len(center_dict[new_center]), new_center))

                    #add the new center into the data structure
                    for i in range(num_repeats):
                        #key = convert_to_string(hashed_keys[i][pt][:])
                        # if code is too slow consider implement it as a heap or a sorted array
                        if key_dict[(new_center, i)] in data_structure[i]:
                            data_structure[i][key_dict[(new_center, i)]].append(new_center)
                        else:
                            data_structure[i][key_dict[(new_center, i)]] = [new_center]
                '''
                print("centers:", center_dict)
                print("updates:", update_dict)
                print("devs:", deviation_dict)
                print("ids:", center_id_dict)
                print("tree:", tree_edges)
                print(id_cluster_dict)
                print("data structure:")
                print(data_structure)
                '''
                break

        # remove this center from all dictionaries because it's no longer valid
        if merge == False:
            #print("didn't find any neighbor...")

            final_center_dict[center] = center_dict.pop(center)
            final_update_dict[center] = update_dict.pop(center)
            final_deviation_dict[center] = deviation_dict.pop(center)
            final_center_id_dict[center] = center_id_dict.pop(center)

            '''
            print("centers:", center_dict)
            print("updates:", update_dict)
            print("devs:", deviation_dict)
            print("ids:", center_id_dict)
            print("tree:", tree_edges)
            print(id_cluster_dict)
            print("data structure:")
            print(data_structure)

            print("FINAL")
            print("centers:", final_center_dict)
            print("updates:", final_update_dict)
            print("devs:", final_deviation_dict)
            print("ids:", final_center_id_dict)
            '''


    return final_center_dict, final_update_dict, final_deviation_dict, final_center_id_dict, dist_computations

def LSH_round_with_validation(center_dict, update_dict, deviation_dict, center_id_dict, id_cluster_dict, eps2, center_sample_size, key_dict,
              data_structure, hashed_keys, dist_matrix, delta, n_neighbors, tree_edges, approx_ratios):

    num_repeats = hashed_keys.shape[0]
    n = dist_matrix.shape[0]

    #make a heap of centers
    center_heap = [(len(center_dict[center]), center) for center in center_dict.keys()]
    heapify(center_heap)

    dist_computations = 0

    #initialize all the final dictionaries

    final_center_dict = {}
    final_update_dict = {}
    final_deviation_dict = {}
    final_center_id_dict = {}

    while center_heap:
        (length, center) = heappop(center_heap)

        #check if it has already been merged with somebody else
        if center_dict.get(center) is None:
            continue
        if length != len(center_dict.get(center)):
            continue

        '''
        print("querying center: ", center)
        print("clustering: ", center_dict[center])
        '''
        #delete the center first
        for i in range(num_repeats):
            #key = convert_to_string(hashed_keys[i][pt][:])
            # if code is too slow consider implement it as a heap or a sorted array
            data_structure[i][key_dict[(center, i)]].remove(center)

        neighbors = NNquery(data_structure, key_dict, center, n_neighbors)
        merge = False
        for neighbor in neighbors:
            dist_computations += 1
            if dist_matrix[center][neighbor] <= delta:
                merge = True

                #compute the ratio
                clusters = [center_dict[c] for c in center_dict] + [final_center_dict[c] for c in final_center_dict]
                _, _, min_avlk = min_avg_link(clusters, dist_matrix)
                #delete this later
                if min_avlk == 0:
                    min_avlk = d_min
                real_avlk = avg_link(center_dict[center], center_dict[neighbor], dist_matrix)

                approx_ratios.append(real_avlk / min_avlk)
                for i in range(num_repeats):
                    data_structure[i][key_dict[(neighbor, i)]].remove(neighbor)

                #print("merge: %d, %d, %f" % (center, neighbor, dist_matrix[center][neighbor]))

                new_center, new_dist_computations, _ = merge_cluster(center, neighbor, eps2, center_sample_size, center_dict, deviation_dict, update_dict, dist_matrix)
                dist_computations += new_dist_computations
                # keep record of the edge
                new_id = n + len(tree_edges)
                id1 = center_id_dict[center]
                id2 = center_id_dict[neighbor]
                center_id_dict.pop(center)
                center_id_dict.pop(neighbor)
                center_id_dict[new_center] = new_id
                id_cluster_dict[new_id] = id_cluster_dict[id1].copy() + id_cluster_dict[id2].copy()
                tree_edges.append((id1, id2, new_id))

                #do the filtering test on the new cluster/center
                if deviation_dict[new_center] > 4 * delta:
                    final_center_dict[new_center] = center_dict.pop(new_center)
                    final_update_dict[new_center] = update_dict.pop(new_center)
                    final_deviation_dict[new_center] = deviation_dict.pop(new_center)
                    final_center_id_dict[new_center] = new_id
                else:
                    heappush(center_heap, (len(center_dict[new_center]), new_center))

                    #add the new center into the data structure
                    for i in range(num_repeats):
                        #key = convert_to_string(hashed_keys[i][pt][:])
                        # if code is too slow consider implement it as a heap or a sorted array
                        if key_dict[(new_center, i)] in data_structure[i]:
                            data_structure[i][key_dict[(new_center, i)]].append(new_center)
                        else:
                            data_structure[i][key_dict[(new_center, i)]] = [new_center]
                '''
                print("centers:", center_dict)
                print("updates:", update_dict)
                print("devs:", deviation_dict)
                print("ids:", center_id_dict)
                print("tree:", tree_edges)
                print(id_cluster_dict)
                print("data structure:")
                print(data_structure)
                '''
                break

        # remove this center from all dictionaries because it's no longer valid
        if merge == False:
            #print("didn't find any neighbor...")

            final_center_dict[center] = center_dict.pop(center)
            final_update_dict[center] = update_dict.pop(center)
            final_deviation_dict[center] = deviation_dict.pop(center)
            final_center_id_dict[center] = center_id_dict.pop(center)

            '''
            print("centers:", center_dict)
            print("updates:", update_dict)
            print("devs:", deviation_dict)
            print("ids:", center_id_dict)
            print("tree:", tree_edges)
            print(id_cluster_dict)
            print("data structure:")
            print(data_structure)

            print("FINAL")
            print("centers:", final_center_dict)
            print("updates:", final_update_dict)
            print("devs:", final_deviation_dict)
            print("ids:", final_center_id_dict)
            '''


    return final_center_dict, final_update_dict, final_deviation_dict, final_center_id_dict, dist_computations


#assume minimum distance is 1
def full_LSH(points, dist_matrix, d_min, eps, eps1, eps2, num_concats, num_repeats, n_neighbors, num_trials):
    (n, k) = points.shape
    dim = (num_repeats, k, num_concats)

    center_sample_size = math.ceil(1 / eps1 * np.log(n))
    dist_computations = 0

    center_dict = {pt: [pt] for pt in range(n)}
    update_dict = {pt: 1 for pt in range(n)}
    deviation_dict = {pt: 0 for pt in range(n)}
    center_id_dict = {pt: pt for pt in range(n)}
    id_cluster_dict = {pt: [pt] for pt in range(n)}

    delta = float(d_min) / (1 + eps)
    width = (1 + eps) * delta

    tree_edges = []

    while len(center_dict) > 1:
        # increase the threshold
        delta = delta * (1 + eps)
        width = width * (1 + eps)

        for i in range(num_trials):
            #print("\n")
            #print("new round starts...")

            indices = list(center_dict.keys())
            #print("all points:", indices)

            a, b = generate_hashing_functions(width, dim)
            ds, hashed_keys = bucketize(points, a, b, width, indices)
            #create the key dictionary
            key_dict = create_key_dict(hashed_keys)

            center_dict, update_dict, deviation_dict, center_id_dict, dc = LSH_round(center_dict, update_dict, deviation_dict, center_id_dict, id_cluster_dict, eps2, center_sample_size, key_dict,
                      ds, hashed_keys, dist_matrix, delta, n_neighbors, tree_edges)

            dist_computations += dc
            if len(center_dict) <= 1:
                break
    assert len(tree_edges) == n - 1
    return tree_edges, dist_computations, id_cluster_dict


def full_LSH_with_validation(points, dist_matrix, d_min, eps, eps1, eps2, num_concats, num_repeats, n_neighbors, num_trials):
    (n, k) = points.shape
    dim = (num_repeats, k, num_concats)

    center_sample_size = math.ceil(1 / eps1 * np.log(n))
    dist_computations = 0

    center_dict = {pt: [pt] for pt in range(n)}
    update_dict = {pt: 1 for pt in range(n)}
    deviation_dict = {pt: 0 for pt in range(n)}
    center_id_dict = {pt: pt for pt in range(n)}
    id_cluster_dict = {pt: [pt] for pt in range(n)}

    delta = float(d_min) / (1 + eps)
    width = (1 + eps) * delta

    tree_edges = []
    approx_ratios = []

    while len(center_dict) > 1:
        # increase the threshold
        delta = delta * (1 + eps)
        width = width * (1 + eps)

        for i in range(num_trials):
            #print("\n")
            #print("new round starts...")

            indices = list(center_dict.keys())
            #print("all points:", indices)

            a, b = generate_hashing_functions(width, dim)
            ds, hashed_keys = bucketize(points, a, b, width, indices)
            #create the key dictionary
            key_dict = create_key_dict(hashed_keys)

            #print(clusters)

            center_dict, update_dict, deviation_dict, center_id_dict, dc = LSH_round_with_validation(center_dict, update_dict, deviation_dict, center_id_dict, id_cluster_dict, eps2, center_sample_size, key_dict,
                      ds, hashed_keys, dist_matrix, delta, n_neighbors, tree_edges, approx_ratios)


            dist_computations += dc
            if len(center_dict) <= 1:
                break
    assert len(tree_edges) == n - 1
    return tree_edges, dist_computations, id_cluster_dict, approx_ratios

if __name__ == "__main__":

    np.random.seed(0)

    rho = 0.2
    k = 2
    eps = 1
    eps1 = 2
    eps2 = 0.5

    #sample_sizes = [2 ** i * 100 for i in range(5)]
    sample_sizes = [100]
    num_exps = 1
    times = []
    dist_computations = []

    pr = cProfile.Profile()
    pr.enable()

    for n in sample_sizes:
        print("sample size: %d " % n)
        num_concats = 4
        num_repeats = 3
        num_trials = 4
        n_neighbors = 3 * num_repeats

        dim = (num_repeats, k, num_concats)
        total_time = 0.0
        total_dist_comps = 0
        for l in range(num_exps):

            points = np.random.randint(low=0, high=n, size=(n, 2))
            dist_matrix = np.zeros((n, n))
            fake_dist = np.zeros((n, n))

            for i in range(n):
                for j in range(i + 1, n):
                    dist_matrix[i][j] = euclidean(points[i, :], points[j, :])
                    dist_matrix[j][i] = dist_matrix[i][j]
                    #factor = 2
                    factor = np.random.uniform(1, 5)
                    coin = np.random.uniform(0, 1)
                    if coin >= 0.5:
                        fake_dist[i][j] = dist_matrix[i][j] * factor
                    else:
                        fake_dist[i][j] = dist_matrix[i][j] / factor
                    fake_dist[j][i] = fake_dist[i][j]

            dist = np.triu(dist_matrix)
            tree = minimum_spanning_tree(csgraph=dist).tocoo()
            real_obj = sum(tree.data)
            d_min = max(int(float(real_obj) / (2 * n)), 1)

            Z = pdist(dist_matrix)
            cluster_matrix = scipy_avlk(Z)
            scipy_root = to_tree(cluster_matrix)
            avlk_obj, _ = calculate_hc_obj(dist_matrix, scipy_root)

            fake_Z = pdist(fake_dist)
            fake_cluster_matrix = scipy_avlk(fake_Z)
            fake_scipy_root = to_tree(fake_cluster_matrix)
            fake_avlk_obj, _ = calculate_hc_obj(dist_matrix, fake_scipy_root)

            begin = time.time()
            tree_edges, dc, id_cluster_dict, approx_ratios = full_LSH_with_validation(points, dist_matrix, d_min, eps, eps1, eps2, num_concats, num_repeats, n_neighbors, num_trials)
            end = time.time()

            parent_dict = create_parent_dict(tree_edges)
            lsh_obj = vca_obj(2 * n - 2, parent_dict, id_cluster_dict, dist_matrix)

            _, proxy_approx_ratios = average_linkage(np.copy(fake_dist), np.copy(dist_matrix))

            print(float(lsh_obj) / float(avlk_obj), float(fake_avlk_obj) / float(avlk_obj))

            print(approx_ratios)
            print(proxy_approx_ratios)
            plt.hist(approx_ratios, bins=10)
            plt.show()

            total_time += (end - begin)
            total_dist_comps += dc

        times.append(total_time / num_exps)
        dist_computations.append(float(total_dist_comps) / num_exps)


    pr.disable()
    pr.dump_stats("profile")
    s = io.StringIO()
    p = pstats.Stats('profile', stream=s)
            
    p.strip_dirs().sort_stats('cumulative').print_stats()
    with open('avlk_profile.txt', 'w') as f:
        f.write(s.getvalue())
        f.close()

    print(times)
    print(dist_computations)


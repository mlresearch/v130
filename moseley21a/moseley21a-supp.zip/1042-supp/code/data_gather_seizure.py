import numpy as np
import matplotlib.pyplot as plt

def read_sglk(output, data_name, sizes, num_instance):
    obj_f = open("{}/{}_{}.txt".format(output, data_name, 'objs'), 'w')
    dc_f = open("{}/{}_{}.txt".format(output, data_name, 'dcs'), 'w')
    avg_dcs = []
    for size in sizes:
        obj_output_f = open("{}/{}_{}/sglk_vca_obj.txt".format(output, data_name, size), 'r')
        dc_output_f = open("{}/{}_{}/sglk_dist_computation.txt".format(output, data_name, size), 'r')
        next(obj_output_f)
        obj_f.write(str(size) + ' ')
        dc_f.write(str(size) + ' ')
        delim = ' '
        objs = []
        for i in range(num_instance):
            line = obj_output_f.readline()
            line = line.strip().split(delim)
            line = [float(x) for x in line if x != '']
            line = line[:2]
            objs.append(line)
        averages = np.average(np.array(objs), axis=0)
        obj_f.write(str(averages[0]) + " " + str(averages[1]))
        obj_f.write("\n")
        obj_output_f.close()

        line = dc_output_f.readline()
        line = line.strip().split(" ")
        dcs = [int(x) for x in line if x != '']
        dc_average = sum(dcs) / len(dcs)
        avg_dcs.append(dc_average)
        dc_f.write(str(dc_average) + "\n")

    obj_f.close()
    dc_f.close()
    return avg_dcs


def read_avlk(output, data_name, sizes, num_instance):
    obj_f = open("{}/{}_{}.txt".format(output, data_name, 'objs'), 'w')
    ratio_f = open("{}/{}_{}.txt".format(output, data_name, 'ratios'), 'w')
    dc_f = open("{}/{}_{}.txt".format(output, data_name, 'dcs'), 'w')
    ratio_f.write("size     mean    median    60%    70%    80%    90%    max \n")
    avg_dcs = []
    for size in sizes:
        obj_output_f = open("{}/{}_{}/avlk_vca_obj.txt".format(output, data_name, size), 'r')
        ratio_output_f = open("{}/{}_{}/approx_ratio_stats.txt".format(output, data_name, size), 'r')
        dc_output_f = open("{}/{}_{}/avlk_dist_computation.txt".format(output, data_name, size), 'r')
        next(obj_output_f)
        next(ratio_output_f)
        obj_f.write(str(size) + ' ')
        ratio_f.write(str(size) + ' ')
        dc_f.write(str(size) + ' ')
        delim = ' '
        objs = []
        ratios1 = []
        ratios2 = []
        for i in range(num_instance):
            line = obj_output_f.readline()
            line = line.strip().split(delim)
            line = [float(x) for x in line if x != '']
            objs.append(line[:2])

            line = ratio_output_f.readline()
            line = line.strip().split(delim)
            new_line1 = []
            new_line2 = []
            for x in line:
                if x == '':
                    continue
                [y, z] = x.split('/')
                new_line1.append(float(y))
                new_line2.append(float(z))

            ratios1.append(new_line1)
            ratios2.append(new_line2)

        line = dc_output_f.readline()
        line = line.strip().split(" ")
        dcs = [int(x) for x in line if x != '']

        obj_averages = np.average(np.array(objs), axis=0)
        ratio_averages1 = np.average(np.array(ratios1), axis=0)
        ratio_averages2 = np.average(np.array(ratios2), axis=0)
        dc_average = sum(dcs) / len(dcs)
        avg_dcs.append(dc_average)

        obj_f.write(str(obj_averages[0]) + " " + str(obj_averages[1]))
        obj_f.write("\n")
        for i in range(ratio_averages1.shape[0]):
            ratio_f.write("{}/{} ".format(ratio_averages1[i], ratio_averages2[i]))
        ratio_f.write("\n")
        dc_f.write(str(dc_average) + "\n")
        obj_output_f.close()
        ratio_output_f.close()
        dc_output_f.close()
    obj_f.close()
    ratio_f.close()
    dc_f.close()
    return avg_dcs


if __name__ == "__main__":
    output1 = "./results_with_jl_sglk_new"
    output2 = "./results_with_jl_new"
    data_name = "seizure"
    sizes = [2 ** k * 100 for k in range(5)]
    num_instance = 5
    #read_sglk(output1, data_name, sizes, num_instance)
    avg_dcs = read_sglk(output1, data_name, sizes, num_instance)
    print(avg_dcs)

    plt.xlabel("sample size")
    plt.ylabel("# of distance computations")
    plt.xscale('log')
    #change this according to sglk/avlk
    plt.plot(sizes, avg_dcs, color='blue', label='Proxy-Hash-SL')

    #fit a fake line
    power = 1.7
    constant = float(avg_dcs[0]) / (float(sizes[0]) ** power)
    fake_dcs = [constant * size ** power for size in sizes]
    plt.plot(sizes, fake_dcs, color='black', ls='--', label='Fitted Line, y=cx^{}'.format(power))
    plt.legend()
    #change this line according to sglk/avlk
    plt.savefig("./{}_{}_{}.pdf".format(data_name, 'dc', 'sglk'))
    plt.show()






This folder contains codes for the project "Faster Hierarchical Clustering in General Metric Spaces using Approximate Nearest Neighbors".
The original data files are not contained due to space.

Here is a list of the functions of different files in this folder:

- data_preprocess, data_preprocess_2, data_preprocess_high_dimensional: data preprocess files for all three road map data sets and the high dimensional data set Seizure.

- dist_gather, distance_counts, data_gather_ny, data_gather_seizure: gathering data, including objective function ratios, approximation ratios and counts of distance computations for road map data sets.

- lsh_MST_second_implementation_constant: implementation of LSH-single linkage (or MST).

- lsh_avlk_with heaps: implementation of LSH-average linkage.

- avlk_validation_helper: help functions for validating the accuracy of LSH-average linkage.

- test_ny, test_avlk_map_metric, test_avlk_with_jl_new_test, test_eps_ny, MST_test_seizure: different testing files for both road map datasets and Seizure.
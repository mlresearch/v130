from scipy.cluster.hierarchy import average as scipy_avlk
from scipy.cluster.hierarchy import to_tree
from scipy.sparse.csgraph import shortest_path
from scipy.spatial.distance import pdist, euclidean
from scipy.sparse import csr_matrix
from data_preprocess import load_data
from lsh_avlk_with_heaps import full_LSH_with_validation
from avlk_validation_helpers import calculate_hc_obj, vca_obj, create_parent_dict, average_linkage, find_min, distortion_ratio, dimension_reduction

import math
import numpy as np
import time
import statistics as stats
import os

def pairwise_dist(points, norm):
    n = len(points)
    dist = np.zeros((n, n))
    for i in range(n):
        for j in range(i):
            dist[i][j] = np.linalg.norm(np.array(points[i]) - np.array(points[j]), ord=norm)
            dist[j][i] = dist[i][j]
    return dist

def avlk_validation(output, direc, file_name, num_instance, size, eps, eps1, eps2):
    print("sample size: %d" % size)

    #create the directory for storing results
    if not os.path.exists("./{}/{}_{}".format(output, file_name, size)):
        os.makedirs("./{}/{}_{}".format(output, file_name, size))

    obj_f = open("./{}/{}_{}/avlk_vca_obj.txt".format(output, file_name, size), 'w')
    dc_f = open("./{}/{}_{}/avlk_dist_computation.txt".format(output, file_name, size), 'w')
    approx_ratio_f = open("./{}/{}_{}/approx_ratio_stats.txt".format(output, file_name, size), 'w')
    distortion_f = open("./{}/{}_{}/distortion_ratio_stats_4.txt".format(output, file_name, size), 'w')

    obj_f.write("lsh_ratio    euclid_ratio    avlk_vca    upperbound_vca\n")
    approx_ratio_f.write("mean    median    60%    70%    80%    90%    max\n")
    distortion_f.write("mean    median    60%    70%    80%    90%    max\n")

    for i in range(num_instance):
        print("instance %d" % i)
        input_f = open("./{}/{}_{}/{}.txt".format(direc, file_name, size, i))

        delim = ' '
        data = []

        for line in input_f.readlines():
            y = line.strip().split(delim)
            y = [float(x) for x in y]
            #delete repeating points
            check = True
            for pt in data:
                if np.linalg.norm(np.array(pt) - np.array(y), ord=2) <= 0.0001:
                    check = False
                    break
            if check == False:
                continue
            data.append(y)

        n = len(data)

        # calculate metrics

        dist_matrix = pairwise_dist(data, norm=2)

        data = np.array(data)
        projected_data = dimension_reduction(data, 4)

        fake_dist = pairwise_dist(projected_data, norm=2)
        _, _, d_min = find_min(dist_matrix)
        scale = 3.0
        projected_data = projected_data * scale
        fake_dist = fake_dist * scale


        distorts = distortion_ratio(dist_matrix, fake_dist)
        distort_quantile = [q for q in stats.quantiles(distorts, n=10)]
        distortion_f.write("{}  {}  {}  {}  {}  {}  {}\n".format(stats.mean(distorts), stats.median(distorts),
                                                                 distort_quantile[5], distort_quantile[6],
                                                                 distort_quantile[7], distort_quantile[8],
                                                                 max(distorts)))
        print("the maximum distortion ratio: %f" % max(distorts))


        upper_bound = np.sum(dist_matrix) / 2 * n

        # start LSH
        print("start...")
        num_concats = 4
        num_repeats = 5
        num_trials = 8
        n_neighbors = 5 * num_repeats



        #true average linkage
        Z = pdist(dist_matrix)
        cluster_matrix = scipy_avlk(Z)
        scipy_root = to_tree(cluster_matrix)
        avlk_obj, _ = calculate_hc_obj(dist_matrix, scipy_root)

        print("l_infinity avlk done")

        fake_Z = pdist(fake_dist)
        fake_cluster_matrix = scipy_avlk(fake_Z)
        fake_scipy_root = to_tree(fake_cluster_matrix)
        fake_avlk_obj, _ = calculate_hc_obj(dist_matrix, fake_scipy_root)

        print("l_2 avlk done")

        tree_edges, dc, id_cluster_dict, approx_ratios = full_LSH_with_validation(projected_data, dist_matrix, d_min, eps, eps1, eps2, num_concats,
                                                   num_repeats, n_neighbors, num_trials)
        print("lsh + validation done")


        parent_dict = create_parent_dict(tree_edges)
        lsh_obj = vca_obj(2 * n - 2, parent_dict, id_cluster_dict, dist_matrix)

        lsh_ratio = float(lsh_obj) / float(avlk_obj)
        euclid_ratio = float(fake_avlk_obj) / float(avlk_obj)


        _, avlk_approx_ratios = average_linkage(np.copy(fake_dist), np.copy(dist_matrix))
        print("proxy-avlk validation done")


        print("lsh ratio:", lsh_ratio, "euclid ratio:", euclid_ratio)
        obj_f.write("{}    {}    ".format(lsh_ratio, euclid_ratio) + "%.4e    %.4e \n" % (avlk_obj, upper_bound))

        print("# of dist computations:", dc)
        dc_f.write(str(dc) + ' ')

        quantiles1 = [q for q in stats.quantiles(approx_ratios, n=10)]
        quantiles2 = [q for q in stats.quantiles(avlk_approx_ratios, n=10)]
        print("mean:", stats.mean(approx_ratios), stats.mean(avlk_approx_ratios))
        print("median", stats.median(approx_ratios), stats.median(avlk_approx_ratios))
        print("60%", quantiles1[5], quantiles2[5])
        print("70%", quantiles1[6], quantiles2[6])
        print("80%", quantiles1[7], quantiles2[7])
        print("90%", quantiles1[8], quantiles2[8])
        print("max", max(approx_ratios), max(avlk_approx_ratios))

        
        # optimize this
        approx_ratio_f.write("{}/{}  {}/{}  {}/{}  {}/{}  {}/{}  {}/{}  {}/{}\n".format(stats.mean(approx_ratios),
                                                                                        stats.mean(avlk_approx_ratios),
                                                                                        stats.median(approx_ratios),
                                                                                        stats.median(
                                                                                            avlk_approx_ratios),
                                                                                        quantiles1[5], quantiles2[5],
                                                                                        quantiles1[6], quantiles2[6],
                                                                                        quantiles1[7], quantiles2[7],
                                                                                        quantiles1[8], quantiles2[8],
                                                                                        max(approx_ratios),
                                                                                        max(avlk_approx_ratios)))

        obj_f.flush()
        dc_f.flush()
        approx_ratio_f.flush()
        distortion_f.flush()

    obj_f.close()
    dc_f.close()
    approx_ratio_f.close()
    distortion_f.close()

    return


if __name__ == "__main__":
    num_instance = 5
    sample_sizes = [2 ** k * 100 for k in range(7)]
    data_name = 'seizure'
    direc = 'samples_' + data_name
    output = 'results_with_jl_new'

    #eps_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    eps = 0.2
    eps1 = 2
    eps2 = 0.5
    for size in sample_sizes:
        avlk_validation(output, direc, data_name, num_instance, size, eps, eps1, eps2)



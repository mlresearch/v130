import math
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import minimum_spanning_tree, shortest_path
from scipy.spatial.distance import euclidean
from scipy.stats import linregress
from data_preprocess import load_data
from lsh_MST_second_implementation_constant import full_LSH
import time
import matplotlib.pyplot as plt
def read_result(output, grid_size, city, num_instance):
    new_lines = []
    output_f = open("{}/{}/{}_dist_counts.txt".format(output, grid_size, city), 'r')
    next(output_f)
    delim = ' '
    for i in range(num_instance):
        new_line = []
        line = output_f.readline()
        line = line.strip().split(delim)
        line = [x for x in line if x != '' and x != ' ']
        new_line.append(int(line[0]))
        for x in line[1:]:
            new_line.append(float(x))
        new_lines.append(new_line)
        next(output_f)
    output_f.close()
    return new_lines

if __name__ == "__main__":
    num_instance = 5
    #use this if ny
    #grid_size_list = [40, 30, 20, 10, 8, 5, 4]
    #use this if bay
    #grid_size_list = [40, 30, 20, 15, 10, 8, 5, 4]
    #use this if lks
    grid_size_list = [100, 50, 30, 20, 10]
    city = 'lks'
    direc = 'samples'
    output = 'results'
    saveplace = 'final'
    eps_list = [0.1, 0.2, 0.3, 0.4, 0.5]
    output_list = []

    for grid_size in grid_size_list:
        output_list.extend(read_result(output, grid_size, city, num_instance))

    output_list = sorted(output_list)
    sample_list = [line[0] for line in output_list]
    dist_list = [line[1:] for line in output_list]

    dist_list = np.array(dist_list)

    out_f = open("{}/{}_dist_slopes.txt".format(saveplace, city), "w")
    for eps in eps_list:
        out_f.write("{}  ".format(eps))
    out_f.write("\n")

    for j in range(len(eps_list)):
        gradient, intercept, r_value, p_value, std_err = linregress(np.log(sample_list), np.log(dist_list[:, j]))

        out_f.write("({}/{}) ".format(str(gradient), str(r_value)))
        out_f.write(" ")
    out_f.close()

    final_f = open("{}/{}_all_dist_counts.txt".format(saveplace, city), 'w')
    final_f.write("Sample Size  ")

    for eps in eps_list:
        final_f.write("eps = {}  ".format(str(eps)))
    final_f.write("\n")

    for j in range(len(dist_list)):
        final_f.write("{} ".format(sample_list[j]))
        line = dist_list[j]
        for i in range(len(eps_list)):
            final_f.write("{} ".format(int(line[i])))
        final_f.write("\n")
    final_f.close()

    another_sample_list = [line[0] for line in output_list if line[0] >= 1000]
    another_dist_list = np.array([line[1:] for line in output_list if line[0] >= 1000])

    #drawing all plots
    plt.figure(0)
    plt.xlabel("Sample Size")
    plt.ylabel("# of distance checks")
    #plt.plot(sample_list, ratio_list_MST, label='Euclidean MST')
    for i in range(len(eps_list)):
        plt.plot(another_sample_list, another_dist_list[:, i], 'x-', label="LSH, eps={}".format(eps_list[i]))

    plt.legend()
    plt.savefig("{}/{}_dist_versus_sample_size.pdf".format(saveplace, city))
    plt.show()

    plt.figure(1)
    plt.xlabel("Eps")
    plt.ylabel("Sample")
    plt.xticks([0.1, 0.2, 0.3, 0.4, 0.5])

    some_samples = np.random.choice(len(another_sample_list), 5)
    some_sample_list = np.array(another_sample_list)[some_samples]
    some_dist_lists = another_dist_list[some_samples, :]

    for i in range(5):
        plt.plot([0.1, 0.2, 0.3, 0.4, 0.5], some_dist_lists[i, 0: 5], 'x-', label="Sample Size={}".format(some_sample_list[i]))

    plt.legend()
    plt.savefig("{}/{}_dist_versus_eps.pdf".format(saveplace, city))
    plt.show()







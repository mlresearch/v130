import math
import numpy as np
#baselines
from scipy.sparse.csgraph import minimum_spanning_tree, shortest_path
from scipy.cluster.hierarchy import single as scipy_single
from scipy.spatial.distance import pdist
from sklearn.cluster import AgglomerativeClustering
from fastcluster import single as fast_single


from scipy.sparse import csr_matrix
from scipy.spatial.distance import euclidean
from data_preprocess import load_data
from lsh_MST_second_implementation_constant import full_LSH
import time

def find_scale(coors, edge_rows, edge_cols, edge_weights):
    euclids = [euclidean(coors[edge_rows[i]], coors[edge_cols[i]]) for i in range(len(edge_weights))]
    return sum(edge_weights) / sum(euclids)

def check_edges(edge_rows, edge_cols, edge_weights, coors, nodes, city):
    all_coors = load_data("{}_latlong.co".format(city))
    all_coors = np.array([[x, y / 1e6, z / 1e6] for x, y, z in all_coors])
    all_edges = load_data("{}_dist.gr".format(city))
    all_edge_dict = {(edge[0], edge[1]): edge[2] for edge in all_edges if edge[0] < edge[1]}
    n = len(coors)
    m = len(edge_weights)
    for i in range(n):
        node = nodes[i]
        assert abs(coors[i][0] - all_coors[node - 1][1]) <= 0.001 or abs(coors[i][1] - all_coors[node - 1][2]) <= 0.001

    for j in range(m):
        assert edge_weights[j] == all_edge_dict[(nodes[edge_rows[j]], nodes[edge_cols[j]])]

    return

#check if LSH successfully return a tree
def is_tree(edges):
    #make a dictionary
    tree_edge_dict = {}
    for edge in edges:
        if edge[0] in tree_edge_dict:
            tree_edge_dict[edge[0]].append(edge[1])
        else:
            tree_edge_dict[edge[0]] = [edge[1]]
        if edge[1] in tree_edge_dict:
            tree_edge_dict[edge[1]].append(edge[0])
        else:
            tree_edge_dict[edge[1]] = [edge[0]]

    #do BFS
    gone_nodes = [0]
    current_nodes = [0]
    while len(current_nodes) >= 1:
        node = current_nodes.pop()
        neighbor_list = tree_edge_dict.pop(node)
        for neighbor in neighbor_list:
            if neighbor in gone_nodes:
                return False
            current_nodes.append(neighbor)
            gone_nodes.append(neighbor)
            tree_edge_dict[neighbor].remove(node)

    return True


def grid_size_experiment(output, direc, city, num_instance, grid_size, eps_list, scale=1e6):
    print("grid size: %d" % grid_size)
    out_f = open("./{}/{}/{}.txt".format(output, grid_size, city), 'w')
    out_f.write("# nodes  Euclid MST Ratio  Scipy MST Time   Scipy SL Time  Scikit SL Time  FastCluster SL Time  ")
    for eps in eps_list:
        out_f.write("LSH Ratio_{}  LSH time_{}  ".format(str(eps), str(eps)))
    out_f.write("\n")

    for i in range(num_instance):
        print("instance %d" % i)
        coor_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subcoors", i))
        edge_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subedges", i))
        node_f = open("./{}/{}/{}_{}_{}.txt".format(direc, grid_size, city, "subnodes", i))

        coors = []
        edge_rows = []
        edge_cols = []
        edge_weights = []
        nodes = []
        delim = ' '

        for line in coor_f.readlines():
            y = line.strip().split(delim)
            y = [float(x) * scale for x in y]
            coors.append(y)

        for line in edge_f.readlines():
            y = line.strip().split(delim)
            y = [int(x) for x in y]
            edge_rows.append(y[0])
            edge_cols.append(y[1])
            edge_weights.append(y[2])

        for line in node_f.readlines():
            y = line.strip().split(delim)
            nodes.extend([int(x) for x in y])

        # check_edges(edge_rows, edge_cols, edge_weights, coors, nodes, city)

        # calculate shortest path matrix
        n = len(nodes)
        m = len(edge_weights)
        print("# of points: %d, # of edges: %d" % (n, m))
        out_f.write("{}  ".format(str(n)))

        edge_weights = np.array(edge_weights, dtype=int)
        edge_rows = np.array(edge_rows, dtype=int)
        edge_cols = np.array(edge_cols, dtype=int)
        sparse_edges = csr_matrix((edge_weights, (edge_rows, edge_cols)), shape=(n, n))
        dist_matrix = shortest_path(csgraph=sparse_edges, method='D', directed=False)

        MST_edge = minimum_spanning_tree(csgraph=sparse_edges).tocoo()
        edge_cost = sum(MST_edge.data)
        euclid_dist = np.zeros((n, n))
        d_min = min(edge_weights)

        for j in range(n):
            for l in range(j + 1, n):
                euclid_dist[j][l] = euclidean(coors[j], coors[l])

        # baselines
        begin1 = time.time()
        MST_euclid = minimum_spanning_tree(csgraph=euclid_dist)
        end1 = time.time()

        MST_euclid = MST_euclid.tocoo()
        euclid_rows = MST_euclid.row
        euclid_cols = MST_euclid.col
        assert euclid_rows.shape[0] == n - 1
        edge_cost_euclid_MST = sum([dist_matrix[euclid_rows[j]][euclid_cols[j]] for j in range(n - 1)])
        out_f.write("{}  ".format(float(edge_cost_euclid_MST) / edge_cost))
        out_f.write("{} ".format(end1 - begin1))
        out_f.flush()

        scipy_dist = pdist(np.array(coors), 'Euclidean')
        begin1 = time.time()
        scipy_single(scipy_dist)
        end1 = time.time()

        out_f.write("{} ".format(end1 - begin1))

        euclid_dist_full = np.copy(euclid_dist)
        for j in range(n):
            for l in range(j):
                euclid_dist_full[j][l] = euclid_dist[l][j]
        begin1 = time.time()
        model = AgglomerativeClustering(affinity="precomputed", compute_full_tree=True, linkage='single')
        model.fit(euclid_dist_full)
        end1 = time.time()
        out_f.write("{} ".format(end1 - begin1))

        begin1 = time.time()
        fast_single(scipy_dist)
        end1 = time.time()
        out_f.write("{} ".format(end1 - begin1))

        # start LSH

        k = 2
        num_concats = 4
        num_repeats = 3
        num_trials = 4
        n_neighbors = num_repeats
        dim = (num_repeats, k, num_concats)

        coors = np.array(coors)

        for eps in eps_list:
            begin2 = time.time()
            tree_edges = full_LSH(coors, dist_matrix, d_min, eps, num_concats, num_repeats, n_neighbors, num_trials)
            end2 = time.time()
            assert is_tree(tree_edges)
            lsh_obj = sum([edge[2] for edge in tree_edges])
            out_f.write("{}  ".format(float(lsh_obj) / edge_cost))
            out_f.write("{} ".format(end2 - begin2))
            out_f.flush()

        out_f.write("\n\n")

    out_f.close()

    return


if __name__ == "__main__":
    num_instance = 5
    grid_size_list = [4]
    city = 'ny'
    direc = 'samples'
    output = 'results'
    scale = 1e6
    eps_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]

    for grid_size in grid_size_list:
        grid_size_experiment(output, direc, city, num_instance, grid_size, eps_list, scale)






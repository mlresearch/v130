##### Code for Figure 3 #####

library(foreach)
library(doParallel)
library(abind)
library(latex2exp)

source("algorithms.R")

acomb <- function(...) abind(..., along=3)

### Experiments for Figure 3 ###
# Experiments (i)-(iii)
n = 1000
k = 5 + 5*(1:15)
m = 500
num_rep = 100
num_try = 50
numcl = 25
prec = 0.01
  
cl <- makeCluster(numcl)
registerDoParallel(cl)
clusterExport(cl,list("gen_data_sparse", "hwf", "sparta_sup", "sparta", "swf", "wf_loss", "wf_grad", "rwf_grad"))
clusterExport(cl,list("n","k", "m", "num_rep", "num_try", "prec"),envir=environment())

# Run different reconstruction algorithms num_rep times with the specified parameters
success_xmax <- foreach(rep = 1:num_rep, .combine='acomb', .multicombine=TRUE) %dopar%{
  B = array(0, dim = c(length(k), 3, 1, 4))
  for(j in 1:length(k)){
    for(i in 1:3){
      # Generate data
      data = gen_data_sparse(m, n, k[j], xmax = (i+1))
      
      # Signal reconstruction using HWF
      ind_sup = sort(t(data$A^2) %*% data$y, index.return = TRUE)$ix[(n-num_try+1):n]
      for(trial in 1:num_try){
        # To save computation, only run HWF when we pick a coordinate on the support
        if(data$x[ind_sup[num_try+1-trial]]!=0){
          res = hwf(data$A, data$y, ini = ind_sup[num_try+1-trial], iteration = 100000)
          # Check whether this run was successful
          # To save computation, we try no further once one run is successful
          # Selecting the sparsest estimate from all runs yields the same result
          if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
            B[j, i, 1, 1] = 1
            break
          }
        }
      } 
      
      # Signal reconstruction using SPARTA-support
      for(trial in 1:num_try){
        res = sparta_sup(data$A, data$y, k[j], trial = trial, iteration = 10000)
        # To save computation on unsuccessful runs, we run 10000 iterations; there is 
        # no benefit in running the algorithm for more iterations
        
        # Check whether this run was successful
        # To save computation, we try no further once one run is successful
        # Selecting the estimate with the minimum gradient from all runs yields the same result
        if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
          B[j, i, 1, 2] = 1
          break
        }
      } 
      
      # Signal reconstruction using SPARTA
      res = sparta(data$A, data$y, k = k[j], iteration = 10000)
      # Check whether this run was successful
      if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
        B[j, i, 1, 3] = 1
      }
      
      # Signal reconstruction using SWF
      res = swf(data$A, data$y, k = k[j], iteration = 10000)
      # Check whether this run was successful
      if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
        B[j, i, 1, 4] = 1
      }
    }
  }
  B
}
stopCluster(cl)

saveRDS(success_xmax, file = "output_xmax.rds")

# Experiment (iv) (k=50 fixed, vary x_max)
k = 50
x_max = (1:11) / 20 + 0.1

cl <- makeCluster(numcl)
registerDoParallel(cl)
clusterExport(cl,list("gen_data_sparse", "hwf", "sparta_sup", "sparta", "swf", "wf_loss", "wf_grad", "rwf_grad"))
clusterExport(cl,list("n","k", "m", "num_rep", "num_try", "prec"),envir=environment())

# Run different reconstruction algorithms num_rep times with the specified parameters
success_xmaxk50 <- foreach(rep = 1:num_rep, .combine='acomb', .multicombine=TRUE) %dopar%{
  B = array(0, dim = c(length(x_max), 4, 1))
  for(j in 1:length(x_max)){
    # Generate data
    data = gen_data_sparse(m, n, k, xmax = 5, maxval = x_max[j])
    
    # Signal reconstruction using HWF
    ind_sup = sort(t(data$A^2) %*% data$y, index.return = TRUE)$ix[(n-num_try+1):n]
    for(trial in 1:num_try){
      # To save computation, only run HWF when we pick a coordinate on the support
      if(data$x[ind_sup[num_try+1-trial]]!=0){
        res = hwf(data$A, data$y, ini = ind_sup[num_try+1-trial], iteration = 100000)
        # Check whether this run was successful
        # To save computation, we try no further once one run is successful
        # Selecting the sparsest estimate from all runs yields the same result
        if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
          B[j, 1, 1] = 1
          break
        }
      }
    } 
    
    # Signal reconstruction using SPARTA-support
    for(trial in 1:num_try){
      res = sparta_sup(data$A, data$y, k, trial = trial, iteration = 10000)
      # To save computation on unsuccessful runs, we run 10000 iterations; there is 
      # no benefit in running the algorithm for more iterations
      
      # Check whether this run was successful
      # To save computation, we try no further once one run is successful
      # Selecting the estimate with the minimum gradient from all runs yields the same result
      if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
        B[j, 2, 1] = 1
        break
      }
    } 
    
    # Signal reconstruction using SPARTA
    res = sparta(data$A, data$y, k = k, iteration = 10000)
    # Check whether this run was successful
    if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
      B[j, 3, 1] = 1
    }
    
    # Signal reconstruction using SWF
    res = swf(data$A, data$y, k = k, iteration = 10000)
    # Check whether this run was successful
    if(min(sqrt(sum((res[nrow(res),]-data$x)^2)), sqrt(sum((res[nrow(res),]+data$x)^2))) < prec){
      B[j, 4, 1] = 1
    }   
  
  }
  B
}
stopCluster(cl)

saveRDS(success_xmaxk50, file = "output_xmaxk50.rds")


temp1 = readRDS("output_xmax1.rds")
temp2 = readRDS("output_xmax2.rds")[1:15,,,]
temp3 = readRDS("output_xmax3.rds")[1:15,,,]
success_xmax = temp2
success_xmax[,3,,] = temp3[,3,,]
success_xmax[1:9,1,,] = temp1[,1,,]
success_xmaxk50 = readRDS("output_xmaxk50.rds")

# Results for PR-GAMP obtained using the code available from https://sourceforge.net/projects/gampmatlab/
pr_gamp1 = c(0.95, 0.69, 0.34, 0.16, 0.04, 0.02, 0, 0, 0, 0, 0, 0, 0, 0, 0) #, 0, 0, 0, 0)
pr_gamp2 = c(1, 1, 0.99, 1, 0.95, 0.91, 0.89, 0.65, 0.63, 0.56, 0.49, 0.37, 0.38, 0.22, 0.24) #, 0.2, 0.17, 0.08, 0.07)
pr_gamp3 = c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.99)
pr_gamp4 = c(0, 0.01, 0.12, 0.33, 0.54, 0.78, 0.9, 0.98, 1, 1, 1, 1)

### Generate plot ###

pdf(file = "plot_xmax.pdf", width = 8, height = 6)

par(mfrow=c(2,2), mai = c(0.7, 0.7, 0.1, 0.1), bg = "transparent")

# Top left plot: x_max = 1/sqrt(k)
plot(pr_gamp1, type = "o", lwd = 2, pch = 4, col = "brown", ylim = c(0,1), ylab = "", xlab = "", xaxt = "n")
axis(1, at = (1 + 2*(0:7)), label = 10*(1:8))
title(xlab = "Sparsity level k", ylab = "Success rate", line = 2.5)
lines(apply(success_xmax, c(1,2,4), mean)[,1,2], type = "o", lwd = 2, pch = 18, col = "magenta")
lines(apply(success_xmax, c(1,2,4), mean)[,1,3], type = "o", lwd = 2, pch = 15, col = "blue")
lines(apply(success_xmax, c(1,2,4), mean)[,1,4], type = "o", lwd = 2, pch = 17, col = "black")
lines(apply(success_xmax, c(1,2,4), mean)[,1,1], type = "o", lwd = 2, pch = 16, col = "red")
legend('topright',legend=c("HWF", "SWF", "SPARTA", "PR-GAMP", "SPARTA-support"), col=c("red", "black", "blue", "brown", "magenta"), pch = c(16,17,15,4,18), lwd = 2, cex = 1, inset = c(0, -0.03), bty = "n")

# Top right plot: x_max = k^(-0.25)
plot(pr_gamp2, type = "o", lwd = 2, pch = 4, col = "brown", ylim = c(0,1), ylab = "", xlab = "", xaxt = "n")
axis(1, at = (1 + 2*(0:7)), label = 10*(1:8))
title(xlab = "Sparsity level k", ylab = "Success rate", line = 2.5)
lines(apply(success_xmax, c(1,2,4), mean)[,2,2], type = "o", lwd = 2, pch = 18, col = "magenta")
lines(apply(success_xmax, c(1,2,4), mean)[,2,3], type = "o", lwd = 2, pch = 15, col = "blue")
lines(apply(success_xmax, c(1,2,4), mean)[,2,4], type = "o", lwd = 2, pch = 17, col = "black")
lines(apply(success_xmax, c(1,2,4), mean)[,2,1], type = "o", lwd = 2, pch = 16, col = "red")
legend('bottomleft',legend=c("HWF", "SWF", "SPARTA", "PR-GAMP", "SPARTA-support"), col=c("red", "black", "blue", "brown", "magenta"), pch = c(16,17,15,4,18), lwd = 2, cex = 1, inset = c(0, -0.03), bty = "n")

# Bottom left plot: x_max = 0.7
plot(pr_gamp3, type = "o", lwd = 2, pch = 4, col = "brown", ylim = c(0,1), ylab = "", xlab = "", xaxt = "n")
axis(1, at = (1 + 2*(0:7)), label = 10*(1:8))
title(xlab = "Sparsity level k", ylab = "Success rate", line = 2.5)
lines(apply(success_xmax, c(1,2,4), mean)[,3,2], type = "o", lwd = 2, pch = 18, col = "magenta")
lines(apply(success_xmax, c(1,2,4), mean)[,3,3], type = "o", lwd = 2, pch = 15, col = "blue")
lines(apply(success_xmax, c(1,2,4), mean)[,3,4], type = "o", lwd = 2, pch = 17, col = "black")
lines(apply(success_xmax, c(1,2,4), mean)[,3,1], type = "o", lwd = 2, pch = 16, col = "red")
legend('bottomleft',legend=c("HWF", "SWF", "SPARTA", "PR-GAMP", "SPARTA-support"), col=c("red", "black", "blue", "brown", "magenta"), pch = c(16,17,15,4,18), lwd = 2, cex = 1, inset = c(0, -0.03), bty = "n")

# Bottom right plot: fix k=50, vary x_max from 0.15 to 0.7
plot(pr_gamp4, type = "o", lwd = 2, pch = 4, col = "brown", ylim = c(0,1), ylab = "", xlab = "", xaxt = "n")
axis(1, at = (2*(1:6)), label = 0.1*(2:7))
title(xlab = TeX('Maximum signal component $x^*_{max}$'), ylab = "Success rate", line = 2.5)
lines(c(apply(success_xmaxk50, c(1,2), mean)[,2], apply(success_xmax, c(1,2,4), mean)[9,3,2]), type = "o", lwd = 2, pch = 18, col = "magenta")
lines(c(apply(success_xmaxk50, c(1,2), mean)[,3], apply(success_xmax, c(1,2,4), mean)[9,3,3]), type = "o", lwd = 2, pch = 15, col = "blue")
lines(c(apply(success_xmaxk50, c(1,2), mean)[,4], apply(success_xmax, c(1,2,4), mean)[9,3,4]), type = "o", lwd = 2, pch = 17, col = "black")
lines(c(apply(success_xmaxk50, c(1,2), mean)[,1], apply(success_xmax, c(1,2,4), mean)[9,3,1]), type = "o", lwd = 2, pch = 16, col = "red")
legend('topleft',legend=c("SPARTA-support", "PR-GAMP", "SPARTA", "SWF", "HWF"), col=c("magenta", "brown", "blue", "black", "red"), pch = c(18,4,15,17,16), lwd = 2, cex = 1, inset = c(0, -0.03), bty = "n")

dev.off()

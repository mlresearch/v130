import os

sim_files_folder = "./Simulation_MAB_files"
save_address = "./SimulationResults"

LastFM_save_address = "./LastFMResults"
LastFM_address = './Dataset/lastfm'
LastFM_FeatureVectorsFileName = os.path.join(LastFM_address, 'Arm_FeatureVectors.dat')